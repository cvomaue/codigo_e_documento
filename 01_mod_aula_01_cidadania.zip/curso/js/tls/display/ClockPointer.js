function ClockPointer(texture, type)
{
    AnimateButton.call(this, texture);
    
    this._im.pivot.set(this.width / 2, this.height);
    
    this._isMove = false;
    this._type = type;
    this._radius = this.height;
    this._catetoOposto = 0;
    this._catetoAdjacente = 0;
    
    this._hour = 0;
    this._minutes = 0;
}

ClockPointer.prototype = Object.create(AnimateButton.prototype);
ClockPointer.prototype.constructor = ClockPointer;

Object.defineProperties(ClockPointer.prototype, {
    hour: {
        get: function(){
            if(this._type == ClockPointer.TYPE_HOUR)
                return this._hour;
            else
                return 0;
        },
        set: function(value){
            if(this._type == ClockPointer.TYPE_HOUR)
            {
                this._hour = value;
                this._setRotation();
            }
        }
    },
    
    minutes: {
        get: function(){
            if(this._type == ClockPointer.TYPE_MINUTES)
                return this._minutes;
            else
                return 0;
        },
        set: function(value){
            if(this._type == ClockPointer.TYPE_MINUTES)
            {
                this._minutes = value;
                this._hour = this._minutes / 5;
                
                this._setRotation();
            }
        }
    }
})

ClockPointer.prototype.addEvents = function()
{
    AnimateButton.prototype.addEvents.call(this);
    
    this
        .on('mousemove', this._onMove)
        .on('touchmove', this._onMove);
}

ClockPointer.prototype.removeEvents = function()
{
    AnimateButton.prototype.removeEvents.call(this);   
    
    this
        .removeListener('mousemove', this._onMove)
        .removeListener('touchmove', this._onMove);
}

ClockPointer.prototype._onDown = function(e)
{
    this._isMove = true;

    this._data = e.data;
    this._local = this._data.getLocalPosition(this);
}

ClockPointer.prototype._onUp = function(e)
{    
    this._isMove = false;    
    this._data = null;

    var round = Math.round(this._im.rotation * PIXI.RAD_TO_DEG / 30);
    var roundAngle = round * 30;
    
    this._hour = round > 0 ? round : round + 12;
    this._minutes = this._hour * 5;
    
    this._setRotation();
}

ClockPointer.prototype._onMove = function(e)
{
    if(this._isMove)
    {   
        var newPosition = this._data.getLocalPosition(this);
        
        var _x = newPosition.x;
        var _y = newPosition.y;
        
        var _rad = Math.atan2(_x, -_y);
        this._im.rotation = _rad;
    }
}

ClockPointer.prototype._setRotation = function()
{
    var roundAngle = this._hour > 6 ? this._hour - 12 : this._hour;
    
    TweenMax.to(this._im, 0.3, {rotation: roundAngle * 30 * PIXI.DEG_TO_RAD});
}

ClockPointer.prototype.destroy = function()
{
    this.removeEvents();
    this.removeAllListeners();
    
    TweenMax.killChildTweensOf(this._im);
    
    AnimateButton.prototype.destroy.call(this);
}

ClockPointer.TYPE_HOUR = "hour";
ClockPointer.TYPE_MINUTES = "minutes";

tls.display.ClockPointer = ClockPointer;

