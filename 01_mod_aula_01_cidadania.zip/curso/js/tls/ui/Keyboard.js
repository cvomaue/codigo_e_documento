function Keyboard(textures)
{
    PIXI.Container.call(this);
    
    this._textures = textures;
    this._keys = [];
    this._alphabetic = [];
    this._numeric = []
    this.POS_Y = 374;
    
    for(var i = 0; i < this._textures.length; i++)
    {
        var k = new AnimateButton(this._textures[i]);
        k.name = this._textures[i].name;
        k.x = this._textures[i].sourceX + k.width / 2;
        k.y = this._textures[i].sourceY + k.height / 2;
        
        if(!isNaN(parseInt(k.name)))
        {
            this._numeric.push(k);
        }
        else
        {
            if(k.name == "alfabetico") this._numeric.push(k);
            else this._alphabetic.push(k);
        }
        
        this._keys.push(k);
        this.addChild(k);       
    }    
    
    this.alpha = 0;
    this.visible = false;
}

Keyboard.prototype = Object.create(PIXI.Container.prototype);
Keyboard.prototype.constructor = Keyboard;

Keyboard.prototype._showNumeric = function()
{    
    for(i = 0; i < this._numeric.length; i++)
    {
        this._numeric[i].interactive = true;
        this._numeric[i].visible = true;
    }
}

Keyboard.prototype._hideNumeric = function()
{
    for(i = 0; i < this._numeric.length; i++)
    {
        this._numeric[i].interactive = false;
        this._numeric[i].visible = false;
    }
}

Keyboard.prototype._showAlphabetic = function()
{
    for(var i = 0; i < this._alphabetic.length; i++)
    {
        this._alphabetic[i].interactive = true;
        this._alphabetic[i].visible = true;
    }
}

Keyboard.prototype._hideAlphabetic = function()
{
    for(var i = 0; i < this._alphabetic.length; i++)
    {
        this._alphabetic[i].interactive = false;
        this._alphabetic[i].visible = false;
    }
}

Keyboard.prototype.show = function()
{
    var self = this;
    
    this._hideNumeric();
    this._showAlphabetic();
    
    if(tls.parent == null || tls.parent == undefined) return;
    
    this.visible = true;
    this.alpha = 1;
    
    console.log("por que não estou aqui")
    
    this.x = tls.base_width / 2 - this.width / 2;
    this.y = this.POS_Y;
    
    TweenMax.from(this, 0.5, {y: "+=" + 200, alpha: 0, onComplete: function(){
        for(var i = 0; i < self._keys.length; i++)
        {
            var k = self._keys[i];
            k.addEvents();
            k.on("clicked", function(e){
                self._clicked(e);
            });
        }
    }});
}

Keyboard.prototype.hide = function()
{
    var self = this;
    for(var i = 0; i < self._keys.length; i++)
    {
        var k = self._keys[i];
        k.removeEvents();
        k.removeListener("clicked");
    }
    console.log("inicio do hide")
    TweenMax.to(this, 0.3, {y: "+=" + 100, alpha: 0, onComplete: function(){
        self.visible = false;
        self.y = self.POS_Y;
    }});
}

Keyboard.prototype._clicked = function(e)
{
    var k = e.target;
    
    if(k.name == "numerico")
    {
        this._hideAlphabetic();
        this._showNumeric();
        
        return;
    }
    
    if(k.name == "alfabetico")
    {
        this._hideNumeric();
        this._showAlphabetic();
        
        return;
    }
    
    if(k.name == "espaco")
    {
        this.emit("keyPressed", {value: " "});
        return;
    }
    
    this.emit("keyPressed", {value: k.name});
}

tls.ui.Keyboard = Keyboard;