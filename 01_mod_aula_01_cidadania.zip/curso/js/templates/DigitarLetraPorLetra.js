function Tela()
{
    tls.core.Factory.call(this, "telas/004/sprite.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/004/4_1.mp3");
    this.soundManager.addSingleSound("telas/004/4_2.mp3");
    
    this.soundManager2 = new tls.media.SoundManager();
    this.soundManager2.addSingleSound("telas/004/4_3.mp3");
    this.soundManager2.addSingleSound("telas/004/4_4.mp3");
    
    this.dialogos;
    this.controller;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        var self = this;
        
        this.feedOkIndex = 0;
        this.bocaFeedOkIndex = 0;
        this.soundOkIndex = 1;
        
        this.keyboard = tls.display.Textures.KEYBOARD;
        this._layers.interactions.addChild(this.keyboard);
        
        this.controller = new tls.templates.WriteLetter(this.txGroup, this.soundManager2, this.keyboard);
        this.controller.corrects = [
            "POMBINHA BRANCA O QUE ESTA FAZENDO",
            "LAVANDO ROUPA PRO CASAMENTO"
        ];
        this.controller.upperCase = true;
        
        this.soundManager2.on("soundStart", function(){
            self.bocas[0].play();
        });
        
        this.soundManager2._onComplete = function(e){
            tls.media.SoundManager.prototype._onComplete.call(this, e);
            
            self.bocas[0].gotoAndStop(self.bocas[0].stationary);
        };
        
        this.init();
        
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;    
    
    console.log(this.bocas[0])
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0], 0);
    this.dialogos.on("preStart", function(e){
        
    });
    this.dialogos.on("start", function(e){
        console.log(e)
        if(e.atualIndex == 1 || e.atualIndex == 3) e.ballon.direction = "-";
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self.controller.open();
        self.controller.on("end", function(){
            self.setOk();
        });
    });    
    
    this.dialogos.play();
}

Tela.prototype.setOk = function()
{
    var self  = this;
    
    this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
        setTimeout(function(){
            self.emit("removeAll");
        }, 1000);            
    });      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    this.soundManager2.destroy();
    
    this.controller.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}