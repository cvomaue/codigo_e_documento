function Bucket(texture)
{
    BaseEspecialDrag.call(this, texture);
    
    var self = this;
    
    this._tintObjects = [];
}

Bucket.prototype = Object.create(BaseEspecialDrag.prototype);
Bucket.prototype.constructor = Bucket;

Object.defineProperties(Bucket.prototype, {
    tintObjects: {
        set: function(value){
            this._tintObjects = value;
        }
    }
})

Bucket.prototype._onDown = function(e)
{
    this._isMove = true;
        
    if(this.parent != null && this.parent)
    {
        var p = this.parent;
        p.setChildIndex(this, p.children.length - 1);
    }

    this._data = e.data;
    this._local = this._data.getLocalPosition(this);
}

Bucket.prototype._onUp = function(e)
{
    this._isMove = false;
    this._data = null;
    
    var gp = this.toGlobal(this._sensor.position);
    var p = new PIXI.Rectangle(gp.x, gp.y, this._sensor.width, this._sensor.height);

    for(var i = 0; i < this._tintObjects.length; i++)
    {
        var t = this._tintObjects[i];
        
        if(p.x + p.width > t.x &&
          p.x < t.x + t.width &&
          p.y + p.height > t.y &&
          p.y < t.y + t.height)
        {
            if(!t.lock)
                this.emit(t.type, {tintObject: t});
            
            break;
        }
    }
    
    TweenMax.to(this, 0.5, {x: this._initPos.x, y: this._initPos.y});
}

Bucket.prototype._onMove = function(e)
{
    if(this._isMove)
    {   
        var newPosition = this._data.getLocalPosition(this.parent);
        this.position.x = newPosition.x - this._local.x;
        this.position.y = newPosition.y - this._local.y;
    }
}

tls.display.Bucket = Bucket;