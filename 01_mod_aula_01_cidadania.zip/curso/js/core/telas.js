function Telas()
{
    var backLoader = new tls.loaders.HTMLTexture();
    var backComplete = false;
    var telas = [];
    var telaFim;
    
    var currentTela;
    var currentIndex = 0;
    
    var loading;
    
    var isEnd = false;
    
    function Constructor()
    {
        EventEmitter.call(this);
        
        loading = new Image();
        loading.src = 'imgs/loading.gif';
        loading.onload = function()
        {
            $(loading).offset({
                left: $(window).width() / 2 - $(loading).width() / 2,
                top: $(window).height() / 2 - $(loading).height() / 2
            });
        }
        
        $(loading).css({
            position: 'absolute' 
        });
    }
    
    Constructor.prototype = Object.create(EventEmitter.prototype);
    Constructor.prototype.constructor = Constructor;
    
    Object.defineProperties(Constructor.prototype, {
        length: {
            get: function(){
                return telas.length;
            }
        },
        
        isEnd: {
            get: function(){
                return isEnd;
            }
        }
    })
    
    Constructor.prototype.defineBackground = function(urls)
    {
        var self = this;

        backLoader.addMultiple(urls);
        backLoader.load();
        backLoader.on("complete", function(e){
            console.log("back complete");
            this.removeListener("complete");
            self.emit("backComplete");
            backComplete = true;
        });
    }
    
    Constructor.prototype.addTela = function(telaName, backIndex)
    {
        telas.push({name: telaName, back: backIndex});
    }
    
    Constructor.prototype.addTelaFim = function(telaName, backIndex)
    {
        telaFim = {name: telaName, back: backIndex};
    }
    
    Constructor.prototype.getTela = function(index)
    {
        if(index >= telas.length) return null;
        
        var oldIndex = currentIndex;
        currentIndex = index;
        if(currentIndex < 0)
        {
            isEnd = true;
            currentIndex = telas.length - 1;
            
            console.log("old index é o final..." + oldIndex);
            console.log("limite..." + (telas.length - 1));
            /*if(oldIndex == telas.length - 1)
            return;*/
        }
        else
        {
            isEnd = false;
        }
        
        var container = $("#curso");
        var old = container.find('.content');
        
        if(old.length == 0)
        {
            container.append(loading);            
            if(!backComplete)
            {
                this.on('backComplete', function(){
                    createTela(container, index);
                });
            }
            else
            {
                createTela(container, index);
            }
        }
        else
        {
            old.fadeOut(200, function(){
                container.empty();
                container.append(loading);
                resize();
                $(loading).show();
                
                createTela(container, index);
            });
        }
        
        return "ok";
    }
    
    function createTela(container, index)
    {
        var div = $(document.createElement('div'));
        div.addClass('content');
        
        currentTela = div;        
        
        var back;
        if(index >= 0)
            back = $(backLoader.getDOM()[telas[index].back]);
        else
        {            
            back = $(backLoader.getDOM()[telaFim.back]);
        }  
        back.css({
            width: '100%',
            height: '100%',
            position: 'absolute'
        });
        
        
        TweenMax.to(div, 0, {css: {opacity: 0}})
        
        var name;
        if(index >= 0)
            name = telas[index].name;
        else
            name = telaFim.name;
        
        div.load(name + '.html', function(){
            $(loading).fadeOut(100, function(){
            //setTimeout(function(){
                $(loading).remove();
                div.prepend(back);
                
                var content = div.find('div');
                content.css({
                    width: '100%',
                    height: '100%',
                    position: 'absolute'
                });
                
                container.append(div);
                
                TweenMax.to(div, 0.3, {css: {opacity: 1}});
                
                resize();
            });
        });  
        
    }
    
    Constructor.prototype.resize = resize;
    function resize(scale)
    {
        if(!currentTela) return;
        
        var parent = currentTela.parent();
        
        currentTela.width(parent.width());
        currentTela.height(parent.height());
        
        var canvas = currentTela.find('canvas');
        canvas.width(currentTela.width());
        canvas.height(currentTela.height());
        
        $(loading).css({
            left: $("#curso").width() / 2 - $(loading).width() / 2 + 'px',
            top: $("#curso").height() / 2 - $(loading).width() / 2 + 'px',
            position: 'absolute'
        });
        
       try{
           Main.stage.resize(scale);
       }
        catch(err){}
    }
    
    Constructor.prototype.getIndex = function()
    {
        return currentIndex;
    }
    
    Constructor.prototype.getBackground = function(index)
    {
        return $(backLoader.getDOM()[index]);
    }
    
    Constructor.prototype.getBackLenth = function()
    {
        return backLoader.getDOM().length;
    }
    
    return new Constructor();
}

var telas = new Telas();