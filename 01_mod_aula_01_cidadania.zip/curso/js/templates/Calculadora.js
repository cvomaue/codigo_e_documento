function Tela()
{
    tls.core.Factory.call(this, "telas/003/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/003/3_1.mp3");
    this.soundManager.addSingleSound("telas/003/3_2.mp3");
    this.soundManager.addSingleSound("telas/003/3_3.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 1;
        this.bocaFeedOkIndex = 0;
        this.soundOkIndex = 1;
        
        this.feedFailIndex = 1;
        this.bocaFeedFailIndex = 0;
        this.soundFailIndex = 1;
        
        this.init();
    });  
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    
    this.calc = new tls.templates.Calc(this);
    this.calc.corrects = [82, 81];
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0], 0);
    this.dialogos.on("preStart", function(e){
        if(e.atualIndex == 0 || e.atualIndex == 2)
            e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self.calc.addEvents();
        self.calc.on("correct", function(e){
            self.setOk();
        });
        
        self.calc.on("incorrect", function(e){
            self.setFail();
        });
    });    
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    
    this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
      for(var i = 0; i < self.feeds.length; i++)
        {
            if(self.feeds[i].type == tls.display.FeedObject.FAIL)
            {
                self.feeds[i].closeFeed();
            }
        }
        
        self.calc.addEvents();
    });
}

Tela.prototype.setOk = function()
{
    var self  = this;
    
    this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
        setTimeout(function(){
            self.emit("removeAll");
        }, 1000);            
    }); 
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    this.calc.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}