function Agulha(texture)
{
    BaseEspecialDrag.call(this, texture);
    
    this._bexigas = [];
    this._feeds = [];
    this._collisions = [];
}

Agulha.prototype = Object.create(BaseEspecialDrag.prototype);
Agulha.prototype.constructor = Agulha;

Object.defineProperties(Agulha.prototype, {
    bexigas: {
        set: function(value){
            this._bexigas = value;
            for(var i = 0; i < this._bexigas.length; i ++)
            {
                var b = this._bexigas[i];
                b.typeA = "bexiga";
                
                this._collisions.push(b);
                b.id = this._collisions.length - 1;
                
                var s = this._createCollisionSensor();
                s.alpha = 0;
                
                b.sensor = s;
                b.addChild(s);
            }
        }
    },
    
    feeds: {
        set: function(value){
            this._feeds = value;
            for(var i = 0; i < this._feeds.length; i ++)
            {
                var f = this._feeds[i];
                f.typeA = "feed";
                
                this._collisions.push(f);
                f.id = this._collisions.length - 1;
                
                var s = this._createCollisionSensor();
                s.y -= 20;
                s.alpha = 0;
                
                f.sensor = s;
                f.addChild(s);
            }
        }
    }
});

Agulha.prototype._onDown = function(e)
{
    this._isMove = true;
        
    if(this.parent != null && this.parent)
    {
        var p = this.parent;
        p.setChildIndex(this, p.children.length - 1);
    }

    this._data = e.data;
    this._local = this._data.getLocalPosition(this);
}

Agulha.prototype._onUp = function(e)
{
    this._isMove = false;
    this._data = null;

   /* for(var i = 0; i < this._tintObjects.length; i++)
    {
        var t = this._tintObjects[i];
        
        if(p.x + p.width > t.x &&
          p.x < t.x + t.width &&
          p.y + p.height > t.y &&
          p.y < t.y + t.height)
        {
            if(!t.lock)
                this.emit(t.type, {tintObject: t});
            
            break;
        }
    }*/
    
    TweenMax.to(this, 0.5, {x: this._initPos.x, y: this._initPos.y});
}

Agulha.prototype._onMove = function(e)
{
    if(this._isMove)
    {   
        var newPosition = this._data.getLocalPosition(this.parent);
        this.position.x = newPosition.x - this._local.x;
        this.position.y = newPosition.y - this._local.y;
        
        var gp = this.toGlobal(this._sensor.position);
        var p = new PIXI.Rectangle(gp.x, gp.y, this._sensor.width, this._sensor.height);
        

        for(var i = 0; i < this._collisions.length; i++)
        {
            var c = this._collisions[i];
            var cg = c.toGlobal(new PIXI.Point(c.sensor.x, c.sensor.y));
            
            if(p.x > cg.x - c.sensor.width / 2 &&
              p.x + p.width < cg.x + c.sensor.width / 2 &&
              p.y > cg.y - c.sensor.height / 2 &&
              p.y + p.height < cg.y + c.sensor.height / 2)
            {
                if(c.isLock) continue;
                if(c.typeA == "bexiga")
                {
                    c.isLock = true;
                    c.pow();
                    this._onUp();
                    this.emit('correct');
                    break;
                }
                else if(c.typeA == "feed")
                {
                    c.openFeed();
                    setTimeout(function(){
                        c.closeFeed();
                    }, 500);
                    this._onUp();
                    this.emit('incorrect');
                    break;
                }
            }
        }
    }
}

Agulha.prototype._createCollisionSensor = function()
{
    var sensor = new PIXI.Graphics();
    sensor.beginFill(0xff0000);
    sensor.drawEllipse(0, 0, 84 / 2, 108 / 2);
    sensor.endFill();
    
    return sensor;
}

tls.display.Agulha = Agulha;