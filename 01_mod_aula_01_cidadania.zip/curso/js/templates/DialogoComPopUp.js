function Tela()
{
    tls.core.Factory.call(this, "telas/002_b/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/002_b/2b_1.mp3");
    this.soundManager.addSingleSound("telas/002_b/2b_2.mp3");
    this.soundManager.addSingleSound("telas/002_b/2b_3.mp3");
    this.soundManager.addSingleSound("telas/002_b/2b_4.mp3");
    this.soundManager.addSingleSound("telas/002_b/2b_5.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.on("complete", function(){
        this.removeListener("complete");
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    
    var tx = new tls.loaders.HTMLTexture();
    this.tx = tx;
    tx.add("telas/002_b/014.png");
    tx.load();
    
    this.pop = new tls.display.PopUp(new PIXI.Sprite(tx.getTextures()[0]));
    this.pop.setAudio(this.soundManager, 4);
    this.addChild(this.pop);
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0, 1, 0, 2]);
    this.dialogos.on("preStart", function(e){
        if(e.atualIndex != 1)
            e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self.star = self.stars[0];
        self.star.animate();
        self.star.addEvents();
        self.star.on("clicked", function(e){
            this.removeListener("clicked");
            
            self.pop.open();
            self.pop.on("closed", function(){
                self.emit("removeAll");
            });
        });
    });    
    
    this.dialogos.play();
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    for(var i = 0; i < this.clicks.length; i++)
        this.clicks[i].destroy();
    
    for(var i = 0; i < this.stars.length; i++)
        this.stars[i].destroy();
    
    for(var i = 0; i < this.icons.length; i++)
        this.icons[i].destroy();
    
    this.pop.destroy();
    
    this.tx.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}