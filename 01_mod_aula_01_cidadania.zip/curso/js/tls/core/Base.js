/**
* Classe base para todos os objetos
* Extende da classe PIXI.Container
* possui métodos de animação como abrir e fechar em fade
* e animação do tipo pulso
*
* @class
* @extends PIXI.Container
* @memberof tls.core
*/
function Base()
{
    PIXI.Container.call(this);
    
    /**
    * Define o tempo para todas as animações (em segundos)
    *
    * ```js
    * var a = new  AnimateButton(texture);
    * a.timeAnimation = 2;
    *
    * var area = new AreaButton(_w, _h);
    * area.addIcon();
    * area.icon.timeAnimation = 0.3;
    * ```
    *
    * @member {number}
    * @default 0.5
    * @public
    */
    this.timeAnimation = 0.5;
    
    /**
    * Define a distância do deslocamento nas animações de movimento (em pixels)
    *
    * @member {number}
    * @default 100
    * @public
    */
    this.moveSize = 100;
    
    /**
    * Armazena a escala inicial
    * 
    * @member {PIXI.Point}
    * @private
    */
    this._initSize = new PIXI.Point(this.scale.x, this.scale.y);
}

Base.prototype = Object.create(PIXI.Container.prototype);
Base.prototype.constructor = Base;

/**
* Faz uma animação de fade em alpha de 0 para 1
* necessário antes setar o alpha do objeto para 0
*
* @memberof Base
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Base.prototype.openWithFade = function(onComplete, onCompleteParams)
{
    TweenMax.to(this, this.timeAnimation, {alpha: 1, onComplete: onComplete, onCompleteParams: onCompleteParams});
}

/**
* Faz uma animação de fade em alpha de 1 para 0
*
* @memberof AnimateButton
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Base.prototype.closeWithFade = function(onComplete, onCompleteParams)
{
    TweenMax.to(this, this.timeAnimation, {alpha: 0, onComplete: onComplete, onCompleteParams: onCompleteParams});
}

/**
* Faz uma animação de fade em alpha de 0 para 1
* execultando um movimento baseado na direção especificada
*
* @memberof Base
* @param [direction='+'] {string} define a direção do movimento ('+', '-')
* '+' da direita para a esquerda - '-' da esquerda para a direira
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Base.prototype.openWithMove = function(direction, onComplete, onCompleteParams)
{
    var opost = direction === "+" ? "-" : "+";
    TweenMax.fromTo(this, this.timeAnimation,
                    {
        x: opost + "=" + this.moveSize
    },
                    {
        x: direction + "=" + this.moveSize,
        alpha: 1,
        ease: Bounce.easeOut,
        onComplete: onComplete,
        onCompleteParams: onCompleteParams
    });
}

/**
* Faz uma animação de fade em alpha de 1 para 0
* execultando um movimento baseado na direção especificada
*
* @memberof Base
* @param [direction='+'] {string} define a direção do movimento ('+', '-')
* '+' da direita para a esquerda - '-' da esquerda para a direira
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Base.prototype.closeWithMove = function(direction, onComplete, onCompleteParams)
{
    TweenMax.to(this, this.timeAnimation,
                    {
        x: direction + "=" + this.moveSize,
        alpha: 0,
        ease: Bounce.easeOut,
        onComplete: onComplete,
        onCompleteParams: onCompleteParams
    });
}

/**
* Faz uma animação de scale
* necessário definir um scale inicial
* a animação vai do scale definido para a posição inicial de criação
*
* @memberof Base
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Base.prototype.openWithScale = function(onComplete, onCompleteParams)
{
    TweenMax.to(this.scale, this.timeAnimation, {
        x: this._initSize.x,
        y: this._initSize.y,
        onComplete: onComplete,
        onCompleteParams: onCompleteParams
    });
}

/**
* Faz uma animação de scale para 0
*
*
* @memberof Base
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Base.prototype.closeWithScale = function(onComplete, onCompleteParams)
{
    TweenMax.to(this.scale, this.timeAnimation, {
        x: 0,
        y: 0,
        onComplete: onComplete,
        onCompleteParams: onCompleteParams
    });
}

/**
* Faz uma animação constante por tempo indeterminado em scale no formato de uma pulsação
*
* @memberof Base
* @param [time=0.5] {number} tempo de meio pulso, a animação completa dura o dobro de time
* @public
*/
Base.prototype.animate = function(time)
{
    this._initSize = new PIXI.Point(this.scale.x, this.scale.y);
    var t = time || 0.5;
    
    TweenMax.to(this.scale, t, {x: "-=0.2", y: "-=0.2", yoyo: true, repeat: -1});
}

/**
* Pára a animação de pulso
*
* @memberof Base
* @public
*/
Base.prototype.stopAnimation = function()
{
    TweenMax.killTweensOf(this.scale);
    
    this.scale.set(this._initSize.x, this._initSize.y);
}

/**
* Suporte para limpar a memória
* destroi todos os objetos e remove os eventos
*
* @memberof Base
* @public
*/
Base.prototype.destroy = function()
{
    if(this.parent != null && this.parent != undefined)
    {
        var p = this.parent;
        p.removeChild(this);
    }
    
    this.stopAnimation();
    TweenMax.killTweensOf(this);
    
    PIXI.Container.prototype.destroy.call(this);
}

tls.Base = Base;