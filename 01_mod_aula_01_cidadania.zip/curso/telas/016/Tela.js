function Tela()
{
    tls.core.Factory.call(this, "telas/016/sprites.json");
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/016/16_1.mp3");
    this.soundManager.addSingleSound("telas/016/16_2.mp3");
    
    this.dialogos;
    this.arrPos = [
        
        new PIXI.Point(678,329),  //0
        new PIXI.Point(397,291),  //1
        new PIXI.Point(770,332),  //2
        new PIXI.Point(480,340),//3
        new PIXI.Point(685,275),  //4
        new PIXI.Point(469,354),  //5
        
            
    ]
    
    this.correct = 0;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 1;
        this.feedFailIndex = 3;
        this.bocaFeedOkIndex = 0;
        this.bocaFeedFailIndex = 0;
        this.soundOkIndex = this.soundManager._sounds.length-1;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;    
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("end", function(e){
        console.log(self.areaDrags)
        this.removeListener("end");
        
        self.addDragsEvents();
    });
    
    this.configureDrags();
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    self.removeDragsEvents();  
    
    //this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.feedFailIndex, function(){
    setTimeout(function(){
        self.addDragsEvents();        
    }, 650);
    //});
}

Tela.prototype.setOk = function()
{
    var self  = this;
    self.removeDragsEvents();  
    
    self.correct++;

    if(self.correct >= 6)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);                
        });

        return;
    }

    self.addDragsEvents();        
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    this.removeDragsEvents();
    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound);  
}

controlY = 0;
rh = 0;
/*Drag.prototype._adjust = function()
{
    console.log(controlY);
    var r = this._collisions[this._index];
    rh = (rh == 0) ? r.height / 3 : rh;
    controlY = (controlY == 0) ? r.y + 50 : controlY;
    TweenMax.to(this.position, 0.5, {x: r.x + r.width / 2, y: controlY, ease: Back.easeOut});
    controlY += rh;
}
*/
Tela.prototype.configureDrags = function()
{
    var self = this;
    
    
    self.drags[0].collisions = [self.areaDrags[1]];
    self.drags[1].collisions = [self.areaDrags[0]];
    self.drags[2].collisions = [self.areaDrags[1]];
    self.drags[3].collisions = [self.areaDrags[0]];
    self.drags[4].collisions = [self.areaDrags[1]];
    self.drags[5].collisions = [self.areaDrags[0]];
        
    
    for(var i = 0; i < self.drags.length; i++)
    {
      
        self.drags[i].id = i;
        self.drags[i].usePoint = true;
        self.drags[i].adjust = false;        
        
        self.drags[i].on("incorrect", function(e){
            self.setFail();
        });

        self.drags[i].on("correct", function(e){
            this.removeListener("correct");
            
            var t = this;
                TweenMax.to(this,0.2,{
                    x: self.arrPos[t.id].x+t.width/2,
                    y: self.arrPos[t.id].y+t.height/2
                });    
            
            self.setOk();
        });
    }
}

Tela.prototype.addDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].addEvents();
    }
}

Tela.prototype.removeDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].removeEvents();
    }
}

Tela.prototype.destroy = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].destroy();
    }
    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}