function BaseEspecialDrag(texture)
{
    Base.call(this);
    
    var self = this;
    
    this._img = new PIXI.Sprite(texture);
    this._sensor = new PIXI.Graphics();
    var s = this._sensor;
    s.lineStyle(2, 0xff0000, 1);
    s.beginFill(0xffffff, 0);
    s.drawRect(0, 0, 20, 20);
    s.endFill();
    
    this.addChild(this._img);
    this.addChild(this._sensor);
    
    this._isMove;
    this._data;
    this._initPos;
    
    this._addedToStage = setInterval(function(){
        if(self.parent != null && self.parent != undefined)
        {
            clearInterval(self._addedToStage);
            
            self._initPos = new PIXI.Point(self.x, self.y);
        }
    }, 100);
}

BaseEspecialDrag.prototype = Object.create(Base.prototype);
BaseEspecialDrag.prototype.constructor = BaseEspecialDrag;

Object.defineProperties(BaseEspecialDrag.prototype, {
    debug: {
        set: function(value)
        {
            if(value) this._sensor.alpha = 1;
            else this._sensor.alpha = 0;
        }
    },
    //Anselmo - posição x do sensor
    possensorx: {
        set: function(value)
        {
            if(!value) this._sensor.x = 0;
            else this._sensor.x = value;
        }
    },
    //Anselmo - posição y do sensor
    possensory: {
        set: function(value)
        {
            if(!value) this._sensor.y = 0;
            else this._sensor.y = value;
        }
    },
});

BaseEspecialDrag.prototype.addEvents = function()
{
    this.interactive = true;
    this.buttonMode = true;
    
    this
        .on('mousedown', this._onDown)
        .on('touchstart', this._onDown)

        .on('mouseup', this._onUp)
        .on('touchend', this._onUp)
        .on('mouseupoutside', this._onUp)
        .on('touchendoutside', this._onUp)
    
        .on('mousemove', this._onMove)
        .on('touchmove', this._onMove);
}

BaseEspecialDrag.prototype.removeEvents = function()
{
    this.interactive = false;
    this.buttonMode = false;
    
    this
        .removeListener('mousedown', this._onDown)
        .removeListener('touchstart', this._onDown)

        .removeListener('mouseup', this._onUp)
        .removeListener('touchend', this._onUp)
        .removeListener('mouseupoutside', this._onUp)
        .removeListener('touchendoutside', this._onUp)
    
        .removeListener('mousemove', this._onMove)
        .removeListener('touchmove', this._onMove);
}

BaseEspecialDrag.prototype._onDown = function(e)
{
    
}

BaseEspecialDrag.prototype._onMove = function(e)
{
    
}

BaseEspecialDrag.prototype._onUp = function(e)
{
    
}