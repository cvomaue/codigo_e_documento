function PopUp(content)
{
    Base.call(this);
    
    var self = this;
    
    this._content = content;
    this._back = new PIXI.Sprite(tls.display.Textures.BACK_POPUP);
    this._back.alpha = .9;
    this._close = new AnimateButton(tls.display.Textures.FECHAR);
    
    this._groupSound = false;
    this._sm;
    this._soundIndex;
    
    var enterframe = setInterval(function(){
        if(self._content.width > 10 && self._content.height > 10)
        {
            clearInterval(enterframe);
            
            self._content.x = self._back.width / 2 - self._content.width / 2;
            self._content.y = self._back.height / 2 - self._content.height / 2;
            
            self._close.x = self._content.x +  self._content.width - self._close.width / 2;
            self._close.y = self._content.y + self._close.height / 2;
        }
    }, 100);
    
    this.addChild(this._back);
    this.addChild(this._content);
    this.addChild(this._close);
    
    this.pivot.set(this._back.width / 2, this._back.height / 2);
    this.scale.set(0);
    
    this.x = this._back.width / 2;
    this.y = this._back.height / 2;
}

PopUp.prototype = Object.create(Base.prototype);
PopUp.prototype.constructor = PopUp;

PopUp.prototype.setAudio = function(soundManager, index, group)
{
    this._groupSound = group || false;
    this._sm = soundManager;
    this._soundIdex = index;
}

PopUp.prototype.open = function(onComplete, onCompleteParams)
{
    var self = this;
    
    this.openWithScale(function(){
        self._close.on("clicked", function(e){
            this.removeListener();
            this.removeEvents();
            
            self.close();
        });
        
        console.log(self._close)
        self._close.addEvents();
        
        if(onComplete != null && onComplete != undefined) onComplete.apply(onCompleteParams);
        
        self.emit("opened");
    });
    
    if(this._sm == null || this._sm == undefined) return;
    
    this._sm.AutorizeSounds();
    
    if(this._groupSound) this._sm.playMultiple(this._soundIdex);
    else this._sm.playSound(this._soundIdex);
}

PopUp.prototype.close = function(onComplete, onCompleteParams)
{    
    var self = this;
    
    this.closeWithScale(function(){
        self.emit("closed");
        
        if(onComplete != null && onComplete != undefined) onComplete.apply(onCompleteParams);
    });
    
    if(this._sm == null || this._sm == undefined) return;
    
    this._sm.stop();
}

PopUp.prototype.destroy = function()
{
    this.removeChildren();
    this._back.destroy();
    
    try{
        this._content.destroy();
    }
    catch(err){}
    
    this._close.destroy();
    
    this._back = null;
    this._close = null;
    this._content = null;
    
    this.removeAllListeners();
    
    Base.prototype.destroy.call(this);
}

tls.display.PopUp = PopUp;

