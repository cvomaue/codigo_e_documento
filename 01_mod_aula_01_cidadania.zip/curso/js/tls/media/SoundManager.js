function SoundManager()
{
    EventEmitter.call(this);
    
    this._initialized = false;
    
    this._sounds = [];
    this._groups = [];
    
    this._countSequence = 0;
}

SoundManager.prototype = Object.create(EventEmitter.prototype);
SoundManager.prototype.constructor = SoundManager;

SoundManager.prototype.addSingleSound = function(url)
{
    var s = new buzz.sound(url);
    this._sounds.push(s);
    s.id = this._sounds.length - 1;
    
    return s.id;
}

SoundManager.prototype.addMultipleSound = function(urls)
{
    var temp = [];
    for(var i = 0; i < urls.length; i++)
    {
        var s = new buzz.sound(); 
        temp.push(s);
    }
    
    var g = new buzz.group(temp);
    this._groups.push(g);    
    g.id = this._groups.length - 1;
    
    return g.id;
}

SoundManager.prototype.playSound = function(index)
{    
    buzz.all().stop();
    
    var sound = this._sounds[index];
    var self = this;
    
    sound.bind("playing", function(e)
               {
        this.unbind("playing");
        self._onStart(e);
    });
    sound.bind("ended", function(e)
               {
        this.unbind("ended");
        self._onComplete(e);
    });
    sound.play();   
}

SoundManager.prototype.playMultiple = function(index)
{
    buzz.all().stop();
    
    var g = this._groups[index];
    this._countSequence = 0;
    
    this._sequence(g);
}

SoundManager.prototype.stop = function()
{
    buzz.all().stop();
}

SoundManager.prototype._sequence = function(g)
{
    var self = this;
    
    var a = g[self._countSequence];
    a.bind("ended", function(e)
           {
        this.unbind("ended");
        self._countSequence++;
        if(self._countSequence >= g.length)
        {
            self.emit("sequenceComplete");
            return;
        }
        self._sequence(g);
    });
    a.play();
}

SoundManager.prototype.AutorizeSounds = function()
{
    if(!this._initialized)
    {
        for(var i = 0; i < this._sounds.length; i++)
        {
            var s = this._sounds[i];
            this._autorize(s);
        }
        
        for(i = 0; i < this._groups.length; i++)
        {
            var g = this._groups[i];
            this._autorize(g);
        }
    }
    
    this._initialized = true;
}

SoundManager.prototype._autorize = function(soundObj)
{
    soundObj.mute();
    soundObj.play();
    soundObj.stop();
    soundObj.unmute();
}

SoundManager.prototype._onStart = function(e)
{
    this.emit("soundStart", e);
}

SoundManager.prototype._onComplete = function(e)
{
    this.emit("soundComplete", e);
}

SoundManager.prototype.destroy = function()
{
    buzz.all().stop();
        
    for(var i = 0; i < buzz.sounds.length; i++)
    {
        var s = buzz.sounds[i];
        s.unbind("playing");
        s.unbind("ended");
        s.sound.src = "";
        s.sound = null;
        
        s = null;
    }

    buzz.sounds.splice(0, buzz.sounds.length);
    this._sounds.splice(0, this._sounds.length);
    this._groups.splice(0, this._groups.length);
    
    this._countSequence = 0;
    this._initialized = false;
    
    this.removeAllListeners();
}

tls.media.SoundManager = SoundManager;