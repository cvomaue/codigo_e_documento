function Tela()
{
    tls.core.Factory.call(this, "telas/011/sprites.json");
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/011/11_1.mp3");
    this.soundManager.addSingleSound("telas/011/11_2.mp3");
    this.soundManager.addSingleSound("telas/011/11_3.mp3");
    this.soundManager.addSingleSound("telas/011/11_4.mp3");
    this.soundManager.addSingleSound("telas/011/11_5.mp3");
    this.soundManager.addSingleSound("telas/011/11_6.mp3");
    this.soundManager.addSingleSound("telas/011/11_7.mp3");
    this.soundManager.addSingleSound("telas/011/11_8.mp3");
    this.soundManager.addSingleSound("telas/011/11_9.mp3");
    this.soundManager.addSingleSound("telas/011/11_10.mp3");
    
    this.dialogos;
    
    this.correct = 0;
    
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 1;
        //this.feedFailIndex = 1;
        this.bocaFeedOkIndex = 0;
        //this.bocaFeedFailIndex = 0;
        this.soundOkIndex = this.soundManager._sounds.length-1;
        //this.soundFailIndex = 4;
        
        this.totalCorrects = this.lines.length;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;    
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("end", function(e){
        this.removeListener("end");
        
        for(i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i );
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }
        
        
        for(var i = 0; i < self.lines.length; i++)
        {
            self.lines[i].addEvents();
            self.lines[i].on("correct", function(e){
                self.setOk();
            });
            
            self.lines[i].on("incorrect", function(e){
                
            });
        }
    });
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    
    this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
        self.addFeedsEvents();
        
        for(var i = 0; i < self.feeds.length; i++)
        {
            if(self.feeds[i].type == tls.display.FeedObject.FAIL)
            {
                self.feeds[i].closeFeed();
            }
        }
    });
}

Tela.prototype.setOk = function()
{
    var self  = this;
    
        self.correct++;
        
        if(self.correct >= self.totalCorrects)
        {
            this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);
            
            return;
            });   
        }     
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    var b = this.ballons[indexBallon];
    //b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    for(var i = 0; i < this.lines.length; i++)
    {
        this.lines[i].destroy();
    }
    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}