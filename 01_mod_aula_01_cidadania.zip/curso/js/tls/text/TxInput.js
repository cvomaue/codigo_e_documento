function TxInput(size, maxChars, theme)
{
    PIXI.Container.call(this);
    
    var self = this;
    
    this._size = size;
    this._theme = theme;
    this._maxChars = maxChars;
    this._field = new CustomInput("abc", this._size.height - 2);
    this._field.maxChars = this._maxChars;
    //this._field.text = "";
    this._field.pixiText.x = 10;
    this._field.height = this._size.height;
    this._field.interactive = false;
    
    this._styleFail = {"font": (this._size.height - 2) + "px Angola",fill: "#a21818", stroke: "#a21818", strokeThickness: 3};
    this._styleOk = {"font": (this._size.height - 2) + "px Angola", fill: "#1ba218", stroke: "#1ba218", strokeThickness: 3};
    
    this._feed = new PIXI.Text(this._field.text, this._theme.textStyle);
    this._feed.x = this._field.pixiText.x;
    this._feed.style = this._styleFail;
    this._feed.alpha = 0;
    
    this._field.x = this._feed.width / 2 - this._field.pixiText.width / 2
    this._field.y = this._feed.height / 2 - this._field.height / 2;
    
    this._field.text = "";
    this._feed.text = "";
    
    this._field.focushandler = function(){
       // GOWN.TextInput.prototype.onfocus.call(this);
        self.emit("focus");
    }
    
    this._field.onblur = function(){
        GOWN.TextInput.prototype.onblur.call(this);
        
        self.emit("blur");
    }
    
    this._field.onKeyUp = function(){
        GOWN.TextInput.prototype.onKeyUp.call(this);
        
        self.emit("textUpdate");
    }
    
    this._bg = new GOWN.Rect(0xcccccc, 0, this._size.width, this._size.height); 
    this._bg.alpha = 0;
    
    this.addChild(this._bg);
    this.addChild(this._feed);
    this.addChild(this._field);
}

TxInput.prototype = Object.create(PIXI.Container.prototype);
TxInput.prototype.constructor = TxInput;

Object.defineProperties(TxInput.prototype, {
    text: {
        get: function(){
            return this._field.text;
        },
        set: function(value){
            this._field.text = value;
        }
    },
    
    maxChars: {
        get: function(){
            return this._maxChars;
        }
    }, 
    
    debug: {
        set: function(value){
            if(value) this._bg.alpha = 1;
            else this._bg.alpha = 0;
        }
    }
});

TxInput.prototype.openFeed = function(type)
{
    var style;
    
    switch(type)
    {
        case "ok":
            style = this._styleOk;
            break;
        case "fail":
            style = this._styleFail;
            break;
    }
    
    this._feed.style = style;
    this._feed.text = this._field.text;
    
    TweenMax.to(this._feed, 0.3, {alpha: 1});
}

TxInput.prototype.closeFeed = function()
{
    TweenMax.to(this._feed, 0.3, {alpha: 0});
}

TxInput.prototype.addEvents = function()
{
    this._bg.interactive = true;
    this._bg
        .on('mousedown', this._onDown)
        .on('touchstart', this._onDown);
}

TxInput.prototype.removeEvents = function()
{
    this._bg.interactive = false;
    this._bg
        .removeListener('mousedown', this._onDown)
        .removeListener('touchstart', this._onDown);    
}

TxInput.prototype.focus = function()
{
    this._field.focus();
}

TxInput.prototype.blur = function()
{
    this._field.blur();
}

TxInput.prototype._onDown = function(e)
{
    var self = e.target.parent;
    
    self.focus();
}

TxInput.prototype.destroy = function()
{
    GOWN.InputControl.blur();
    this.removeChildren();
    this.removeEvents()
    this.removeAllListeners();
    
    this._feed.destroy
    this._field.destroy();
    this._bg.destroy();
    this._theme = null;
    this._feed = null;
    this._field = null;
    this._bg = null;
    
    PIXI.Container.prototype.destroy.call(this);
}


tls.text.TxInput = TxInput;