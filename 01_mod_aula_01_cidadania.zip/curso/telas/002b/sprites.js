{
"frames": {
	"audio00.png": {
		"frame": {"x":0, "y":777, "w":61, "h":59},
		"spriteSourceSize": {"x":528,"y":197,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"audio01.png": {
		"frame": {"x":0, "y":777, "w":61, "h":59},
		"spriteSourceSize": {"x":299,"y":185,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"balao01.png": {
		"frame": {"x":0, "y":0, "w":374, "h":159},
		"spriteSourceSize": {"x":353,"y":140,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"balaoE00.png": {
		"frame": {"x":0, "y":161, "w":338, "h":139},
		"spriteSourceSize": {"x":264,"y":166,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"boca00.png": {
		"frame": {"x":0, "y":838, "w":31, "h":22},
		"spriteSourceSize": {"x":179,"y":297,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"boca01.png": {
		"frame": {"x":0, "y":838, "w":31, "h":22},
		"spriteSourceSize": {"x":780,"y":299,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"click00.png": {
		"frame": {"x":0, "y":715, "w":61, "h":60},
		"spriteSourceSize": {"x":487,"y":134,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"img00.png": {
		"frame": {"x":0, "y":415, "w":188, "h":298},
		"spriteSourceSize": {"x":102,"y":224,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"img01.png": {
		"frame": {"x":190, "y":415, "w":181, "h":313},
		"spriteSourceSize": {"x":705,"y":211,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"img02.png": {
		"frame": {"x":0, "y":302, "w":329, "h":111},
		"spriteSourceSize": {"x":336,"y":115,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	}

},
"meta": {
	"image": "sprites.png",
	"size": {"w": 512, "h": 1024},
	"scale": "1"
}
}