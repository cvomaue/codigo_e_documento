/**
* Classe que representa o balão
* manipula a imagem de texto e o audio
*
* @class
* @extends tls.core.Base
* @memberof tls.display
* @param texture {PIXI.Texture} textura que representa a imagem do balão
*/
function Ballon(texture)
{
    Base.call(this);
    
    /**
    * imagem com base na textura
    *
    * @menber {PIXI.Sprite}
    * @private
    */
    this._img = new PIXI.Sprite(texture);
    this.addChild(this._img);
    
    //define o alpha inicial para 0;
    this.alpha = 0;
    this.visible = false;
    
    /**
    * o botão de áudio se houver
    *
    * @member {tls.buttons.AudioButton}
    * @private
    */
    this._audioButton;
    // index para o som
    this._audioButtonPosition;
    
    /**
    * direção da abertura do balão
    * por padrão a direção vai da esquerda para a direita
    *
    * @member {string}
    * @default "+"
    * @private
    */
    this._direction = "+";
    
    /**
    * Objeto que controla o audio sem o botão
    *
    * @member {tls.media.SoundManager}
    * @private
    */
    this._soundManager;
    
    /**
    * indice do som referente ao tls.media.SoundManager
    *
    * @member {number}
    * @private
    */
    this._indexSound;
    
    /**
    * tipo do balão
    *
    * @member {string}
    * @default "normal"
    * @private
    */
    this._type = "normal";
    
    /**
    * para verificar se o som está tocando
    *
    * @member {boolean}
    * @default false
    * @private
    */
    this._playing = false;
    
    /**
    * Disparado quando começa a tocar o audio
    *
    * @event soundStart
    * @menberof Ballon#
    */
    
    /**
    * Disparado quando termina de tocar o audio
    *
    * @event soundComplete
    * @memberof Ballon#
    */
}

Ballon.prototype = Object.create(Base.prototype);
Ballon.prototype.constructor = Ballon;

Object.defineProperties(Ballon.prototype, {
    /**
    * direção do balão
    *
    * @member {string}
    * @public
    */
    direction: {
        get: function()
        {
            return this._direction;
        },
        set : function(value)
        {
            this._direction = value;
        }
    },
    
    /**
    * tipo do balão: especial (exercícios), normal
    * 
    * @member {string}
    * @public
    */
    type: {
        get: function()
        {
            return this._type;
        },
        set: function(value)
        {
            this._type = value;
        }
    },
    
    x: {
        get: function()
        {
            return this.position.x;
        },
        set: function(value)
        {
            this.position.x = value;
            
            if(this._audioButton != undefined && this._audioButton != null)
            {
                this._audioButton.x = value + this._audioButtonPosition.x;
            }
        }
    },
    
    y: {
        get: function()
        {
            return this.position.y;   
        },
        set: function(value)
        {
            this.position.y = value;
            
            if(this._audioButton != undefined && this._audioButton != null)
            {
                this._audioButton.y = value + this._audioButtonPosition.y;
            }
        }
    }
});

/**
* Método para abrir o balão
* torna o balão visivel e faz uma animação de entrada dependendo da direção
*
* @memberof Ballon
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Ballon.prototype.open = function(onComplete, onCompleteParams)
{
    var self = this;
    
    //torna visivel
    this.visible = true;
    
    //abre
    this.openWithMove(this.direction, onComplete, onCompleteParams);
    
    //Se tiver o botão de audio
    if(this._audioButton != undefined && this._audioButton != null)
    {
        this._audioButton.open(function(){
            self._audioButton.animate();
            self._audioButton.addEvents();
            self._handlerAudio(self._audioButton);
        });
    }
    
    //Se tiver o soundManager
    if(this._soundManager != null && this._soundManager != undefined)
    {
        this._handlerAudio(this._soundManager);
        
        this._soundManager.playSound(this._indexSound);
    }
    
    //se não tiver o botão de audio, mas tivever o soundmanager e for especial
    if((this._audioButton == undefined || this._audioButton == null) &&
      (this._soundManager != null && this._soundManager != undefined) &&
      this._type == "especial")
    {
        this.interactive = true;
        this.on("mousedown", onDown);
        this.on("touchstart", onDown);
        
        function onDown(e){
            if(!self._playing)
            {
               self._soundManager.playSound(self._indexSound);
            }
        }
    }
}

/**
* Suporte para manipulação do audio
*
* @memberof Ballon
* @param soundObject {[object, {tls.buttons.AudioButton}, {tls.media.SoundManager}]}
* @fires soundStart
* @fires soundComplete
* @private
*/
Ballon.prototype._handlerAudio = function(soundObject)
{
    var self = this;
    
    soundObject.on("soundStart", function(e){
        self._playing = true;
        self.emit("soundStart", e);
    });
    soundObject.on("soundComplete", function(e){
        self._playing = false;
        self.emit("soundComplete", e);        
    });
}

/**
* Método para encerrar o balão. Fecha os audios e cria uma animação
* em fade que vai de 1 a 0
*
* @memberof Ballon
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
Ballon.prototype.close = function(onComplete, onCompleteParams)
{
    var self = this;
    
    //fica invisível no final da animação
    var complete = function()
    {
        self.visible = false;
        
        if(onComplete != null && onComplete != undefined) 
            onComplete.apply(this, onCompleteParams);
    }
    
    //se tiver botão de audio, fecha o botão
    if(this._audioButton != undefined && this._audioButton != null)
        this._audioButton.closeWithFade();
    
    // se tiver o SoudManager, fecha o objeto
    if(this._soundManager != undefined && this._soundManager != null)
        this._soundManager.stop();
    
    //encerra as atividades
    this.closeWithFade(complete);
}

/**
* adiciona o botão de audio
*
* @memberof Ballon
* @param audioButton {tls.buttons.AudioButton} 
* @public
*/
Ballon.prototype.setAudioButton = function(audioButton)
{
    this._audioButton = audioButton;
    this._audioButtonPosition = new PIXI.Point(audioButton.position.x - this.position.x, audioButton.position.y - this.position.y);
    this._audioButton.alpha = 0;
}

/**
* Adiciona o objeto tls.media.SoundManager para controlar o áudio sem o botão
* 
* @memberof Ballon
* @param soundManager {tls.media.SoundManager} objeto que controla os áudios
* @param index {number} indice do som referente ao objeto SoundManager
* @public
*/
Ballon.prototype.setSoundManager = function(soundManager, index)
{
    this._soundManager = soundManager;
    this._indexSound = index;
}

/**
* Método que destroi os objetos e limpa a memória
*/
Ballon.prototype.destroy = function()
{
    this.removeChild(this._img);
    this._img.destroy();
    this._img = null;
    
    this._audioButton = null;
    this._audioButtonPosition = null;
    
    Base.prototype.destroy.call(this);
}

Ballon.ESPECIAL = "especial";
Ballon.NORMAL = "normal";

tls.display.Ballon = Ballon;