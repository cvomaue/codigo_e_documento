function Textures()
{
    EventEmitter.call(this);
    
    var self = this;
    this._txloader = new HTMLTexture();
    this._bocaSource;
    this._frameBocaConfig = [];
    this._bocaGatoSource;
    this._frameBocaGatoConfig = [];
    this._isComplete = false;
    
    this._keyboardSource; 
    this._keyboardConfig = [];
    this._keyboard;
    
    this._paintSource;
    this._paintConfig = [];
    this._paint;
    
    this._bexigaSource = [];
    this._bexigaConfig = [];
    this._bexiga;
    
    this._txloader.addMultiple([
        "telas/comum/audio.png",
        "telas/comum/click.png",
        "telas/comum/backPopup.png",
        "telas/comum/fechar.png",
        "telas/comum/cardClose.png"
    ]);
    this._txloader.on("complete", function(e){
        this.removeListener(e);
        
        PIXI.loader
            .add("boca", "telas/comum/boca/boca.json")
            .add("bocaGato", "telas/comum/bocaGato/bocaGato.json")
            .add("keyboard", "telas/comum/teclado/teclado.json")
            .add("paint", "telas/comum/paint/paint.json")
            .add("bexiga", "telas/comum/bexiga/bexiga.json")
            .load(function(loader, r){
            self._bocaSource = r.boca_image.data;
            self._bocaGatoSource = r.bocaGato_image.data;
            
            self._keyboardSource = r.keyboard_image.data;
            
            self._paintSource = r.paint_image.data;
            
            self._bexigaSource = r.bexiga_image.data;
            
            Object.keys(r.boca.textures).forEach(function(i, count){
                self._frameBocaConfig[count] = {
                    crop: {
                        x: r.boca.textures[i].crop.x,
                        y: r.boca.textures[i].crop.y,
                        width: r.boca.textures[i].crop.width,
                        height: r.boca.textures[i].crop.height,
                        type: r.boca.textures[i].crop.type
                    }/*,
                    trim: {
                        x: r.boca.textures[i].trim.x,
                        y: r.boca.textures[i].trim.y,
                        width: r.boca.textures[i].trim.width,
                        height: r.boca.textures[i].trim.height,
                        type: r.boca.textures[i].trim.type
                    }*/
                }
            });
            
            Object.keys(r.bocaGato.textures).forEach(function(i, count){
                self._frameBocaGatoConfig[count] = {
                    crop: {
                        x: r.bocaGato.textures[i].crop.x,
                        y: r.bocaGato.textures[i].crop.y,
                        width: r.bocaGato.textures[i].crop.width,
                        height: r.bocaGato.textures[i].crop.height,
                        type: r.bocaGato.textures[i].crop.type
                    }/*,
                    trim: {
                        x: r.bocaGato.textures[i].trim.x,
                        y: r.bocaGato.textures[i].trim.y,
                        width: r.bocaGato.textures[i].trim.width,
                        height: r.bocaGato.textures[i].trim.height,
                        type: r.bocaGato.textures[i].trim.type
                    }*/
                }
            });
            
             Object.keys(r.keyboard.textures).forEach(function(i, count){
                 self._keyboardConfig[count] = {
                    crop: {
                        x: r.keyboard.textures[i].crop.x,
                        y: r.keyboard.textures[i].crop.y,
                        width: r.keyboard.textures[i].crop.width,
                        height: r.keyboard.textures[i].crop.height,
                        type: r.keyboard.textures[i].crop.type
                    },
                    source: {
                        x: r.keyboard.data.frames[i].spriteSourceSize.x,
                        y: r.keyboard.data.frames[i].spriteSourceSize.y,
                        width: r.keyboard.data.frames[i].frame.w,
                        height: r.keyboard.data.frames[i].frame.h,
                        name: i.replace(".png", "")
                    }
                }
             });
            
            Object.keys(r.paint.textures).forEach(function(i, count){
                self._paintConfig[count] = {
                    crop: {
                        x: r.paint.textures[i].crop.x,
                        y: r.paint.textures[i].crop.y,
                        width: r.paint.textures[i].crop.width,
                        height: r.paint.textures[i].crop.height,
                        type: r.paint.textures[i].crop.type
                    },
                    source: {
                        x: r.paint.data.frames[i].spriteSourceSize.x,
                        y: r.paint.data.frames[i].spriteSourceSize.y,
                        width: r.paint.data.frames[i].frame.w,
                        height: r.paint.data.frames[i].frame.h,
                        name: i.replace(".png", "")
                    }
                }
            });
            //self._frameBocaConfig = r.boca.textures;
            //self._frameBocaGatoConfig = r.bocaGato.textures;
            
            Object.keys(r.bexiga.textures).forEach(function(i, count){
                self._bexigaConfig[count] = {
                    crop: {
                        x: r.bexiga.textures[i].crop.x,
                        y: r.bexiga.textures[i].crop.y,
                        width: r.bexiga.textures[i].crop.width,
                        height: r.bexiga.textures[i].crop.height,
                        type: r.bexiga.textures[i].crop.type
                    },
                    source: {
                        x: r.bexiga.data.frames[i].spriteSourceSize.x,
                        y: r.bexiga.data.frames[i].spriteSourceSize.y,
                        width: r.bexiga.data.frames[i].frame.w,
                        height: r.bexiga.data.frames[i].frame.h,
                        name: i.replace(".png", "")
                    }
                }
            });
            
            self._createKeyboard();
            self._createPaint();
            self.emit("complete");
            self._isComplete = true;            
        });
        
        PIXI.loader.load();
    });
    
    this._txloader.load();
    
    this._textures;
}

Textures.prototype = Object.create(EventEmitter.prototype);
Textures.prototype.constructor = Textures;

Object.defineProperties(Textures.prototype, {
    AUDIO: {
        get: function(){
            return this._getTexture(0);
        }
    },
    
    CLICK: {
        get: function(){
            return this._getTexture(1);
        }
    },
    
    BACK_POPUP: {
        get: function(){
            return this._getTexture(2);
        }
    },
    
    FECHAR: {
        get: function(){
            return this._getTexture(3);
        }
    },
    
    CARD_CLOSE: {
        get: function(){
            return this._getTexture(4);
        }
    },
    
    FRAMES_BOCA: {
        get: function(){
            return this._generateFrames(this._bocaSource, this._frameBocaConfig);
        }
    },
    
    FRAMES_BOCA_GATO: {
        get: function(){
            return this._generateFrames(this._bocaGatoSource, this._frameBocaGatoConfig);
        }
    },
    
    FRAMES_BEXIGA:{
        get: function(){            
            return this._generateFrames(this._bexigaSource, this._bexigaConfig);
        }
    },
    
    KEYBOARD: {
        get: function(){
            return this._keyboard;
        }
    },
    
    PAINT: {
        get: function(){
            return this._paint;
        }
    },
    
    isComplete: {
        get: function(){
            return this._isComplete;
        }
    }
    
});

Textures.prototype._getTexture = function(index)
{
    if(this._textures != null && this._textures != undefined)
    {
        return this._textures[index];
    }
    else
    {
        this._textures = this._txloader.getTextures();
    }
    return this._textures[index];
}

Textures.prototype._generateFrames = function(base, config)
{
    var fr = [];
    var b = new PIXI.BaseTexture(base);
    
    Object.keys(config).forEach(function(i, count){
        //console.log(config[i]);
        if(config[i].trim != null && config[i].tim != undefined)
            fr[count] = new PIXI.Texture(b, config[i].trim, config[i].crop, config[i].trim);
        else
        {
            fr[count] = new PIXI.Texture(b, config[i].crop);
        }
        
        
        if(config[i].source != null && config[i].source != undefined)
        {
            fr[count].name = config[i].source.name;
            fr[count].sourceX = config[i].source.x;
            fr[count].sourceY = config[i].source.y;
        }
    });
    return fr;
}

Textures.prototype._createKeyboard = function()
{
    var frames = this._generateFrames(this._keyboardSource, this._keyboardConfig);
    this._keyboard = new tls.ui.Keyboard(frames);
}

Textures.prototype._createPaint = function()
{
    var frames = this._generateFrames(this._paintSource, this._paintConfig);
    this._paint = new tls.ui.Paint(frames);
}

Textures.prototype.destroy = function()
{
    this._txloader.destroy();
    this._txloader = null;
    
    this._bocaGatoSource.src = "";
    this._bocaGatoSource = null;
    
    this._bocaSource.src = "";
    this._bocaSource = null;
    
    this._frameBocaConfig.splice(0, this._frameBocaConfig.length);
    this._frameBocaGatoConfig.splice(0, this._frameBocaGatoConfig.length);
}

tls.display.Textures = new Textures();