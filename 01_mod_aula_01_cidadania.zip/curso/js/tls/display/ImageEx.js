function ImageEx(texture)
{
    AnimateButton.call(this, texture);    
}

ImageEx.prototype = Object.create(AnimateButton.prototype);
ImageEx.prototype.constructor = ImageEx;

tls.display.ImageEx = ImageEx;