/**
* Suporte para criação de imagens DOM (<img />)
* Suporte para criação de PIXI.Texture a partir de DOM
* Armazenamento próprio liberando resource do PIXI.loaders.Loader
*
* ```js
* var l = new HTMLTexture();
* l.add('img/imagem1.png');
* l.add('img/imagem2.png');
*
* ou
*
* l.addMultiple(['img/imagem1.png', 'img/imagem2.png']);
*
* l.on('complete', function(e){
* //TODO
* });
* l.load();
* 
* var arrTextures = l.getTextures();
* var arrDOM = l.getDOM();
* ```
*
* @class
* @extends EventEmitter
* @memberof tls.loaders
*/
function HTMLTexture()
{
    EventEmitter.call(this);
    
    /**
    * Para armazenar as urls
    *
    * @member {string[]}
    * @private
    */
    this._urls = [];
    
    /**
    * Para armazenar as imagens DOM
    *
    * @member {Image[]} (DOMObject)
    * @private
    */
    this._imgs = [];
    
    /**
    * Suporte para verificar as imagens que foram carregadas
    * 
    * @member {number}
    * @default 0
    * @private
    */
    this._countLoaders = 0;
    
    /**
    * suporte para definir se todas as imagens ja foram carregadas
    *
    * @member {boolean}
    * @default false
    * @private
    */
    this._isComplete = false;
    
    /**
    * Disparado quando o completa o carregamento de todas as imagens
    *
    * @event complete
    * @memberof HTMLTexture#
    */
}

HTMLTexture.prototype = Object.create(EventEmitter.prototype);
HTMLTexture.prototype.constructor = HTMLTexture;

/**
* Adiciona uma url à fila de carregamento
*
* @memberof HTMLTexture
* @param url {string} a url da imagem a ser carregada
* @public 
*/
HTMLTexture.prototype.add = function(url)
{
    var self = this;
    var i = new Image();
    i.onload = function(e){
        self._loadHandler(self);
    }
    this._urls.push(url);
    this._imgs.push(i);
}

/**
* Adiciona um array de urls para a fila de carregamento
*
* @memberof HTMLTexture
* @param urls {string[]} um array com as urls da imagens a serem carregadas
* @public
*/
HTMLTexture.prototype.addMultiple = function(urls)
{
    for(var i = 0; i < urls.length; i++)
    {
        this.add(urls[i]);
    }
}

/**
* Inicia o carregamento da fila
*
* @memberof HTMLTexture
* @public
*/
HTMLTexture.prototype.load = function()
{   
    for(var i = 0; i < this._urls.length; i++)
    {
        this._imgs[i].src = this._urls[i];
    }
}

/**
* É executada ao témino do carregamento de cada imagem
* Verifica se todas as imagens estão carregadas
*
* @memberof HTMLTexture
* @param self {tls.loaders.HTMLTexture}
* @fires complete
* @private
*/
HTMLTexture.prototype._loadHandler = function(self)
{
    // incrementa o suporte a cada imagem baixada
    self._countLoaders++;
    
    // verifica se todas as imagens foram baixadas
    if(self._countLoaders >= self._urls.length)
    {
        //dispara o evento complete
        self.emit("complete");
        self._isComplete = true;
    }
}

/**
* Retorna um array de textures na ordem listada
*
* @memberof HTMLTexture
* @return {PIXI.Texture[]}
* @public
*/
HTMLTexture.prototype.getTextures = function()
{
    if(this.tx == null && this.tx == undefined)
    {
        this.tx = [];
        
        for(var i = 0; i < this._urls.length; i++)
        {
            var base = new PIXI.BaseTexture(this._imgs[i]);
            var texture = new PIXI.Texture(base);

            this.tx.push(texture);
        }
    }
    
    
    return this.tx;        
}

/**
* Retorna um array de Images na ordem listada
*
* @memberof HTMLTexture
* @return {Image[]} (DOMObject)
*/
HTMLTexture.prototype.getDOM = function()
{    
    return this._imgs;
}

/**
* Suporte para limpar a memória
* destroi todos os objetos e remove os eventos
*
* @memberof HTMLTexture
* @public
*/
HTMLTexture.prototype.destroy = function()
{
    for(var i = 0; i < this._urls.length; i++)
    {
        this._imgs[i].src = "";
        this._imgs[i] = null;
    }
    
    this._imgs.splice(0, this._imgs.length);
    this._urls.splice(0, this._imgs.length);
    
    this._countLoaders = 0;
}

tls.loaders.HTMLTexture = HTMLTexture;