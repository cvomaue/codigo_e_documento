function Clock(factory)
{
    EventEmitter.call(this);
    
    this._factory = factory;
    
    var txH = this._factory.pointersH[0].texture;
    var txM = this._factory.pointersM[0].texture;
    
    for(var i = 0; i < this._factory.pointersH.length; i++)
    {
        var h = this._factory.pointersH[i];
        h.swapTexture(txH);
        
        var m = this._factory.pointersM[i];
        m.swapTexture(txM);
        
        var parent = m.parent;
        parent.setChildIndex(m, i);
    }
    
    this._corrects = [];
    this._initialPosition = [];
}

Clock.prototype = Object.create(EventEmitter.prototype);
Clock.prototype.constructor = Clock;

Object.defineProperties(Clock.prototype, {
    corrects: {
        set: function(value){
            this._corrects = value;
        }
    },
    
    initialPosition: {
        set: function(value){  
            this._initialPosition = value; 
            
            this.reset();
        }
    }
})

Clock.prototype.addEvents = function()
{
    for(var i = 0; i < this._factory.pointersH.length; i++)
    {
        var h = this._factory.pointersH[i];
        h.addEvents();
        
        var m = this._factory.pointersM[i];
        m.addEvents();
    }
}

Clock.prototype.removeEvents = function()
{
    for(var i = 0; i < this._factory.pointersH.length; i++)
    {
        var h = this._factory.pointersH[i];
        h.removeEvents();
        
        var m = this._factory.pointersM[i];
        m.removeEvents();
    }
}

Clock.prototype.check = function()
{    
    var res = true;
    
    for(var i = 0; i < this._factory.pointersH.length; i++)
    {
        var h = this._factory.pointersH[i];        
        if(h.hour != this._corrects[i][0])
        {
            res = false;
            break;
        }
        
        var m = this._factory.pointersM[i];
        if(m.minutes != this._corrects[i][1])
        {
            res = false;
            break;
        }
    }
    
    return res;
}

Clock.prototype.reset = function()
{
    var len = this._factory.pointersH.length;
    
    for(var i = 0; i < len; i++)
    {
        var h = this._factory.pointersH[i];
        try{
            h.hour = this._initialPosition[i][0]
        }
        catch(err){
            h.hour = 0; 
        }

        var m = this._factory.pointersM[i];
        try{
            m.minutes = this._initialPosition[i][1];
        }
        catch(err){
            m.minutes = 0;
        }
    }
}

Clock.prototype.destroy = function()
{
    this.removeEvents();
    this.removeAllListeners();
    
    for(var i = 0; i < this._factory.pointersH.length; i++)
    {
        var h = this._factory.pointersH[i];
        h.destroy();
        
        var m = this._factory.pointersM[i];
        m.destroy();
    }
}

tls.templates.Clock = Clock;