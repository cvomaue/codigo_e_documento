function TxGroup()
{
    Base.call(this);
    
    var self = this;
    
    this._images = [];
    this._audios = [];
    this._inputs = [];
    
    this._addedToStage = setInterval(function(){
        if(this.parent != null && this.parent != undefined)
        {
            clearInterval(self._addedToStage);
            
            for(var i = 0; i < self._audios.length; i++)
            {
                self.setChildIndex(self._audios[i], self.children.length - 1);
            }
        }
    }, 100);
}

TxGroup.prototype = Object.create(Base.prototype);
TxGroup.prototype.constructor = TxGroup;

Object.defineProperties(TxGroup.prototype, {
    inputs: {
        get: function(){
            return this._inputs;
        }
    },
    
    images: {
        get: function(){
            return this._images;   
        }
    },
    
    audios: {
        get: function(){
            return this._audios;
        }
    }
});

TxGroup.prototype.setAudio = function(soundManager)
{
    this._soundManager = soundManager;
    
    for(var i = 0; i < this._audios.length; i++)
    {
        this._audios[i].setAudio(this._soundManager, i);
    }
}

TxGroup.prototype.addTextEvents = function()
{
    var self = this;
    
    for(var i = 0; i < this._inputs.length; i++)
    {
        var input = this._inputs[i];
        if(input.block) continue;
        input.id = i;
        input.addEvents();
        input.on("focus", function(){
            self.emit("focus", {index: this.id});
        });
        
        input.on("blur", function(){
            self.emit("blur", {index: this.id});
        });
        
        input.on("textUpdate", function(){
            self.emit("textUpdate", {index: this.id});
        });
    }
}

TxGroup.prototype.removeTextEvents = function()
{
    var self = this;
    
    for(var i = 0; i < this._inputs.length; i++)
    {
        var input = this._inputs[i];
        input.removeEvents();
        input.removeListener("focus");
        
        input.removeListener("blur");
        
        input.removeListener("textUpdate");
    }
}

TxGroup.prototype.destroy = function()
{
    this.removeChildren();
    this.removeAllListeners();
    
    for(var i = 0; i < this._images.length; i++)
    {
        this._images[i].destroy();
        this._images[i] = null;
    }
    
    for(i = 0; i < this._audios.length; i++)
    {
        this._audios[i].destroy();
        this._audios[i] = null;
    }
    
    for(i = 0; i < this._inputs.length; i++)
    {
        this._inputs[i].destroy();
        this._inputs[i]  = null;
    }
    
    this._images.splice(0, this._images.length);
    this._audios.splice(0, this._audios.length);
    this.inputs.splice(0, this.inputs.length);
    
    if(this._soundManager != null && this._soundManager != undefined)
        this._soundManager = null;
    
    Base.prototype.destroy.call(this);
}

tls.text.TxGroup = TxGroup;