function FadeSequence(sequence)
{
    PIXI.Container.call(this);
    
    this._sequence = sequence;
    this._paused = false;
    this._atualIndex = 0;
    
    for(var i = 0; i < this._sequence.length; i++)
    {
        this._sequence[i].alpha = 0;
        this.addChild(this._sequence[i]);
    }
}

FadeSequence.prototype = Object.create(PIXI.Container.prototype);
FadeSequence.prototype.constructor = FadeSequence;

FadeSequence.prototype.play = function()
{
    this.emit("preStart", {atualIndex: this._atualIndex, sequence: this._sequence[this._atualIndex]});
    this._paused = false;
    this._openSeq(this._atualIndex);
}

FadeSequence.prototype._openSeq = function(index)
{
    var self = this;
    
    if(this._paused) return;
    
    this.emit("start", {atualIndex: this._atualIndex, sequence: this._sequence[this._atualIndex]});
    
    if(this._paused) return;
    
    this._sequence[this._atualIndex].openWithFade(function(){
        self._atualIndex++;
    
        if(self._atualIndex >= self._sequence.length)
        {
            self.emit("end");
            return;
        }

        self.emit("preStart", {atualIndex: self._atualIndex, sequence: self._sequence[self._atualIndex]});
        self._openSeq(this._atualIndex);
    });
}

FadeSequence.prototype.pause = function()
{
    this._paused = true;
}

FadeSequence.prototype.destroy = function()
{
    this.removeChildren();
    this.removeAllListeners();
    
    for(var i = 0; i < this._sequence.length; i++)
    {
        this._sequence[i].destroy();
        this._sequence[i] = null;
    }
    
    this._sequence.splice(0, this._sequence.length);
    
    PIXI.Container.prototype.destroy.call(this);
}

tls.templates.FadeSequence = FadeSequence;