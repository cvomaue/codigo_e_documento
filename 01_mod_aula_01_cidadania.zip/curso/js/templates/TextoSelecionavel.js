function Tela()
{
    PIXI.Container.call(this);
    tls.core.Factory.call(this, "telas/036/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/036/36_1.mp3");
    this.soundManager.addSingleSound("telas/036/36_2.mp3");
    
    this.dialogos;
    
    this.correct = 0;
    
    this.totalCorrects = 3;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.init();
    }); 
}

Tela.prototype = Object.create(PIXI.Container.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    
    this.feedOkIndex = 1;
    this.feedFailIndex = 0;
    this.bocaFeedOkIndex = 0;
    this.bocaFeedFailIndex = 0;

    this.soundOkIndex = 1;
    this.soundFailIndex = 0;
    
    this.input = new SelectableText("Modo de preparar:\nBata 3 ovos na batedeira, depois acrescente 2\nxícaras (chá) de açúcar. Agora acrescente 1 tablete\nde margarina e bata com 3 xícaras (chá) de farinha\nde trigo. Acrescente a essa mistura 1 copo de leite,\nmisture mais um pouco. Por fim, acrescente 1 colher\n(sopa) de fermento em pó e misture delicadamente.\nColoque a mistura em forma untada e polvilhada com\nfarinha de trigo. Asse em forno pré-aquecido em\n180° por 25 minutos.", 24, 445);
    
    this.input.corrects = ["preparar", "Bata", "acrescente", "Acrescente", "bata", "misture", "Coloque", "Asse"];
    
    this.input.x = 426;
    this.input.y = 139;
    this.input.interactive = false;
    
    this.addChild(this.input);
    
    this.click = this.clicks[0];
    this.click.addIcon();
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("end", function(e){
        this.removeListener("end");
        
        for(var i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i);
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }
        
        self.click.icon.animate();
        
        self.input.interactive = true;
        self.input.on("correct", function(){
            self.setOk();
        });
    });
    
    this.dialogos.play();
}

Tela.prototype.setOk = function()
{
    var self  = this;
    self.removeDragsEvents(); 
    
    self.correct++;

    if(self.correct >= self.totalCorrects)
    {
        this.input.interactive = false;
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);                
        });

        return;
    }

    self.addDragsEvents();        
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    this.removeDragsEvents();
    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound);  
}

Tela.prototype.configureDrags = function()
{
    var self = this;
    
    for(var i = 0; i < self.drags.length; i++)
    {
        if(i < self.areaDrags.length)
        {
            self.drags[i].collisions = [self.areaDrags[i]];            
        }
        
        self.drags[i].usePoint = true;
        self.drags[i].adjust = true;        
        
        self.drags[i].on("incorrect", function(e){
            //self.setFail();
        });

        self.drags[i].on("correct", function(e){
            this.removeListener("correct");
            this.isOff = true;
            self.setOk();
        });
    }
}

Tela.prototype.addDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        if(this.drags[i].isOff) continue;
        this.drags[i].addEvents();
    }
}

Tela.prototype.removeDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].removeEvents();
    }
}

Tela.prototype.destroy = function()
{    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}