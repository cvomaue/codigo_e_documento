function Tela()
{
    tls.core.Factory.call(this, "telas/005/b/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/005/b/5_4.mp3");
    this.soundManager.addSingleSound("telas/005/b/5_5.mp3");
    this.soundManager.addSingleSound("telas/005/b/5_6.mp3");
    this.soundManager.addSingleSound("telas/005/b/5_7.mp3");
    this.soundManager.addSingleSound("telas/005/b/5_8.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.correct = 0;
    this.totalCorrects = 1;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 3;
        this.bocaFeedOkIndex = 0;
        this.soundOkIndex = 3;
        
        this.feedFailIndex = 2;
        this.bocaFeedFailIndex = 0;
        this.soundFailIndex = 4;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    
    this.memoryGame = new tls.templates.MemoryGame(this, "individual");
    this.memoryGame.corrects = [8];
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0, 0, 0], 2);
    this.dialogos.on("preStart", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        if(e.atualIndex == 1)
        {
            self.dialogos.pause();
            self.memoryGame.init();
            self.memoryGame.on("closeComplete", function(){
                this.removeListener("closeComplete");
                
                self.dialogos.play();
            });
        }
    });
    this.dialogos.on("end", function(e){
        self.memoryGame._addEvents();      
        
        self.memoryGame.on("correct", function(e){
            self.setOk();
        });
        
        self.memoryGame.on("incorrect", function(e){
            self.setFail();
        });
    });    
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    
    this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
      for(var i = 0; i < self.feeds.length; i++)
        {
            if(self.feeds[i].type == tls.display.FeedObject.FAIL)
            {
                self.feeds[i].closeFeed();               
            }
        }
        
        self.memoryGame._addEvents();
        
    });
    
    //Alternativa sem balão de feedFail
    /*setTimeout(function(){
      for(var i = 0; i < self.feeds.length; i++)
        {
            if(self.feeds[i].type == tls.display.FeedObject.FAIL)
            {
                self.feeds[i].closeFeed();               
            }
        }
        
        self.memoryGame._addEvents();
        
    }, 1000);*/
}

Tela.prototype.setOk = function()
{
    var self  = this; 
    
    self.correct++;

    if(self.correct >= self.totalCorrects)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);            
        }); 

        return;
    }
    
    self.memoryGame._addEvents();
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    for(var i = 0; i < this.clicks.length; i++)
        this.clicks[i].destroy();
    
    for(var i = 0; i < this.stars.length; i++)
        this.stars[i].destroy();
    
    for(var i = 0; i < this.icons.length; i++)
        this.icons[i].destroy();
    
    this.memoryGame.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}