function CustomInput(text, size)
{    
    this._size = size || 30;
    
    this._inputTheme = new GOWN.ShapeTheme();
    this._inputTheme.textStyle = {
        "fill": "#000",
        "font": this._size + "px Angola"
    };
    
    this.focushandler = function(){};
    
    GOWN.TextInput.call(this, text, false, this._inputTheme);
}

CustomInput.prototype = Object.create(GOWN.TextInput.prototype);
CustomInput.prototype.constructor = CustomInput;

CustomInput.prototype.onfocus = function() {
    this.focushandler();
};

CustomInput.prototype.focus = function () {
    // is already current input
    if (GOWN.InputControl.currentInput === this) {
        return;
    }

    // drop focus
    if (GOWN.InputControl.currentInput) {
        GOWN.InputControl.currentInput.blur();
    }

    // set focus
    GOWN.InputControl.currentInput = this;
    this.hasFocus = true;

    // check custom focus event
    this.onfocus();
};