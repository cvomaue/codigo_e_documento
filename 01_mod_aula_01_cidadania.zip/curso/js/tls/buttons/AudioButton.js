/**
* Suporte para os botões de audio
* utiliza uma textura padrão
* utiliza um objeto tls.media.SoundManager para tocar o audio
*
* @class
* @extends tls.display.AnimateButton
* @memberof tls.buttons
*/
function AudioButton()
{
    AnimateButton.call(this, tls.display.Textures.AUDIO);
    
    /**
    * instância do objeto tls.media.SoundManager
    * 
    * @member {tls.media.SoundManager}
    * @private 
    */
    this._sm = null;
    
    /**
    * indice do audio referente ao objeto tls.media.SoundManager
    *
    * @member {number}
    * @private
    */
    this._soundIndex;
    
    /**
    * indica se o som é um grupo de audios
    * 
    * @member {boolean}
    * @default false
    * @private
    */
    this._goupSound = false;
    
    /**
    * Disparado quando o usuário solta a pressão do mouse ou tira o toque da tela
    * após ter precionado ou tocado representando uma ação de click
    * inicia a reprodução do audio
    *
    * @event soundStart
    * @memberof AudioButton#
    */
    
    /**
    * Disparado quando termina a reprodução do audio
    *
    * @event soundComplete
    * @memberof AudioButton#
    */
}

AudioButton.prototype = Object.create(AnimateButton.prototype);
AudioButton.prototype.constructor = AudioButton;

/**
* Método para adicionar o audio
* o objeto AudioButton precisa ter um audio
*
* ```js
* var a = new AudioButton();
* a.setAudio(soundManager, 3);
* a.animate();
* a.addEvents();
*
* a.on('soundStart', function(e){
* //TODO
* });
*
* a.on('soundComplete', function(e){
* //TODO
* });
* ```
*
* @memberof AudioButton
* @param soundManager {tls.media.SoundManager} objeto para controlar o audio
* @param index {number} indice do audio referente ao objeto tls.media.SoundManager
* @param [group=false] {boolean} indica se o audio é um grupo
* @public
*/
AudioButton.prototype.setAudio = function(soundManager, index, group)
{
    this._groupSound = group || false;
    
    this._sm = soundManager;
    this._soundIdex = index;
}

/**
* Ao retirar a pressão do mouse ou retirar o toque na tela
* inicia a reprodução do audio
*
* @memberof AudioButton
* @param e {MouseEvent/TouchEvent}
* @fires soundStart
* @private
*/
AudioButton.prototype._onUp = function(e)
{
    AnimateButton.prototype._onUp.call(this, e);
    
    var self = this;
    
    //autoriza todos os audios (util para dispositivos móveis)
    this._sm.AutorizeSounds();
    this._sm.on("soundComplete", function(e)
                {
        this.removeListener("soundComplete");
        this.removeListener("sequenceComplete");
        
        self._onSoundComplete(e);
    });
    this._sm.on("sequenceComplete", function(e)
                {
        this.removeListener("sequenceComplete");
        this.removeListener("soundComplete");
        
        self._onSoundComplete(e);
    });
    
    this.emit("soundStart");
    
    //inicia a reprodução do som
    if(this._groupSound) this._sm.playMultiple(this._soundIdex);
    else this._sm.playSound(this._soundIdex);
}

/**
* Ao terminar de tocar o audio
*
* @memberof AudioButton
* @param e {SoundManagerEvent}
* @fires soundComplete
* @private
*/
AudioButton.prototype._onSoundComplete = function(e)
{
    this.emit("soundComplete");
    
    this.addEvents();
}

tls.buttons.AudioButton = AudioButton;