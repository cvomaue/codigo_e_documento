function Tela()
{
    tls.core.Factory.call(this, "telas/020/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/020/20_1.mp3");
    this.soundManager.addSingleSound("telas/020/20_2.mp3");
    this.soundManager.addSingleSound("telas/020/20_3.mp3");
    this.soundManager.addSingleSound("telas/020/20_4.mp3");
    this.soundManager.addSingleSound("telas/020/20_5.mp3");
    //this.soundManager.addSingleSound("telas/020/20_6.mp3");
    ///quantos sons forem necessarios para os baloes
    
  this.dialogos;
    
    this.correct = 0;
    this.totalCorrects = 3;
    
    this.on("complete", function(){
        this.removeListener("complete");
            
        this.feedOkIndex = 1;
        this.feedFailIndex = 1;
        this.bocaFeedOkIndex = 0;
        this.bocaFeedFailIndex = 0;
        this.soundOkIndex = this.soundManager._sounds.length-1;
        //this.soundFailIndex = 1;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this; 
    
    CORRECTS = 0;
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("end", function(e){
        this.removeListener("end");
        
        self.addFeedsEvents();
        
     for(var i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i );
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }
        
        
    });
    
    this.configureFeeds();
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    self.removeFeedsEvents();
    //this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
    setTimeout(function(){
      for(var i = 0; i < self.feeds.length; i++)
        {
            if(self.feeds[i].type == tls.display.FeedObject.FAIL)
            {
                self.feeds[i].closeFeed();
            }
        }
        
        self.emit("removeAll");
        //self.addFeedsEvents();
    },650);
}

Tela.prototype.setOk = function()
{
    var self  = this;
    self.removeFeedsEvents(); 
    
    self.correct++;

    if(self.correct >= self.totalCorrects)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                CORRECTS++;
                self.emit("removeAll");
            }, 1000);            
       }); 

        return;
    }

    self.addFeedsEvents();       
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    this.removeFeedsEvents();
    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.configureFeeds = function()
{    
    var self = this;
    
    for(var i = 0; i < this.feeds.length; i++)
    {        
        this.feeds[i].on(tls.display.FeedObject.FAIL, function(){
            self.setFail();
        });
        
        this.feeds[i].on(tls.display.FeedObject.OK, function(){
            self.setOk();
        });
        
        //this.feeds[i].thickness = 10;
    }
    
    /*for(i = 1; i < this.audios.length; i++)
    {
        this.audios[i].setAudio(this.soundManager, i);
        this.audios[i].on("soundStart", function(){
            self.bocas[0].play();
        });
        this.audios[i].on("soundComplete", function(){
            self.bocas[0].gotoAndStop(self.bocas[0].stationary);
        });
    }*/
}

Tela.prototype.addFeedsEvents = function()
{
    for(var i = 0; i < this.feeds.length; i++)
    {
        this.feeds[i].addEvents();
    }
}

Tela.prototype.removeFeedsEvents = function()
{
    for(var i = 0; i < this.feeds.length; i++)
    {
        this.feeds[i].removeEvents();
    }
}

Tela.prototype.destroy = function()
{
    for(var i = 0; i < this.feeds.length; i++)
    {
        this.feeds[i].destroy();
    }
    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}