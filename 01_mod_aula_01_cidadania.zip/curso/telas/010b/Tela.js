function Tela()
{
    tls.core.Factory.call(this, "telas/010b/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/010b/10_6.mp3");
    this.soundManager.addSingleSound("telas/010b/10_7.mp3");
    this.soundManager.addSingleSound("telas/010b/10_8.mp3");
    this.soundManager.addSingleSound("telas/010b/10_9.mp3");
    ///quantos sons forem necessarios para os baloes
    
   this.dialogos;
    
    this.on("complete", function(){
        this.removeListener("complete");
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0,0,0,0]);
    this.dialogos.on("preStart", function(e){
        
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
    
        
    });
    this.dialogos.on("end", function(e){
        self.emit("removeAll");/*
            var a = self.audios[1];
            a.setAudio(self.soundManager, 4);
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
                self.click = self.clicks[0];
                self.click.addIcon();
                self.click.icon.animate();
                self.click.addEvents();
                self.click.on("clicked", function(e){
                    this.removeListener("clicked");
                    self.emit("removeAll");
                });
            });   */ 
    });
    
    this.dialogos.play();
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    //this.click.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}