function Tela()
{
    tls.core.Factory.call(this, "telas/013/sprites.json");
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/013/13_1.mp3");
    this.soundManager.addSingleSound("telas/013/13_2.mp3");
    this.soundManager.addSingleSound("telas/013/13_3.mp3");
    this.soundManager.addSingleSound("telas/013/13_4.mp3");
    this.soundManager.addSingleSound("telas/013/13_5.mp3");
    this.soundManager.addSingleSound("telas/013/13_6.mp3");
    this.soundManager.addSingleSound("telas/013/13_7.mp3");
    this.soundManager.addSingleSound("telas/013/13_8.mp3");
    
    this.dialogos;
    
    this.correct = 0;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 1;
        this.feedFailIndex = 3;
        this.bocaFeedOkIndex = 0;
        this.bocaFeedFailIndex = 0;
        this.soundOkIndex = this.soundManager._sounds.length-1;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;    
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("end", function(e){
        //console.log(self.areaDrags)
        this.removeListener("end");
        
        self.addDragsEvents();
    });
    
     this.dialogos.on("end", function(e){
        this.removeListener("end");

        for(i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i );
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }

    });
    
    this.configureDrags();
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    self.removeDragsEvents();  
    
    //this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.feedFailIndex, function(){
    setTimeout(function(){
        self.addDragsEvents();        
    }, 650);
    //});
}

Tela.prototype.setOk = function()
{
    var self  = this;
    self.removeDragsEvents();  
    
    self.correct++;

    if(self.correct >= 3)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);                
        });

        return;
    }

    self.addDragsEvents();        
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    this.removeDragsEvents();
    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound);  
}

controlY = 0;
rh = 0;
Drag.prototype._adjust = function()
{
    //console.log(controlY);
    var r = this._collisions[this._index];
    rh = (rh == 0) ? r.height / 3 : rh;
    controlY = (controlY == 0) ? r.y + 50 : controlY;
    TweenMax.to(this.position, 0.5, {x: r.x + r.width / 2, y: controlY, ease: Back.easeOut});
    controlY += rh;
}

Tela.prototype.configureDrags = function()
{
    var self = this;
    
    
    self.drags[5].collisions = [self.areaDrags[0]];            
    self.drags[2].collisions = [self.areaDrags[0]];            
    self.drags[1].collisions = [self.areaDrags[0]];            
        
    
    for(var i = 0; i < self.drags.length; i++)
    {
      
        
        self.drags[i].usePoint = true;
        self.drags[i].adjust = true;        
        
        self.drags[i].on("incorrect", function(e){
            self.setFail();
        });

        self.drags[i].on("correct", function(e){
            this.removeListener("correct");
            self.setOk();
        });
    }
}

Tela.prototype.addDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].addEvents();
    }
}

Tela.prototype.removeDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].removeEvents();
    }
}

Tela.prototype.destroy = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].destroy();
    }
    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}