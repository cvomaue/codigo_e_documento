function Tela()
{
    tls.core.Factory.call(this, "telas/012e/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/012e/12_1.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        var self = this;
        
        this.movies = [];
        
        /**
        * Novo loader para carregar as animações
        */
        this.loader = new PIXI.loaders.Loader();
        /**
        * use o método add para cadada animação
        * Sintaxe:
        * nome {string}
        * url {string}
        */
        this.loader.add("paladar1", "telas/012e/paladar01.json");        
        this.loader.add("paladar2", "telas/012e/paladar02.json");        
        this.loader.add("paladar3", "telas/012e/paladar03.json");        
        this.loader.add("paladar4", "telas/012e/paladar04.json");         
        /**
        * método load para fazer o load da/ das animações
        * Sintaxe:
        * onComplete {function} função executada quando termina o carregamento
        */
        this.loader.load(function(){
            
            var numFrames1 = [];
            
            /**
            * Método getFrames -> usado para criar os frames pode adicionar
            * uma ou várias animação no mesmo frame ou até um spritesheet 
            * com varias animações
            * os frames serão posicionados na ordem descrita nos parametros
            * Sintaxe:
            * init {number[]} frame inicial em cada um dos sprites
            * max {number []} a quantidade de frames em cada sprite
            * tiver mais de uma animação incluir na ordem que quiser que seja montado os frames
            * o exemplo a seguir tem duas animações no spritesheet
            */
            self.getFrames([0, 101, 226, 331], [100, 124, 104, 115], numFrames1, ["paladar0", "paladar0", "paladar0", "paladar0"]);
            /**
            * o exemplo a seguir tem uma animação no spritesheet
            *
            * container {array} um array para armazenar os frames
            * pattern {string} o padrão do nome da animação no spritesheet
            */
//            
            
            /**
            * Método createMovie
            * esse método serve para criar o movie clip
            * pode ser criados quantos forem necessários
            * os movie clips são armazenados no array this.movies ou self.movies
            * @member PIXI.extras.MovieClip
            * @see http://pixijs.github.io/docs/PIXI.extras.MovieClip.html
            * 
            * frames {PIXI.Texture[]} array dos frames com as texturas obtidas com o 
            * método getFrames
            * x {number} posição x no stage
            * y {number} posição y no stage
            * as posições x, y podem ser modificadas depois acessando diretamente
            * o movie clip, exemplo:
            * self.movies[0].x = 300//etc..
            */
            self.createMovie(numFrames1, 400, 186);
            
            //caso necessite aumentar ou diminuir o scale
            self.movies[0].scale.x = self.movies[0].scale.y = 1.1;
            
            self.init();
        });
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.createMovie = function(frames, _x, _y){
    
    var m = new PIXI.extras.MovieClip(frames);
    m.loop = false;
    m.animationSpeed = .3;
    m.x = _x;
    m.y = _y;
    
    this.addChild(m);
    this.movies.push(m);
}

Tela.prototype.getFrames = function(init, max, container, pattern){
    
    for(var i = 0; i < max.length; i++)
    {
        for(var j = init[i]; j < init[i] + max[i]; j++)
        {
            var val = 0;

            if(j < 9)
            {
                val = '00' + (j + 1);
            }
            else if(j >= 9 && j < 99)
            {
                val = '0' + (j + 1);
            }
            else
            {
                val = j + 1;
            }

            container.push(PIXI.Texture.fromFrame(pattern[i] + val + '.png'));
        }
    }
}

Tela.prototype.init = function()
{
    var self = this;   
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0], 0);
    this.dialogos.on("preStart", function(e){
            e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self.movies[0].play();
        
        //para quando a animação encerrar
        self.movies[0].onComplete = function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);
        }
    });    
    
    this.dialogos.play();
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}