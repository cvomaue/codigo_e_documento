function AreaDrag(rect)
{
    EventEmitter.call(this);

    this._rect = rect;
    this._containerDrags = [];
    this._maxChildren = 0
    this._alignMode = "none";

    this._vspace = 0;
    this._hspace = 0
    this._grid = [];

    this._index;

    this._corrects = [];
}

AreaDrag.prototype = Object.create(EventEmitter.prototype);
AreaDrag.prototype.constructor = AreaDrag;

Object.defineProperties(AreaDrag.prototype, {
    x: {
        get: function(){
            return this._rect.x;
        }
    },

    y: {
        get: function(){
            return this._rect.y;
        }
    },

    width: {
        get: function(){
            return this._rect.width;
        }
    },

    height: {
        get: function(){
            return this._rect.height;
        }
    },

    maxChildren: {
        get: function(){
            return this._maxChildren;
        },

        set: function(value){
            this._maxChildren = value;
        }
    },

    children: {
        get: function(){
            return this._containerDrags;
        }
    },

    align: {
        get: function(){
            return this._alignMode;
        },

        set: function(value){
            this._alignMode = value;
        }
    },

    vspace: {
        get: function(){
            return this._vspace;
        },

        set: function(value){
            this._vspace = value;
        }
    },

    hspace: {
        get: function(){
            return this._hspace;
        },

        set: function(value){
            this._hspace = value;
        }
    },

    points: {
        get: function(){
            return this._points;
        },

        set: function(value){
            this._points = value;
        }
    },

    alignMode: {
        get: function(){
            return this._alignMode;
        },

        set: function(value){
            this._alignMode = value;
        }
    },

    index: {
        get: function(){
            return this._index;
        },

        set: function(value){
            this._index = value;
        }
    },

    corrects: {
        set: function(value){
            this._corrects = value;
        }
    }
})

AreaDrag.prototype.addDrag = function(drag)
{
    var self  = this;
    if(this._maxChildren > 0 && this._containerDrags.length >= this._maxChildren)
    {
        console.log(drag._isOff)
        
        if(drag._isOff) return;

        console.log(drag._originalPosition.x)
        console.log(drag._originalPosition.y)
        
        setTimeout(function(){
            TweenMax.killTweensOf(drag.position);
            TweenMax.to(drag, 0.5, {x: drag._originalPosition.x, y: drag._originalPosition.y, ease: Back.easeOut});
            self.emit('areaFull');
            
        }, 300);  
        
        return;
    }

    this._containerDrags.push(drag);
    this._align();

    if(this._maxChildren > 0 && this._containerDrags.length >= this._maxChildren)
    {
        this.emit('full');
    }
}

AreaDrag.prototype.removeDrag = function(index)
{
    this._containerDrags.splice(index, 1);
}

AreaDrag.prototype.clear = function()
{
    for(var i = 0; i < this._containerDrags.length; i++)
    {
        var d = this._containerDrags[i];
        d._resetPosition();
    }

    this._containerDrags.splice(0, this._containerDrags.length);
}

AreaDrag.prototype.createGrid = function(row, col)
{
    var _r = row || 1;
    var _c = col || 1;

    var w = this.width / col;
    var h = this.height / row;

    var countR = 0;
    var countC = 0;

    for(var i = 0; i < row * col; i++)
    {
        var cel = new PIXI.Rectangle(0, 0, w, h);

        if(i % 3 == 0)
        {
            countC = 0;
            countR ++;
        }

        cel.x = w * countC;
        cel.y = h * countR;

        this._grid.push(cel);
    }
}

AreaDrag.prototype._align = function()
{
    switch (this._alignMode) {
        case AreaDrag.AlineMode.VERTICAL:
            this._verticalAlign();
            break;
        case AreaDrag.AlineMode.HORIZONTAL:
            this._horizontalAlign();
            break;
        case AreaDrag.AlineMode.GRID:
            this._gridAlign();
            break;
        case AreaDrag.AlineMode.PERSON:
            this._personAlign();
            break;
    }
}

AreaDrag.prototype._verticalAlign = function()
{
    for(var i = 0; i < this._containerDrags; i++)
    {
        var d = this._containerDrags[i];

        if(i == 0)
        {
            TweenMax.to(d, 0.3, {
                x: this.x + this.width / 2,
                y: this.y + d.height / 2
            });
        }
        else
        {
            var dold = this._containerDrags[i - 1];

            TweenMax.to(d, 0.3, {
                x: this.x + this.width / 2,
                y: dold.y + dold.height + this._vspace
            });
        }
    }
}

AreaDrag.prototype._horizontalAlign = function()
{
    for(var i = 0; i < this._containerDrags; i++)
    {
        var d = this._containerDrags[i];

        if(i == 0)
        {
            TweenMax.to(d, 0.3, {
                x: this.x + d.width / 2,
                y: this.y + this.height / 2
            });
        }
        else
        {
            var dold = this._containerDrags[i - 1];

            TweenMax.to(d, 0.3, {
                x: dold.x + dold.width + this.hspace,
                y: this.y + this.height / 2
            });
        }
    }
}

AreaDrag.prototype._gridAlign = function()
{
    for(var i = 0; i < this._containerDrags; i++)
    {
        var d = this._containerDrags[i];

        TweenMax.to(d, 0.3, {
            x: this.x + this._grid[i].x + this._grid[i].width / 2,
            y: this.y + this._grid[i].y + this._grid[i].height / 2
        });
    }
}

AreaDrag.prototype._personAlign = function()
{
    for(var i = 0; i < this._containerDrags; i++)
    {
        var d = this._containerDrags[i];

        TweenMax.to(d, 0.3, {
            x: this._points[i].x,
            y: this._points[i].y
        });
    }
}

AreaDrag.prototype.checkCorrect = function()
{
    var isOk = false;

    var count = 0;

    for(var i = 0; i < this._containerDrags.length; i++)
    {
        var v = false;

        for(var j = 0; j < this._corrects.length; j++)
        {
            if(this._corrects[j] == this._containerDrags[i].id)
            {
                v = true;
                break;
            }
        }

        if(v)
            count++;
        else
            break;
    }

    if(count == this._maxChildren)
        isOk = true;

    return isOk;
}

AreaDrag.AlineMode = {};
AreaDrag.AlineMode.NONE = "none";
AreaDrag.AlineMode.VERTICAL = "vertical";
AreaDrag.AlineMode.HORIZONTAL = "horizontal";
AreaDrag.AlineMode.GRID = "grid";
AreaDrag.AlineMode.PERSON = "person";

tls.display.AreaDrag = AreaDrag;
