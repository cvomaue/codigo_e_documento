//AUDIOS EXTRAS...
/**
* iniciando a contagem com 1 porque teoricamente o 0 seria o balão
* caso não haja balão deve iniciar por 0 (zero)
*/
for(var i = 1; i < self.audios.length; i++)
{
    var a = self.audios[i];
    /**
    * Adicionando o audio
    * indice i + 1 considerando um balão de feed
    */
    a.setAudio(self.soundManager, i + 1);
    a.animate();
    a.addEvents();
    a.on("soundStart", function(){
        self.bocas[0].play();
    });
    a.on("soundComplete", function(){
        self.bocas[0].gotoAndStop(self.bocas[0].stationary);
    });
}

//ESPELHANDO OBJETOS
/**
* o mesmo que tornar o lado oposto usamos para isso a escala
* oposto de um número positivo é o mesmo número negativo
* oposto de 1 = -1;
* portanto:
*/
var bocaGato = this.bocas[1];
bocaGato.scale.set(-bocaGato.scale.x, bocaGato.scale.y);
//ajustando o ponto de ancora
bocaGato.pivot.set(-bocaGato.width, 0);