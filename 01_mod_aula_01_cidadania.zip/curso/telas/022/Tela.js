function Tela()
{
    tls.core.Factory.call(this, "telas/022/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/022/22_1.mp3");
    this.soundManager.addSingleSound("telas/022/22_2.mp3");
    this.soundManager.addSingleSound("telas/022/22_3.mp3");
    this.soundManager.addSingleSound("telas/022/22_4.mp3");
    this.soundManager.addSingleSound("telas/022/22_5.mp3");
    this.soundManager.addSingleSound("telas/022/22_6.mp3");
    this.soundManager.addSingleSound("telas/022/22_7.mp3");
    this.soundManager.addSingleSound("telas/022/22_8.mp3");
    this.soundManager.addSingleSound("telas/022/22_9.mp3");
    ///quantos sons forem necessarios para os baloes
    
   this.dialogos;
    
    this.on("complete", function(){
        this.removeListener("complete");
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    self.bocas[2].scale.set(-self.bocas[2].scale.x, self.bocas[2].scale.y);
    self.bocas[2].pivot.set(-self.bocas[2].width , 0);
    self.bocas[2].x += 15;
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [2, 0, 0, 1, 0, 2, 0, 1, 2]);
    this.dialogos.on("preStart", function(e){
        if(e.atualIndex == 0 || e.atualIndex == 2)
            e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        //self.emit("removeAll");
    });    
    
    this.dialogos.play();
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}