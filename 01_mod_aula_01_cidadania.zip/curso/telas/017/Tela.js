function Tela()
{
    tls.core.Factory.call(this, "telas/017/sprites.json");
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/017/17_1.mp3");
    this.soundManager.addSingleSound("telas/017/17_2.mp3");
    this.soundManager.addSingleSound("telas/017/17_3.mp3");
    this.soundManager.addSingleSound("telas/017/17_4.mp3");
    this.soundManager.addSingleSound("telas/017/17_5.mp3");
    
    this.dialogos;
    
    this.correct = 0;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 4;
        this.feedFailIndex = 3;
        this.bocaFeedOkIndex = 0;
        this.bocaFeedFailIndex = 0;
        this.soundOkIndex = this.soundManager._sounds.length-1;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;    
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0, 0, 0, 0], 3);
    this.dialogos.on("preStart", function(e){
        
    });
    
    this.dialogos.on("start", function(e){
        console.log(e.atualIndex)
        e.ballon.direction = "-";
        if(e.atualIndex == 3)
        {
            setTimeout(function(){
                console.log(self.audios[1])
                self.audios[1].stopAnimation();
            }, 600);
            
        }
    });
    this.dialogos.on("end", function(e){
        console.log(self.areaDrags)
        this.removeListener("end");
        
         //self.audios[1].stopAnimation();
        
        self.addDragsEvents();
    });
    
    this.configureDrags();
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    self.removeDragsEvents();  
    
    //this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.feedFailIndex, function(){
    setTimeout(function(){
        self.addDragsEvents();        
    }, 650);
    //});
}

Tela.prototype.setOk = function()
{
    var self  = this;
    self.removeDragsEvents();  
    
    self.correct++;

    if(self.correct >= 3)
    {
            self.ballons[3].close();
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);                
        });

        return;
    }

    self.addDragsEvents();        
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    this.removeDragsEvents();
    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound);  
}

controlY = 0;
rh = 0;
Drag.prototype._adjust = function()
{

/*    var r = this._collisions[this._index];
    rh = (rh == 0) ? r.height / 3 : rh;
    controlY = (controlY == 0) ? r.y + 50 : controlY;
    TweenMax.to(this.position, 0.5, {x: r.x + r.width / 2, y: controlY, ease: Back.easeOut});
    controlY += rh;*/
    this.alpha = 0;
}

Tela.prototype.configureDrags = function()
{
    var self = this;
    
    
    self.drags[0].collisions = [self.areaDrags[0]];
    self.drags[1].collisions = [self.areaDrags[0]];
    self.drags[2].collisions = [self.areaDrags[0]];
    
    
    for(var i = 0; i < self.drags.length; i++)
    {
      
        
        self.drags[i].usePoint = true;
        self.drags[i].adjust = true;        
        
        self.drags[i].on("incorrect", function(e){
            self.setFail();
        });

        self.drags[i].on("correct", function(e){
            this.removeListener("correct");
            self.setOk();
        });
    }
}

Tela.prototype.addDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].addEvents();
    }
}

Tela.prototype.removeDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].removeEvents();
    }
}

Tela.prototype.destroy = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].destroy();
    }
    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}