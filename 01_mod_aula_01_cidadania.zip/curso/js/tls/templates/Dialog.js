/**
* Classe que faz o controle dos diálogos,
* abre e fecha os balões e executa o áudio
*
* a classe fornece métodos e eventos de controle
*
* ```js
* var dialogo = new tls.template.Dialog(factory, soundManager, mouthOrder);
* 
* dialogo.on('preStart', function(e){ });
* dialogo.on('paused', function(e){ });
* dialogo.on('start', function(e){ });
* dialogo.on('end', function(e){ });
*
* dialogo.on('soundStart', function(e){ });
* dialogo.on('soundComplete', function(e){ });
*
* dialogo.play();
* dialogo.pause();
*
* //Objeto e = {atualIndex: {number}, ballon: {tls.display.Ballon}};
* ```
*
* @class
* @extends EventEmitter
* @memberof tls.templates
* @param factory {tls.core.Factory} classe geral onde ficam armazenados todos os objetos
* @param soundManager {tls.media.SoundManager} objeto que controla os audios
* @param mouthOrder {number[]} array numérico com a ordem das bocas dos personagens
*/
function Dialog(factory, soundManager, mouthOrder, e_order)
{
    EventEmitter.call(this);
    
    this._eOrder = e_order || null;
    
    this._factory = factory;
    this._soundManager = soundManager;
    this._mouthOrder = mouthOrder
    this._length = mouthOrder.length;
    
    this._ballons = this._factory.ballons;
    this._audios = this._factory.audios;
    this._mouths = this._factory.bocas;
    
    
    this._atualIndex = 0;
    this._atualMouth = 0;
    this._paused = false;
    
    this._isSpecial = false;
    
    this._audios[0].setAudio(this._soundManager, 0);
    var index = 0;
   
    if(this._ballons[this._ballons.length - 1].type == tls.display.Ballon.ESPECIAL)
    {
        var e = this._ballons.pop();
        if(e_order && e_order > 0 && this._audios.length > 1)
        {
            this._audios[1].setAudio(this._soundManager, e_order);
            e.setAudioButton(this._audios[1]);
        }
        this._ballons.splice(e_order || 0, 0, e);
    }
    
    this._ballons[0].setAudioButton(this._audios[0]);
    
    for(var i = 1; i < this._mouthOrder.length; i++)
    {            
        this._ballons[i].setSoundManager(this._soundManager, i);
        this._ballons[i].noAudio = true;
    }
    
    /**
    * Disparado antes de iniciar, ao preparar para o inicio
    *
    * @event preStart
    * @menberof Dialog#
    */
    
    /**
    * Disparado ao pausar a sequência
    *
    * @event paused
    * @memberof Dialog#
    */
    
    /**
    * Disparado quando inicia a sequencia
    *
    * @event start
    * @memberof Dialog#
    */
    
    /**
    * Disparado quando termina toda a sequência
    *
    * @event end
    * @memberof Dialog#
    */
    
    /**
    * Disparado quando começa a tocar o som
    *
    * @event soundStart
    * @memberof Dialog#
    */
    
    /**
    * Disparado quando termina de tocar o som
    *
    * @event soundComplete
    * @memberof Dialog#
    */
}

Dialog.prototype = Object.create(EventEmitter.prototype);
Dialog.prototype.constructor = Dialog;

/**
* Inicia a sequência
* 
* @memberof Dialog
* @fires preStart
* @public
*/
Dialog.prototype.play = function()
{
    this.emit("preStart", {atualIndex: this._atualIndex, ballon: this._ballons[this._atualIndex]});
    this._paused = false;
    this._openBallon(this._atualIndex);
}

/**
* Pausa a sequência
*
* @memberof Dialog
* @fires paused
* @public
*/
Dialog.prototype.pause = function()
{
    this._paused = true;
    this.emit("paused", {atualIndex: this._atualIndex});
}

/**
* Método responsável pelo inicio da sequência e adição dos listeners de audio
*
* @memberof Dialog
* @fires start
* @fires soundStart
* @param index {number} index da ordem da sequência
* @private
*/
Dialog.prototype._openBallon = function(index)
{    
    //verificação de pausa antes de iniciar
    if(this._paused) return;
    
    /**
    * @fires start
    */
    this.emit("start", {atualIndex: this._atualIndex, ballon: this._ballons[this._atualIndex]});
    
    //ultima verificaçã de pausa antes de iniciar
    if(this._paused) return;
    
    
    var b = this._ballons[this._atualIndex];
    if(this._atualIndex > 0) b.noAudio = true;
    var m = this._mouthOrder != null ? this._mouths[this._mouthOrder[this._atualMouth]] : null;
    
    var self = this;
    
    /**
    * listener no balão para verificar quando o som inicia
    * 
    * @fires soundStart
    */
    b.on("soundStart", function(e){
        //this.removeListener("soundStart");
        if(this.repeat != true)
        self.emit("soundStart");
        
        if(m != null) m.play();
    });
    
    /**
    * listener para verificar quando o som termina
    *
    * @fires soundComplete
    */
    b.on("soundComplete", function(e){
        //this.removeListener("soundComplete");
        if(this.repeat != true)
        self.emit("soundComplete", {atualIndex: self._atualIndex});       
        
        if(m != null)
        {
            m.gotoAndStop(m.stationary);
            m = null;
        }
        
        /**
        * Se o balão for do tipo dialogo normal, fecha o balão ao final do som
        * Se não, o balão permanece aberto
        */
        if(this.type == tls.display.Ballon.NORMAL)
        {
            this.removeListener("soundComplete");
            this.close();
        }
        else
        {
            if(self._atualMouth >= self._mouthOrder.length)
            {
                self._atualMouth = self._mouthOrder.length - 1;
            }
            m = self._mouths[self._mouthOrder[self._atualMouth]];
        }
        
        //verifica a continuidade da sequência
        if(this.repeat != true)
        self._checkSequence();
        
        this.repeat = true;
    });
    
    //abre o balão
    b.open();
}

/**
* Verifica se a sequência chegou ao fim
*
* @memberof Dialog
* @fires preStart
* @fires end
* @private
*/
Dialog.prototype._checkSequence = function()
{
    this._atualIndex++;
    this._atualMouth++;
    
    if(this._isSpecial)
    {
        console.log(this._mouthOrder.length)
        console.log("atual..." + this._atualMouth)
        console.log(" mouth..." + (this._atualMouth == this._mouthOrder.length - 2))
        if(this._atualMouth == this._mouthOrder.length - 1) this._atualIndex = this._ballons.length - 1;
    }
    
    if(this._atualIndex >= this._length)
    {
        this.emit("end");
        return;
    }
    
    this.emit("preStart", {atualIndex: this._atualIndex, ballon: this._ballons[this._atualIndex]});
    this._openBallon(this._atualIndex);
}

/**
* Suporte para limpar a memória
* destroi todos os objetos e remove os eventos
*
* @memberof Dialog
* @public
*/
Dialog.prototype.destroy = function()
{
    this.removeAllListeners();
    this._factory = null;
    for(var i = 0; i < this._ballons.length; i++)
    {
        this._ballons[i].destroy();
        try{
            this._audios[i].destroy();
        }
        catch(err){}
    }
    
    for(var i = 0; i < this._mouths.length; i++)
    {
        this._mouths[i].destroy();
    }
}

tls.templates.Dialog = Dialog;

