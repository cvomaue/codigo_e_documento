function TintObject(texture)
{
    PIXI.Sprite.call(this, texture);
    
    this._type;
    this._color;
    
    this._feed = new PIXI.Sprite(texture);
    this._feed.alpha = 0;
    this.addChild(this._feed);
}

TintObject.prototype = Object.create(PIXI.Sprite.prototype);
TintObject.prototype.constructor = TintObject;

Object.defineProperties(TintObject.prototype, {
    type: {
        get: function(){
            return this._type;
        },
        set: function(value){
            this._type = value;
            switch(this._type)
            {
                case TintObject.CORRECT:
                    this._color = 0x1ba218;
                    break;
                case TintObject.INCORRECT:
                    this._color = 0xa21818;
                    break;
            }
            
            this._feed.tint = this._color;
        }
    },
    
    blend: {
        set: function(value){
            this.blendMode = value;
            this._feed.blendMode = value;
        }
    }
});

TintObject.prototype.color = function(color)
{
    var self = this;
    
    if(color != null && color != undefined) this._feed.tint = color;
    
    TweenMax.to(this._feed, 0.3, {alpha: 1});
}

TintObject.prototype.uncolor = function()
{
    var self = this;
    
    TweenMax.to(this._feed, 0.3, {alpha: 0});
}

TintObject.prototype.destroy = function()
{
    this.removeChildren();
    this.removeListeners();
    
    this._feed.destroy(true, true);
    this._feed = null;
    
    PIXI.Sprite.prototype.destroy.call(this, true, true);
}

TintObject.CORRECT = "correct";
TintObject.INCORRECT = "incorrect";

tls.display.TintObject = TintObject;