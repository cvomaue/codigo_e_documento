function CrossWord(rows, cols, letters, sizeField)
{
    PIXI.Container.call(this);
    
    this._rows = rows;
    this._cols = cols;
    this._letters = letters.split(",");
    this._sizeField = sizeField;
    this._fields = [];
    
    this._isMove = false;
    this._currentWord = "";
    this._currentFields = [];
    this._corrects = [];
    
    this._feeds = [];
    
    this._feedStroke = 2;
    
    for(var i = 0; i < this._rows; i++)
    {
        for(var j = 0; j < this._cols; j++)
        {
            var f = new tls.display.CrossField(this._sizeField.width, this._sizeField.height);
            f.x = f.width / 2 + (f.width * j);
            f.y = f.height / 2 + (f.height * i);
            f.index = this._cols * i + j;
            f.text = this._letters[f.index];
            
            this._fields.push(f);
            this.addChild(f);
        }
    }
}

CrossWord.prototype = Object.create(PIXI.Container.prototype);
CrossWord.prototype.constructor = CrossWord;

Object.defineProperties(CrossWord.prototype, {
    corrects: {
        set: function(value){
            this._corrects = value;
        }
    },
    
    debug: {
        set: function(value){
            for(var i = 0; i < this._fields.length; i++)
            {
                this._fields[i].debug = value;
            }
        }
    },
    
    lineColor: {
        set: function(value){
            for(var i = 0; i < this._fields.length; i++)
            {
                this._fields[i].lineColor = value;
            }
        }
    },
    
    feedStroke: {
        get: function(){
            return this._feedStroke;
        },
        
        set: function(value){
            this._feedStroke = value;
        }
    }
});

CrossWord.prototype.addEvents = function()
{
    this.interactive = true;
    
    this
        .on('mousedown', this._onDown)
        .on('touchstart', this._onDown)

        .on('mouseup', this._onUp)
        .on('touchend', this._onUp)
        .on('mouseupoutside', this._onUp)
        .on('touchendoutside', this._onUp)

        .on('mousemove', this._onMove)
        .on('touchmove', this._onMove);
}

CrossWord.prototype.removeEvents = function()
{
    this.interactive = false;
    
    this
        .removeListener('mousedown', this._onDown)
        .removeListener('touchstart', this._onDown)

        .removeListener('mouseup', this._onUp)
        .removeListener('touchend', this._onUp)
        .removeListener('mouseupoutside', this._onUp)
        .removeListener('touchendoutside', this._onUp)

        .removeListener('mousemove', this._onMove)
        .removeListener('touchmove', this._onMove);
}

CrossWord.prototype._onDown = function(e)
{
    this._isMove = true;

    var p = e.data.getLocalPosition(this.parent);
    this._checkTouch(p);

    this.data = e.data;
    this.local = this.data.getLocalPosition(this);
}

CrossWord.prototype._onUp = function(e)
{
    this._isMove = false;

    this._clear();
    this._checkWord();
}

CrossWord.prototype._onMove = function(e)
{
    if(this._isMove)
    {   
        var newPosition = this.data.getLocalPosition(this.parent);

        this._checkTouch(newPosition);
    }
}

CrossWord.prototype._checkTouch = function(point)
{
    var p = point;

    for(var i = 0; i < this._fields.length; i++)
    {
        var g = this._fields[i].sensor.toGlobal(this._fields[i].sensor.position);
        var a = new PIXI.Rectangle(g.x, g.y, this._fields[i].sensor.width, this._fields[i].sensor.height);

        if(p.x > a.x && p.x < a.x + a.width && p.y > a.y && p.y < a.y + a.height && !this._fields[i].turnOn)
        {
            this._fields[i].turnOn = true;
            this._currentWord += this._fields[i].text;
            this._currentFields.push(this._fields[i]);
            
            console.log(this._currentWord)
        }
    }
}

CrossWord.prototype._clear = function()
{
    for(var i = 0; i < this._fields.length; i++)
    {
        this._fields[i].turnOn = false;
    }
}

CrossWord.prototype._checkWord = function()
{
    var isok = false;
    console.log(this._currentWord)

    for(var i = 0; i < this._corrects.length; i++)
    {
        if(this._corrects[i] == this._currentWord)
        {
            this.emit("correct");

            this._drawFeed();

            isok = true;

            break;
        }
    }

    if(!isok)
    {
        this.emit("incorrect");
    }

    this._currentWord = "";
    this._currentFields.splice(0, this._currentFields.length);
}

CrossWord.prototype._drawFeed = function()
{
    if(this._currentFields[0].x != this._currentFields[this._currentFields.length - 1].x && this._currentFields[0].y != this._currentFields[this._currentFields.length - 1].y)
    {
        this._drawDiagonal();
    }
    else
    {
        this._drawRect();
    }
}

CrossWord.prototype._drawRect = function()
{
    var i = this._currentFields[0];
    var f = this._currentFields[this._currentFields.length - 1];
    
    var feed = new PIXI.Graphics();
    //feed.lineStyle(this._feedStroke, 0x1ba218, 1);
    feed.beginFill(0x1ba218, 1);
    feed.drawRect(i.x - i.width / 2, i.y - i.height / 2, f.x - i.x + i.width, f.y - i.y + i.height);
    feed.endFill();
    feed.blendMode = PIXI.BLEND_MODES.MULTIPLY;
    
    this._feeds.push(feed);
    this.addChild(feed);    
    this._currentFields.splice(0, this._currentFields.length);
}

CrossWord.prototype._drawDiagonal = function()
{
    var i = this._currentFields[0];
    var f = this._currentFields[this._currentFields.length - 1];
    
    var feed = new PIXI.Graphics();
    //feed.lineStyle(this._feedStroke, 0x1ba218, 1);
    feed.beginFill(0x1ba218, 1);
    if(i.x < f.x)
    {
        feed.moveTo(i.x - i.width, i.y);
        feed.lineTo(f.x, f.y + f.height);
        feed.lineTo(f.x + f.width, f.y);
        feed.lineTo(i.x, i.y - i.height);
    }
    else
    {
        feed.moveTo(i.x + i.width, i.y);
        feed.lineTo(f.x, f.y + f.height);
        feed.lineTo(f.x - f.width, f.y);
        feed.lineTo(i.x, i.y - i.height);
    }
    
    feed.endFill();
    feed.blendMode = PIXI.BLEND_MODES.MULTIPLY;
    
    this._feeds.push(feed);
    this.addChild(feed);    
    this._currentFields.splice(0, this._currentFields.length);
}

CrossWord.prototype.destroy = function()
{
    this.removeChildren();
    this.removeAllListeners();
    
    for(var i = 0; i < this._fields.length; i++)
    {
        this._fields[i].destroy();
        this._fields[i] = null;
    }
    
    for(i = 0; i < this._feeds.length; i++)
    {
        this._feeds[i].destroy();
        this._feeds[i] = null;
    }
    
    PIXI.Container.prototype.destroy.call(this);
}

tls.display.CrossWord = CrossWord;