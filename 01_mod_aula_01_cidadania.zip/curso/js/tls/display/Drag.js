function Drag(texture)
{
    AnimateButton.call(this, texture);
    this.on("textureComplete", function(e){
        this.removeListener("textureComplete");
        
        this.pivot.set(0);
    });
    
    var self = this;
    
    this._isMove = false;    
    this._isAdjust = true;    
    this._usePoint = false;
    
    this._obstacles = [];    
    this._useObstacles = false;
    
    this._isOff = false;
    
    this._impactForce = 20;
    
    this._lockArea = false;
    
    this._collisions = [];
    
    this._index;
    
    this._reset = true;
    
    this._addedToStage = setInterval(function(){
        if(self.parent != null && self.parent != undefined)
        {
            clearInterval(self._addedToStage);
            self._originalPosition = new PIXI.Point(self.x, self.y);
        }
    }, 100);
}

Drag.prototype = Object.create(AnimateButton.prototype);
Drag.prototype.constructor = Drag;

Object.defineProperties(Drag.prototype, {
    index: {
        get: function(){
            return this._index;
        },
        set: function(value){
            this._index = value;
        }
    },
    
    adjust: {
        get: function(){
            return this._isAdjust;
        },
        set: function(value){
            this._isAdjust = value;
        }
    },
    
    collisions: {
        get: function(){
            return this._collisions;
        },
        set: function(_collisions){
            this._collisions = _collisions;
        }
    },
    
    usePoint: {
        get: function(){
            return this._usePoint;
        },
        set: function(value){
            this._usePoint = value;
        }
    },
    
    useObstacles: {
        get: function(){
            return this._useObstacles;
        },
        set: function(value){
            if(value)
                if(this._obstacles.length > 0) this._useObstacles = value;
                else this._useObstacles = false;
        }
    },
    
    obstacles: {
        get: function(){
            return this._obstacles;
        },
        set: function(_obstacles){
            this._obstacles = _obstacles;
        }
    },
    
    isOff: {
        get: function(){
            return this._isOff;
        },
        set: function(value){
            this._isOff = value;
        }
    },
    
    lockColision: {
        set: function(value){
            this._lockArea = value;
        }
    },
    
    reset: {
        set: function(value){
            this._reset = value;
        }
    }
});

Drag.prototype.addEvents= function()
{
    AnimateButton.prototype.addEvents.call(this);
    
    this
        .on('mousemove', this._onMove)
        .on('touchmove', this._onMove);
}

Drag.prototype.removeEvents = function()
{
    AnimateButton.prototype.removeEvents.call(this);   
    
    var self = this;
    
    this
        .removeListener('mousemove', this._onMove)
        .removeListener('touchmove', this._onMove);
}

Drag.prototype._onDown = function(e)
{
    this._isMove = true;
        
    if(this.parent != null && this.parent)
    {
        var p = this.parent;
        p.setChildIndex(this, p.children.length - 1);
    }

    this._data = e.data;
    this._local = this._data.getLocalPosition(this);
}

Drag.prototype._onUp = function(e)
{    
    this._isMove = false;
    this._data = null;

    var t = this._checkColision();
    if(t.result)
    {   
        this._setIndex(t.index);
        
        var r = this._collisions[this._index];
        if(this.x <= r.x)
            TweenMax.to(this, 0.2, {x: r.x + this.width / 2});
        if(this.x >= r.x + r.width)
            TweenMax.to(this, 0.2, {x: r.x + r.width - this.width / 2});
        if(this.y <= r.y)
            TweenMax.to(this, 0.2, {y: r.y + this.height / 2});
        if(this.y >= r.y + r.height)
            TweenMax.to(this, 0.2, {y: r.y + r.height - this.height / 2});

        if(this._isAdjust)
        this._adjust();

        this.emit("correct", e);
        console.log("correct")
    }
    else
    {
        if(this._reset)
        this._resetPosition();

        this.emit("incorrect", e);
    }
}

Drag.prototype._onMove = function(e)
{
    if(this._isMove)
    {   
        var newPosition = this._data.getLocalPosition(this.parent);
        this.position.x = newPosition.x - this._local.x;
        this.position.y = newPosition.y - this._local.y;

        if(this._useObstacles) this._checkObstacles();
    }
}

Drag.prototype._checkColision = function()
{        
    var self = this;
    var result = false;
    var index;

    if(!this._usePoint)
    for(var i = 0; i < this._collisions.length; i++)
    {
        if(this.x - this.width / 2 > this._collisions[i].x &&
           this.x + this.width / 2 < this._collisions[i].x + this._collisions[i].width &&
           this.y - this.height / 2 > this._collisions[i].y &&
           this.y + this.height / 2 < this._collisions[i].y + this._collisions[i].height)
        {
            if(this._lockArea)
            {
                if(this._collisions[i].lock != undefined && this._collisions[i].lock != null) continue;
                else this._collisions[i].lock = true;
            }
            index = i;
            result = true;
            
            if(this._collisions[i].addDrag != undefined && this._collisions[i].addDrag != null){
                this._collisions[i].addDrag(this);
            }
                
            break;
        }
    }
    else
    for(var i = 0; i < this._collisions.length; i++)
    {
        if(this.x + this.width / 2 > this._collisions[i].x &&
          this.x  - this.width / 2 < this._collisions[i].x + this._collisions[i].width &&
          this.y + this.height / 2 > this._collisions[i].y &&
          this.y - this.height / 2 < this._collisions[i].y + this._collisions[i].height)
        {
            if(this._lockArea)
            {
                if(this._collisions[i].lock != undefined && this._collisions[i].lock != null) continue;
                else this._collisions[i].lock = true;
            }
            index = i;
            result = true;
            
            if(this._collisions[i].addDrag != undefined && this._collisions[i].addDrag != null){
                this._collisions[i].addDrag(this);
            }
                
            break;
        }
    }

    return {result: result, index: index};
}

Drag.prototype._checkObstacles = function()
{
    var self = this;
    for(var i = 0; i < this._obstacles.length; i++)
    {
        var o = this._obstacles[i];

        if(this.x + this.width / 2 > o.x && this.x - this.width / 2 < o.x + o.width &&
        this.y - this.height / 2 < o.y + o.height && this.y + this.height / 2 > o.y)
        {
            console.log("mentira")
            this._isMove = false;
            this.removeEvents();
            
            var returnPos = 2;

            if(this.x <= o.x) TweenMax.to(this, 0.3, {x: "-=" + returnPos});
            else if(this.x > o.x) TweenMax.to(this, 0.3, {x: "+=" + returnPos});

            if(this.y <= o.y) TweenMax.to(this, 0.3, {y: "-=" + returnPos});
            else if(this.y > o.y) TweenMax.to(this, 0.3, {y: "+=" + returnPos});

            setTimeout(function(){
                self.addEvents();
            }, 400);

            break;
        }
    }
}

Drag.prototype._adjust = function()
{
    var r = this._collisions[this._index];

    TweenMax.to(this.position, 0.5, {x: r.x + r.width / 2, y: r.y + r.height / 2, ease: Back.easeOut});
}

Drag.prototype.adjustToToBottom = function()
{
    var r = this._collisions[this._index];
    
    if(this.y + this.height / 2 > r.y + r.height)
        TweenMax.to(this, 0.3, {y: (r.y + r.height) - this.height / 2});
}

Drag.prototype._resetPosition = function()
{
    if(this._isOff) return;
    TweenMax.to(this.position, 0.5, {x: this._originalPosition.x, y: this._originalPosition.y, ease: Back.easeOut});
}

Drag.prototype._setIndex = function(value)
{
    this._index = value;
}

tls.display.Drag = Drag;