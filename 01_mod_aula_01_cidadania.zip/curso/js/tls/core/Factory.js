function Factory(_json)
{
    Base.call(this);
    
    var self = this;
    
    this._textureURL = _json;
    //this._xmlURL = _xml;
    
    this._xml;
    this._img;
    
    this._images = [];
    this._bocas = [];
    this._ballons = [];
    this._audios = [];
    this._clicks = [];
    this._drags = [];
    this._areaDrags = [];
    this._obstacles = [];
    
    this._lines0 = [];
    this._lines1 = [];
    
    this._lines = [];
    
    this._stars = [];
    this._icons = [];
    
    this._inputs = [];
    
    this._txfields = [];
    
    this._feeds = [];
    this._feedsI = [];
    this._feedsO = [];
    
    this._txGroup;
    
    this._fadeSequence = null;
    this._fades = [];
    
    this._vTexture;
    this._fTexture;
    
    this._baldes = [];
    this._tints = [];
    
    this._calcKeys = [];
    this._calcResults = [];
    
    this._bexigas = [];
    this._agulhas = [];
    
    this._cards = [];
    
    this._layers = {
        images: new PIXI.Container(),
        bocas: new PIXI.Container(),
        interactions: new PIXI.Container(),
        ballons: new PIXI.Container(),
        audios: new PIXI.Container(),
        sup: new PIXI.Container()
    }
    
    this._inputTheme = new GOWN.ShapeTheme();
    this._inputTheme.textStyle = {
        "fill": "#000",
        "font": "30px Angola"
    };
    
    this.addChild(this._layers.images);
    this.addChild(this._layers.bocas);
    this.addChild(this._layers.interactions);    
    this.addChild(this._layers.ballons);
    this.addChild(this._layers.audios);
    this.addChild(this._layers.sup);
    
    this._loadTexture();
}

Factory.prototype = Object.create(Base.prototype);
Factory.prototype.constructor = Factory;

Object.defineProperties(Factory.prototype, {
    images:     { get: function(){ return this._images } },
    bocas:      { get: function(){ return this._bocas } },
    ballons:    { get: function(){ return this._ballons } },
    audios:     { get: function(){ return this._audios } },
    clicks:     { get: function(){ return this._clicks } },
    drags:      { get: function(){ return this._drags } },
    areaDrags:  { get: function(){ return this._areaDrags } },
    obstacles:  { get: function(){ return this._obstacles } },
    lines:      { get: function(){ return this._lines } },
    stars:      { get: function(){ return this._stars } },
    icons:      { get: function(){ return this._icons } },
    inputs:     { get: function(){ return this._inputs } },
    txFields:   { get: function(){ return this._txFields } },
    feeds:      { get: function(){ return this._feeds } },
    feedsI:     { get: function(){ return this._feedsI } },
    feedsO:     { get: function(){ return this._feedsO } },
    fadeSequence: { get: function(){ return this._fadeSequence } },
    txGroup:    { get: function(){ return this._txGroup } },
    baldes:     { get: function(){ return this._baldes } },
    tints:      { get: function(){ return this._tints } },
    calcKeys:   { get: function(){ return this._calcKeys } },
    calcResults:{ get: function(){ return this._calcResults } },
    cards:      { get: function(){ return this._cards } },
    bexigas:    { get: function(){ return this._bexigas } },
    agulhas:    { get: function(){ return this._agulhas } }
});

Factory.prototype._loadTexture = function()
{
    var self = this;
    
    var lo = new PIXI.loaders.Loader();
    lo.add("mainTexture", this._textureURL);
    lo.load(function(e, resources){        
        self._configureElements(resources.mainTexture.data.frames);
    });
}

Factory.prototype._configureElements = function(e)
{
    var self = this;
    
    for(var i in e)
    {        
        if(i.indexOf("img")                 != -1)  self._createImage(e[i], i);
        else if(i.indexOf("boca")           != -1)  self._createBoca(e[i], tls.display.Boca.TYPE_NORMAL);
        else if(i.indexOf("focinhoGato")    != -1)  self._createBoca(e[i], tls.display.Boca.TYPE_GATO);
        else if(i.indexOf("balao")          != -1) {
            if(i.indexOf("balaoE") != -1)
                self._createBallon(e[i], i, tls.display.Ballon.ESPECIAL);
            else
                self._createBallon(e[i], i, tls.display.Ballon.NORMAL);
        }
        else if(i.indexOf("audio")          ==  0)  self._createAudio(e[i]);
        else if(i.indexOf("click")          != -1)  self._createClickArea(e[i]);
        else if(i.indexOf("drag")           != -1)  self._createDrag(e[i], i);
        else if(i.indexOf("areaDrag")       != -1)  self._createAreaDrag(e[i]);
        else if(i.indexOf("obstacles")      != -1)  self._createObstacles(e[i]);
        else if(i.indexOf("star")           != -1)  self._createStar(e[i], i);
        else if(i.indexOf("icon")           != -1)  self._createIcon(e[i], i);
        else if(i.indexOf("input")          ==  0)  self._createInput(e[i]);
        else if(i.indexOf("fade")           != -1)  self._createFadeSequence(e[i], i);
        else if(i.indexOf("feedI")          != -1)  self._createFeed(e[i], tls.display.FeedObject.FAIL, i);
        else if(i.indexOf("feedO")          != -1)  self._createFeed(e[i], tls.display.FeedObject.OK, i);
        else if(i.indexOf("balde")          != -1)  self._createBucket(e[i], i);
        else if(i.indexOf("tintI")          != -1)  self._createTint(e[i], i, TintObject.INCORRECT);
        else if(i.indexOf("tintO")          != -1)  self._createTint(e[i], i, TintObject.CORRECT);
        else if(i.indexOf("calc")           != -1)  self._createCalcKeys(e[i], i);
        else if(i.indexOf("res")            != -1)  self._createCalcResult(e[i], i);
        else if(i.indexOf("card")           != -1)  self._createCard(e[i], i);
        else if(i.indexOf("bexiga")         != -1)  self._createBexiga(e[i], i);
        else if(i.indexOf("agulha")         != -1)  self._createAgulha(e[i], i);
        else if(i.indexOf("line0")          != -1)
            self._lines0.push(new PIXI.Rectangle(e[i].spriteSourceSize.x, e[i].spriteSourceSize.y, e[i].frame.w, e[i].frame.h));
        else if(i.indexOf("line1")          != -1)
            self._lines1.push(new PIXI.Rectangle(e[i].spriteSourceSize.x, e[i].spriteSourceSize.y, e[i].frame.w, e[i].frame.h));
        else if(i.indexOf("txGroup")        != -1)
        {
            if(self._txGroup == null || self._txGroup == undefined) 
                self._txGroup = new tls.text.TxGroup();
            
            if(i.indexOf("back")    != -1)        self._createImage(e[i], i, self._txGroup);
            if(i.indexOf("audio")   != -1)        self._createAudio(e[i], self._txGroup);
            if(i.indexOf("input")   != -1)
            {
                var tx = i
                var prev = i.search(/_\d/);
                var next = i.indexOf("$_");
                var max = parseInt(tx.substr(prev + 1, next - (prev + 1)));
                
                self._createInput(e[i], max, self._txGroup);
            }
        }
    }
    
    if(this._lines0.length > 0)
    {
        for(var i = 0; i < this._lines0.length; i++)
        {
            var l = new tls.display.Line([this._lines0[i], this._lines1[i]]);
            this._layers.interactions.addChild(l);
            this._lines.push(l);
        }
    }
    
    if(this._fades.length > 0)
    {
        this._fadeSequence = new tls.templates.FadeSequence(this._fades);
        this._layers.interactions.addChild(this._fadeSequence);
    }
    
    if(this._txGroup != null && this._txGroup != undefined) 
    {
        this._layers.interactions.addChild(this._txGroup);
    }
    
    this.emit("complete"); 
}

Factory.prototype._createImage = function(config, name, container)
{    
    var _container = container || this._layers.images;
    var arr = container ? container._images : this._images;
    
    var i = new tls.display.ImageEx(this._baseCrop(name));
    i.x = config.spriteSourceSize.x + i.width / 2;
    i.y = config.spriteSourceSize.y + i.height / 2;

    _container.addChild(i);
    arr.push(i);
}

Factory.prototype._createBoca = function(config, type)
{     
    var boca = new tls.display.Boca(type);
    boca.width = config.frame.w;
    boca.height = config.frame.h;
    boca.x = config.spriteSourceSize.x;
    boca.y = config.spriteSourceSize.y;

    boca.gotoAndStop(boca.stationary);

    this._layers.bocas.addChild(boca);
    this._bocas.push(boca);    
}

Factory.prototype._createBallon = function(config, name, type)
{    
    var t = this._baseCrop(name);
    var b = new tls.display.Ballon(t);
    b.type = type;
    b.x = config.spriteSourceSize.x;
    b.y = config.spriteSourceSize.y;

    this._layers.ballons.addChild(b);
    this._ballons.push(b);
}

Factory.prototype._createAudio = function(config, container)
{
    var _container = container || this._layers.audios;
    var arr = container ? container._audios : this._audios;
    
    var a = new tls.buttons.AudioButton();
    a.x = config.spriteSourceSize.x + a.width / 2;
    a.y = config.spriteSourceSize.y + a.height / 2;

    _container.addChild(a);
    arr.push(a);
}

Factory.prototype._createClickArea = function(config)
{
    var c = new tls.buttons.AreaButton(config.frame.w, config.frame.h);
    c.x = config.spriteSourceSize.x;
    c.y = config.spriteSourceSize.y;

    this._layers.interactions.addChild(c);
    this._clicks.push(c);
}

Factory.prototype._createDrag = function(config, name)
{
    var d = new tls.display.Drag(this._baseCrop(name));
    d.collisions = [new PIXI.Rectangle(0,0,2,2)];
    d.x = config.spriteSourceSize.x + d.width / 2;
    d.y = config.spriteSourceSize.y + d.height / 2;

    this._layers.interactions.addChild(d);
    this._drags.push(d);
}

Factory.prototype._createAreaDrag = function(config)
{
    var a = new PIXI.Rectangle(config.spriteSourceSize.x, config.spriteSourceSize.y, config.frame.w, config.frame.h);

    this._areaDrags.push(a);
}

Factory.prototype._createObstacles = function(config)
{
    var o = new PIXI.Rectangle(config.spriteSourceSize.x, config.spriteSourceSize.y, config.frame.w, config.frame.h);

    this._obstacles.push(o);
}

Factory.prototype._createStar = function(config, name)
{
    var s = this._createAnimateButton(config, name);
    this._stars.push(s);
    this._layers.interactions.addChild(s);
}

Factory.prototype._createIcon = function(config, name)
{
    var s = this._createAnimateButton(config, name);
    this.icons.push(s);
    this._layers.interactions.addChild(s);
}

Factory.prototype._createInput = function(config, maxChars, container)
{
    var _max = maxChars || 1;
    var _container = container || this._layers.interactions;
    var arr = container ? container._inputs : this._inputs;
    
    var input = new tls.text.TxInput({width: config.frame.w, height: config.frame.h}, _max, this._inputTheme);
    input.x = config.spriteSourceSize.x;
    input.y = config.spriteSourceSize.y;

    arr.push(input);
    _container.addChild(input);
}

Factory.prototype.createTextField = function(config)
{
    var tx = new PIXI.Text("", {font: (config.height - 2) + "px Angola", fill: 0x000000, align: "center", wordWrap: true, wordWrapWidth: config.width});
    tx.boundW = config.width;
    tx.boundH = config.height;

    tx.x = config.pivotX;
    tx.y = config.pivotY;

    this._txfields.push(tx);
    this._layers.interactions.addChild(tx);
}

Factory.prototype._createFeed = function(config, type, name)
{    
    var f = new tls.display.FeedObject(this._baseCrop(name), type);
    f.x = config.spriteSourceSize.x + f.width / 2;
    f.y = config.spriteSourceSize.y + f.height / 2;
    
    if(type == tls.display.FeedObject.FAIL) this._feedsI.push(f);
    else this._feedsO.push(f);
    
    if(name.indexOf("$v") != -1)
    {
        if(this._vTexture == null || this._vTexture == undefined) this._vTexture = f.texture.clone();
        
        f.swapTexture(this._vTexture);
    }
    
    if(name.indexOf("$f") != -1)
    {
        if(this._fTexture == null || this._fTexture == undefined) this._fTexture = f.texture.clone();
        
        f.swapTexture(this._fTexture);
    }
    
    this._feeds.push(f);
    this._layers.interactions.addChild(f);
}

Factory.prototype._createFadeSequence = function(config, name)
{
    var i = new tls.display.ImageEx(this._baseCrop(name));
    i.x = config.spriteSourceSize.x + i.width / 2;
    i.y = config.spriteSourceSize.y + i.height / 2;
    
    this._fades.push(i);
}

Factory.prototype._createAnimateButton = function(config, name)
{
    var s = new tls.buttons.AnimateButton(this._baseCrop(name));
    s.x = config.spriteSourceSize.x + s.width / 2;
    s.y = config.spriteSourceSize.y + s.height / 2;
    
    return s;
}

Factory.prototype._createTint = function(config, name, type)
{
    var t = new tls.display.TintObject(this._baseCrop(name));
    t.type = type;
    
    t.x = config.spriteSourceSize.x;
    t.y = config.spriteSourceSize.y;
    
    this._tints.push(t);
    this._layers.images.addChild(t);
}

Factory.prototype._createBucket = function(config, name)
{
    var b = new tls.display.Bucket(this._baseCrop(name));
    b.x = config.spriteSourceSize.x;
    b.y = config.spriteSourceSize.y;
    
    this._baldes.push(b);
    this._layers.sup.addChild(b);
}

Factory.prototype._createCalcKeys = function(config, name)
{
    var key = new tls.buttons.AnimateButton(this._baseCrop(name));
    var value = name.replace("calc", "");
    value = value.replace(".png", "");
    key.value = value;
    key.x = config.spriteSourceSize.x + key.width / 2;
    key.y = config.spriteSourceSize.y + key.height / 2;
    
    this._calcKeys.push(key);
    this._layers.interactions.addChild(key);
}

Factory.prototype._createCalcResult = function(config, name)
{
    var index = name.substr(3, 1);
    var area = new PIXI.Rectangle(config.spriteSourceSize.x, config.spriteSourceSize.y, config.frame.w, config.frame.h);
    
    if(this._calcResults[index] == undefined)
    {
        this._calcResults[index] = [];
    }
    
    this._calcResults[index].push(area);
}

Factory.prototype._createCard = function(config, name)
{
    var card = new tls.display.Card(this._baseCrop(name));
    card.x = config.spriteSourceSize.x + card.width / 2;
    card.y = config.spriteSourceSize.y + card.height / 2;
    
    this._cards.push(card);
    this._layers.interactions.addChild(card);
}

Factory.prototype._createBexiga = function(config, name)
{
    var tx = this._baseCrop(name)
    var bx = new tls.display.Bexiga(tx);
    bx.x = config.spriteSourceSize.x + tx.width / 2;
    bx.y = config.spriteSourceSize.y + tx.height / 2;
    
    this._bexigas.push(bx);
    this._layers.interactions.addChild(bx);
}

Factory.prototype._createAgulha = function(config, name)
{
    var a = new tls.display.Agulha(this._baseCrop(name));
    a.x = config.spriteSourceSize.x;
    a.y = config.spriteSourceSize.y;
    
    this._agulhas.push(a);
    this._layers.sup.addChild(a);
}

Factory.prototype._baseCrop = function(config)
{
    var t = new PIXI.Texture.fromFrame(config);

    return t;
}

Factory.prototype.swapLayer = function(obj, oldLayer, newLayer)
{
    var _o = obj;
    
    var _ol = this._getLayer(oldLayer);
    var _nl = this._getLayer(newLayer);
    
    _ol.removeChild(_o);
    _nl.addChild(_o);
}

Factory.prototype._getLayer = function(layer)
{
    var res;
    
    switch(layer)
    {
        case "img":
            res = this._layers.images;
            break;
        case "sup":
            res = this._layers.sup;
            break;
        case "bocas":
            res = this._layers.bocas;
            break;
        case "ballons":
            res = this._layers.ballons;
            break;
        case "audios":
            res = this._layers.audios;
            break;
        case "interactions":
            res = this._layers.interactions;
            break;
    }
    
    return res;
}

Factory.prototype.setChildIndexByLayer = function(obj, index)
{
    var layer = obj.parent;
    layer.setChildIndex(obj, index);
}

tls.core.Factory = Factory;
