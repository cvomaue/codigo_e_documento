{
"frames": {
	"audio00.png": {
		"frame": {"x":185, "y":815, "w":61, "h":59},
		"spriteSourceSize": {"x":289,"y":73,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"balao00.png": {
		"frame": {"x":0, "y":0, "w":330, "h":167},
		"spriteSourceSize": {"x":31,"y":53,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"balao01.png": {
		"frame": {"x":0, "y":815, "w":183, "h":173},
		"spriteSourceSize": {"x":621,"y":55,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"boca00.png": {
		"frame": {"x":0, "y":990, "w":31, "h":22},
		"spriteSourceSize": {"x":216,"y":259,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"boca01.png": {
		"frame": {"x":0, "y":990, "w":31, "h":22},
		"spriteSourceSize": {"x":767,"y":245,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"img00.png": {
		"frame": {"x":0, "y":493, "w":187, "h":320},
		"spriteSourceSize": {"x":143,"y":175,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	},
	"img01.png": {
		"frame": {"x":0, "y":169, "w":192, "h":322},
		"spriteSourceSize": {"x":687,"y":168,"w":974,"h":524},
		"sourceSize": {"w":974,"h":524}
	}

},
"meta": {
	"image": "sprites.png",
	"size": {"w": 512, "h": 1024},
	"scale": "1"
}
}