function Paint(textures)
{
    PIXI.Container.call(this);
    
    this._textures = textures;
    this._back;
    this._colors = ['#cb4d3a', '#009de0', '#89b53c', '#ffed00', '#dc911b', '#322b80', '#2d3440', '#9b7541', '#ffffff'];
    this._buttonGroup = [];
    this._next;
    this._selectColor;
    
    this._autorizeDraw = false;
    
    this._autorizeNext = false;
    
    this._lineWidth = 10;
    
    this._isMove = false;
    
    var lo = this.lo = new tls.loaders.HTMLTexture();
    lo.add("telas/comum/paint/back.png");
    lo.on("complete", function(){
        this._back = new PIXI.Sprite(this.lo.getTextures()[0]);    
    }, this);
    lo.load(); 
}

Paint.prototype = Object.create(PIXI.Container.prototype);
Paint.prototype.constructor = Paint;

Paint.prototype.init = function()
{
    var self = this;
    
    this.addChild(this._back);
    
    for(var i = 0; i < this._textures.length; i++)
    {
        if(this._textures[i].name == "next")
        {
            this._next = new AnimateButton(this._textures[i]);
            this._next.x = this._textures[i].sourceX + this._next.width / 2;
            this._next.y = this._textures[i].sourceY + this._next.height / 2;
            
            this.addChild(this._next);
            continue;
        }
        
        var a = new FeedObject(this._textures[i], FeedObject.OK);
        var n = this._textures[i].name
        if(n.indexOf("cor") != -1) n = parseInt(n.replace("cor", "")).toString();
        
        a.name = n;
        a.index = i;
        a.x = this._textures[i].sourceX + a.width / 2;
        a.y = this._textures[i].sourceY + a.height / 2;        
        
        this._buttonGroup.push(a);
        this.addChild(a);
    }  
        
    this.x = 301;
    this.y = 38;
    
    this._canvas = document.createElement('div');
    this._canvas.width = 414;
    this._canvas.height = 379;
    this._canvas.id = "board";
    $(this._canvas).css({
        "position": "absolute",
        "left": this.x + 32 + "px",
        "top": this.y + 34 + "px"
    });
    tls.parent.append(this._canvas);
    
    this.board = Sketch.create({
        container: this._canvas,
        fullscreen: false,
        width: 414,
        height: 379,
        autoclear: false,
        type: Sketch.CANVAS,
        
        touchstart: function(){
            self._isMove = true;
        },
        
        touchend: function(){
            self._isMove = false;
            
            if(!self._autorizeNext && self._autorizeDraw)
            {
                self._autorizeNext = true;
                
                var n = self._next;
                n.animate();
                n.addEvents();
                n.on('clicked', function(){
                    this.removeListener();
                    this.removeEvents();
                    
                    self.emit("next");
                });
            }
        },
        
        touchmove: function() {
            if(self._isMove && self._autorizeDraw)
            {
                var touch = this.touches[0];
                this.lineCap = 'round';
                this.lineJoin = 'round';
                this.fillStyle = this.strokeStyle = self._selectColor;
                this.lineWidth = self._lineWidth;
                this.beginPath();
                this.moveTo( touch.ox, touch.oy );
                this.lineTo( touch.x, touch.y );
                this.stroke();
            }
        }
    });
}

Paint.prototype.addEvents = function()
{
    for(var i = 0; i < this._buttonGroup.length; i++)
    {
        var a = this._buttonGroup[i];
        
        a.addEvents();
        a.on(FeedObject.OK, this.clicked, {target: a, self: this});
    }
}

Paint.prototype.clicked = function(e)
{
    var bt = this.target;
    
    var self = this.self;
    
    for(var i = 0; i < self._buttonGroup.length; i++)
    {
        var b = self._buttonGroup[i];        
        if(b.index != bt.index)
        {         
            b.removeEvents();
            b.addEvents();
            b.interactive = true;
            b.closeFeed();
        }
        else
        {
            if(b.index == 8) self._lineWidth = 50;
            else self._lineWidth = 10;
            
            if(!self._autorizeDraw)
            {
                self._autorizeDraw = true;
                self.emit("autorizeDraw");
            }            
            
            self._selectColor = self._colors[b.index];
            
            
            b.removeEvents();
        }
    }
}

Paint.prototype.destroy = function()
{
    this.removeChildren();
    this.removeAllListeners();    
    
    this.board.destroy();
    $(this._canvas).remove();
    
    PIXI.Container.prototype.destroy.call(this);
}

tls.ui.Paint = Paint;