/**
* AnimateButton cria um botão a partir de uma textura expecificada.
* 
* @class
* @extends tls.core.Base
* @menberof tls.buttons
* @fires textureComplete
* @param texture {PIXI.Texture} imagem base para o botão
*/
function AnimateButton(texture)
{
    Base.call(this);
    
    var self = this;
    
    /**
    * Armazena a textura
    * @member {PIXI.Texture}
    * @private
    */
    this._texture = texture;
    
    /**
    * Cria uma imagem a partir da textura
    *
    * @member {PIXI.Sprite}
    * @private
    */
    this._im = new PIXI.Sprite(texture);
    var im = this._im;
    
    // Armazena o setInterval
    var enterframe;
    
    /**
    * Disparado quando a imagem está totalmente carregada e centralizada
    *
    * @event textureComplete
    * @menberof AnimateButton#
    */
    
    /**
    * Disparado quando o usuário solta a pressão do mouse ou tira o toque da tela
    * após ter precionado ou tocado representando uma ação de click
    *
    * @event clicked
    * @memberof AnimateButton#
    */
    
    /**
    * Verifica o tamanho da imagem para saber se já foi completamente carregada
    */
    if(im.width > 6 || im.height > 6)
    {
        // Seta o ponto de registro para o centro
        this._centralize(im); 
        self.emit("textureComplete");
    }
    else
    {
        /**
        * Caso a imagem não tenha sido completamente carregada
        * cria um setInterval para verificar o carregamento
        */
        enterframe = setInterval(function(){
            if(im.width > 6 || im.height > 6)
            {
                // cancela a verificação
                clearInterval(enterframe);
                // Seta o ponto de registro para o centro
                this._centralize(im);
                self.emit("textureComplete");
            }            
        }, 100);
    }
    
    // Adiciona a imagem à lista de exibição
    this.addChild(this._im);
}

AnimateButton.prototype = Object.create(Base.prototype);
AnimateButton.prototype.constructor = AnimateButton;

Object.defineProperties(AnimateButton.prototype, {
    /**
    * Retorna a textura usada como base
    *
    * @member {PIXI.Texture}
    * @readonly
    */
    texture: {
        get: function()
        {
            return this._texture;
        }
    }
});

/**
* Centraliza o ponto de registro da imagem especificada
* 
* @memberof AnimatedButton
* @param image {PIXI.Sprite} imagem para ser centralizada
* @private
*/
AnimateButton.prototype._centralize = function(image)
{
    image.pivot.set(image.width / 2, image.height / 2);
}

/**
* Faz uma animação de fade em alpha de 0 para 1
* antes deve setar o alpha para 0
* inicia o modo interativo
*
* ```js
* var b = new AnimateButton(texture);
* b.alpha = 0;
* b.open();
* ```
*
* @memberof AnimateButton
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
AnimateButton.prototype.open= function(onComplete, onCompleteParams)
{
    this.interactive = true;
    this.buttonMode = true;
    
    this.openWithFade(onComplete, onCompleteParams);
}

/**
* Faz uma animação de fade em alpha de 1 para 0
* encerra o modo interativo
*
* @memberof AnimateButton
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
AnimateButton.prototype.close = function(onComplete, onCompleteParams)
{
    this.interactive = false;
    this.buttonMode = false;
    
    this.closeWithFade(onComplete, onCompleteParams);
}

/**
* Adiciona os eventos suporte de mouse e touch
* inicia o modo interativo
*
* @memberof AnimateButton
* @public
*/
AnimateButton.prototype.addEvents = function()
{
    this.interactive = true;
    this.buttonMode = true;
    
    this
        .on('mousedown', this._onDown)
        .on('touchstart', this._onDown)

        .on('mouseup', this._onUp)
        .on('touchend', this._onUp)
        .on('mouseupoutside', this._onUp)
        .on('touchendoutside', this._onUp);
}

/**
* Remove os eventos suporte de mouse e touch
* encerra o modo interativo
*
* @memberof AnimateButton
* @public
*/
AnimateButton.prototype.removeEvents = function()
{
    this.interactive = false;
    this.buttonMode = false;

    this
        .removeListener('mousedown', this._onDown)
        .removeListener('touchstart', this._onDown)

        .removeListener('mouseup', this._onUp)
        .removeListener('touchend', this._onUp)
        .removeListener('mouseupoutside', this._onUp)
        .removeListener('touchendoutside', this._onUp);
}

/**
* Ao pressionar do mouse ou toque na tela
*
* @memberof AnimateButton
* @param e {MouseEvent/TouchEvent}
* @private
*/
AnimateButton.prototype._onDown = function(e)
{
    //para a animação se houver
    this.stopAnimation();
    
    //diminui 20% na escala
    this.scale.set(this._initSize.x - 0.2, this._initSize.y - 0.2);
}

/**
* Ao retirar a pressão do mouse ou retirar o toque na tela
*
* @memberof AnimateButton
* @param e {MouseEvent/TouchEvent}
* @fires clicked
* @private
*/
AnimateButton.prototype._onUp = function(e)
{
    //volta a escala original
    this.scale.set(this._initSize.x, this._initSize.y);
    
    //Dispara o evento indicando o click
    this.emit("clicked", e);
}

/**
* Permite substituir a imagem base por outra
*
* @memberof AnimateButton
* @param texture {PIXI.Texture} Nova textura para substituir a atual
* @public
*/
AnimateButton.prototype.swapTexture = function(texture)
{
    //representa a imagem atual
    var im = this._im;
    
    /**
    * Verifica o tamanho da imagem para saber se já foi completamente carregada
    */
    if(texture.width > 5 || texture.height > 5)
    {
        im.texture = texture;
        this._im.pivot.set(texture.width / 2, texture.height / 2);
    }
    else
    {
        /**
        * Caso a imagem não tenha sido completamente carregada
        * cria um setInterval para verificar o carregamento
        */
        var enterframe = setInterval(function(){
            if(texture.width > 5 || texture.height > 5)
            {
                clearInterval(enterframe);
                im.texture = texture;
                im.pivot.set(texture.width / 2, texture.height / 2);
            }
        }, 100);
    }    
}

/**
* Suporte para limpar a memória
* destroi todos os objetos e remove os eventos
*
* @memberof AnimateButton
* @public
*/
AnimateButton.prototype.destroy = function()
{
    this.removeEvents();    
    
    this.removeChild(this._im);
    this._im.destroy();
    this._im = null;
    
    this.removeAllListeners();
    
    Base.prototype.destroy.call(this);
}

tls.buttons.AnimateButton = AnimateButton;