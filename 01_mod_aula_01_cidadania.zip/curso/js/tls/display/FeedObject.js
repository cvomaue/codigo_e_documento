function FeedObject(texture, type)
{
    Base.call(this);
    
    var self = this;
    
    this._type = type;
    this._colorFeed;
    
    switch(this._type)
    {
        case FeedObject.FAIL:
            this._colorFeed = "#a21818";
            break;
        case FeedObject.OK:
            this._colorFeed = "#1ba218";
            break;
    }
    
    this._texture = texture;
    this._cloneTexture = this._texture.clone();  
    this._thickness = 5;
    
    this._img = new AnimateButton(this._texture);
    //this._img.alpha = 0;
    
    var _feed = new PIXI.Sprite(this._cloneTexture);
    
    var rt = new PIXI.RenderTexture(tls.renderer, _feed.width, _feed.height);
    rt.render(_feed);
    
    this._src = rt.getImage();    
    tls.utils.Outline(this._src, tls.parent, this._thickness, this._colorFeed, function(res){ self._addFeed(res); });
    
    _feed.destroy();
    rt.destroy();
    
    this.addChild(this._img);
}

FeedObject.prototype = Object.create(Base.prototype);
FeedObject.prototype.constructor = FeedObject;

Object.defineProperties(FeedObject.prototype, {
    type: {
        get: function(){ return this._type; }
    },
    texture: {
        get: function(){ return this._texture; }
    },
    
    thickness: {
        set: function(value){
            var self = this;
            
            this._thickness = value;
            try{
                this.removeChild(this._feed);
                this._feed.destroy();
                tls.utils.Outline(this._src, tls.parent, this._thickness, this._colorFeed, function(res){ self._addFeed(res); });
            }
            catch(err){
                this._enterframe = setInterval(function(){
                    if(self._feed != null && self._feed != undefined)
                    {
                        clearInterval(self._enterframe);
                        
                        self.removeChild(self._feed);
                        self._feed.destroy();
                        tls.utils.Outline(self._src, tls.parent, self._thickness, self._colorFeed, function(res){ self._addFeed(res); });
                    }
                }, 100);
            }
            
        }
    }
});

FeedObject.prototype.addEvents = function()
{
    var self = this;
    
    this._img.addEvents();
    this._img.on("clicked", function(e){
        self.emit(self._type, e);
        self.openFeed();
    });
}

FeedObject.prototype.removeEvents = function()
{
    this._img.removeEvents();
    this._img.removeListener("clicked");
}

FeedObject.prototype.openFeed = function(matrix)
{
    if(matrix)
    {
        var f = new PIXI.filters.ColorMatrixFilter();        
        this._feed.filters = [f];
        f.matrix = matrix;
    }
    else
    {
        this._feed.filters = null;
    }
    
    this._feed.visible = true;
    TweenMax.to(this._feed, 0.5, {alpha: 1});
}

FeedObject.prototype.closeFeed = function()
{
    var self = this;
    TweenMax.to(this._feed, 0.3, {alpha: 0, onComplete: function(){
        self._feed.visible = false;
    }});
}

FeedObject.prototype.swapTexture = function(texture)
{
    this._texture = texture;
    
    var img = this._img;
    
    if(texture.width > 10 && texture.height > 10)
    {
        this._img.swapTexture(texture);
    }
    else
    {        
        var enterframe = setInterval(function()
                                     {
            if(texture.width > 10 && texture.height > 10)
            {
                clearInterval(enterframe);
                img.swapTexture(texture);
            }
        }, 100);
    }
    
}

FeedObject.prototype._addFeed = function(feed)
{
    feed.pivot.set(feed.width / 2, feed.height / 2);
    feed.alpha = 0;
    this._feed = feed;
    this.addChildAt(feed, 0);
}

FeedObject.prototype.destroy = function()
{
    this.removeChildren();
    this.removeAllListeners();
    this.removeEvents();
    
    this._img.destroy();
    this._feed.filters = null;
}

FeedObject.FAIL = "feed_fail";
FeedObject.OK = "feed_ok";

tls.display.FeedObject = FeedObject;