function Tela()
{
    tls.core.Factory.call(this, "telas/006/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/006/6_1.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.correct = 0;
    this.totalCorrects = 5;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.paint = tls.display.Textures.PAINT;
        this.paint.init();
        this._layers.interactions.addChild(this.paint);
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("preStart", function(e){
        
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self.paint.addEvents();
        self.paint.on("next", function(){
            self.emit("removeAll");
        });
    });    
    
    this.dialogos.play();
}

Tela.prototype.destroy = function()
{
    this.paint.destroy();
    this.dialogos.destroy();
    this.soundManager.destroy();    
    
    tls.core.Factory.prototype.destroy.call(this);
}