function Tela()
{
    tls.core.Factory.call(this, "telas/004/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/004/4_1.mp3");
    this.soundManager.addSingleSound("telas/004/4_2.mp3");
    this.soundManager.addSingleSound("telas/004/4_3.mp3");
    this.soundManager.addSingleSound("telas/004/4_4.mp3");
    this.soundManager.addSingleSound("telas/004/4_5.mp3");
    
    this.dialogos;
    
    this.correct = 0;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 1;
        this.bocaFeedOkIndex = 0;
        this.soundOkIndex = 1;
        
        this.feedFailIndex = 1;
        this.bocaFeedFailIndex = 0;
        this.soundFailIndex = 1;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;    
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0], 0);
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("end", function(e){
        console.log(self.areaDrags)
        this.removeListener("end");
        
        self.addDragsEvents();
    });
    
    this.configureDrags();
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    
    self.removeDragsEvents(); 
    
    this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
        self.addDragsEvents();        
    });
}

Tela.prototype.setOk = function()
{
    var self  = this;
    
    self.removeDragsEvents();
    
    self.correct++;

    if(self.correct >= self.areaDrags.length)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);                
        });

        return;
    }

    self.addDragsEvents();        
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound);  
}

Tela.prototype.configureDrags = function()
{
    var self = this;
    
    for(var i = 0; i < self.drags.length; i++)
    {
        if(i < self.areaDrags.length)
        {
            self.drags[i].collisions = [self.areaDrags[i]];            
        }
        
        self.drags[i].usePoint = true;
        self.drags[i].adjust = true;        
        
        self.drags[i].on("incorrect", function(e){
            self.setFail();
        });

        self.drags[i].on("correct", function(e){
            this.removeListener("correct");
            this.isOff = true;
            self.setOk();
        });
    }
}

Tela.prototype.addDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        if(this.drags[i].isOff) continue;
        this.drags[i].addEvents();
    }
}

Tela.prototype.removeDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].removeEvents();
    }
}

Tela.prototype.destroy = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].destroy();
    }
    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}