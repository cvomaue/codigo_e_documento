function Bexiga(base_texture){
    Base.call(this);
    
    this._base = new ImageEx(base_texture);
    this._mc = new Boca(Boca.TYPE_BEXIGA);
    this._mc.pivot.set(83, 84.5);
    this._mc.animationSpeed = 0.7;
    this._mc.loop = false;
    
    this.addChild(this._mc);
    this.addChild(this._base);
    
}

Bexiga.prototype = Object.create(Base.prototype);
Bexiga.prototype.constructor = Bexiga;

Object.defineProperties(Bexiga.prototype, {
    mc: {
        get: function(){
            return this.mc;
        }
    }
})

Bexiga.prototype.pow = function()
{
    var self = this;
    
    this._mc.play();
    TweenMax.to(this._base.scale, 0.3, {x: 3, y: 3});
    TweenMax.to(this._base, 0.3, {alpha: 0, onComplete: function(){
        self.visible = false;
    }});
}

Bexiga.prototype.destroy = function()
{
    this.removeChildren();
    this.removeListeners();
    
    this._base.destroy();
    this._mc.destroy();
    
    Base.prototype.destroy.call(this);
}

tls.display.Bexiga = Bexiga;
    
