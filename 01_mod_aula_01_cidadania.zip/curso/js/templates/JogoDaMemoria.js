function Tela()
{
    tls.core.Factory.call(this, "telas/005/sprite.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/005/5_1.mp3");
    this.soundManager.addSingleSound("telas/005/5_2.mp3");
    this.soundManager.addSingleSound("telas/005/5_3.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.correct = 0;
    this.totalCorrects = 5;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 1;
        this.feedFailIndex = 0;
        this.bocaFeedOkIndex = 0;
        this.bocaFeedFailIndex = 0;
        this.soundOkIndex = 2;
        this.soundFailIndex = 1;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    
    this.memoryGame = new tls.templates.MemoryGame(this, "memory");
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0, 1, 0]);
    this.dialogos.on("preStart", function(e){
        if(e.atualIndex == 0 || e.atualIndex == 2)
            e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self.memoryGame.init();
        self.memoryGame.on("correct", function(e){
            self.setOk();
        });
        
        self.memoryGame.on("incorrect", function(e){
            self.setFail();
        });
    });    
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    
    this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
      for(var i = 0; i < self.feeds.length; i++)
        {
            if(self.feeds[i].type == tls.display.FeedObject.FAIL)
            {
                self.feeds[i].closeFeed();               
            }
        }
        
        self.memoryGame._addEvents();
        
    });
}

Tela.prototype.setOk = function()
{
    var self  = this; 
    
    self.correct++;

    if(self.correct >= self.totalCorrects)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);            
        }); 

        return;
    }
    
    self.memoryGame._addEvents();
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}