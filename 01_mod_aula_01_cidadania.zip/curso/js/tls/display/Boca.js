function Boca(type)
{
    this._t = type || Boca.TYPE_NORMAL;
    
    this._fr;
    this._stationary;
    
    switch(this._t)
    {
        case Boca.TYPE_NORMAL:
            this._fr = tls.display.Textures.FRAMES_BOCA;
            this._stationary = 7;
            break;
        case Boca.TYPE_GATO:
            this._fr = tls.display.Textures.FRAMES_BOCA_GATO;
            this._stationary = 10;
            break;
        case Boca.TYPE_BEXIGA:
            this._fr = tls.display.Textures.FRAMES_BEXIGA;
    }
    
    PIXI.extras.MovieClip.call(this, this._fr);
    
    this.animationSpeed = 0.2;
}

Boca.prototype = Object.create(PIXI.extras.MovieClip.prototype);
Boca.prototype.constructor = Boca;

Object.defineProperties(Boca.prototype, {
    stationary: {
        get: function(){
            return this._stationary;
        }
    }
});

Boca.TYPE_NORMAL = "boca";
Boca.TYPE_GATO = "bocaGato";
Boca.TYPE_BEXIGA = "bexiga";

tls.display.Boca = Boca;