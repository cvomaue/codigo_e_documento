function Card(texture)
{
    PIXI.Container.call(this);
    
    this._front = new FeedObject(texture, FeedObject.OK);
    this._feedFail = new FeedObject(texture, FeedObject.FAIL);
    
    this._back = new PIXI.Sprite(tls.display.Textures.CARD_CLOSE);
    this._back.pivot.set(this._back.width / 2, this._back.height / 2);
    
    this.addChild(this._feedFail);
    this.addChild(this._front);
    this.addChild(this._back);
    
    this._feedFail.scale.set(0, 1);
    this._front.scale.set(0, 1);
    
    this._feedFail.visible = false;
    
    this._status = "close";
    
    this._tl = new TimelineMax({
        paused: true,
        onComplete: this._opened,
        onReverseComplete: this._closed,
        onCompleteScope: this,
        onReverseCompleteScope: this
    });
    this._tl.to(this._back.scale, 0.2, {x: 0});
    this._tl.to([this._front.scale, this._feedFail.scale], 0.2, {x: 1});
}

Card.prototype = Object.create(PIXI.Container.prototype);
Card.prototype.constructor = Card;

Card.prototype.open = function()
{
    this._tl.play();
    this._status = "open";
}

Card.prototype.close = function()
{
    this._tl.reverse();
    this._status = "close";
}

Card.prototype._opened = function()
{
    this._back.interactive = false;
    this._back
        .removeListener("mousedown")
        .removeListener("touchstart");
    
    this._front.interactive = true;
    this._front
        .on("mousedown", this._clicked, this)
        .on("touchstart", this._clicked, this);
    
}

Card.prototype._closed = function()
{
    this._front.interactive = false;
    this._front
        .removeListener("mousedown")
        .removeListener("touchstart");
    
    this._back.interactive = true;
    this._back
        .on("mousedown", this._clicked, this)
        .on("touchstart", this._clicked, this);
}

Card.prototype._clicked = function(e)
{
    this.emit("clicked", {status: this._status});
}

Card.prototype.openFeed = function(type)
{
    var matrix;
    var r = 162 / 255;
    var g = 24 / 255;
    var b = 24 / 255;
    
    if(type == "fail")
    {
        matrix = [
            0, 0, 0, r, 0, // red
            0, 0, 0, g, 0, // green
            0, 0, 0, b, 0, // blue
            0, 0, 0, 1, 0 // alpha
        ];
        
        this._front.visible = false;
        this._feedFail.visible = true;
        
        this._feedFail.openFeed();
        
        return;
    }
    
    this._front.visible = true;
    this._feedFail.visible = false;
    
    this._front.openFeed(matrix);
}

Card.prototype.closeFeed = function()
{
    this._front.closeFeed();
    this._feedFail.closeFeed();
}

Card.prototype.destroy = function()
{
    this.removeChildren();
    this.removeListeners();
    
    this._feed.destroy();
    this._back.destroy();
    
    PIXI.Container.prototype.destroy.call(this);
}

tls.display.Card = Card;