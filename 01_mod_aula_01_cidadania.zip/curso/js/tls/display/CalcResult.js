function CalcResult(radius, type)
{
    PIXI.Container.call(this);
    
    switch(type)
    {
        case "result":
            this._drawBase(radius, 0xffffff, 0x1ba218, 0);
            break;
        case "text":
            this._drawBase(radius, 0xffffff, 0x053342, 0);
            break;
    }
    
    this._text = new PIXI.Text("", {font: '50px Angola'});
    this.addChild(this._text);
    this._alignText();
}

CalcResult.prototype = Object.create(PIXI.Container.prototype);
CalcResult.prototype.constructor = CalcResult;

Object.defineProperties(CalcResult.prototype, {
    text: {
        get: function(){
            return this._text.text;
        },
        
        set: function(value){
            this._text.text = value;
            this._alignText();
        }
    }
})

CalcResult.prototype._drawBase = function(radius, color, stroke, alpha)
{
    var b = new PIXI.Graphics();
    b.lineStyle(5, stroke);
    b.beginFill(color, alpha);
    b.drawCircle(0, 0, radius);
    b.endFill();
    
    var rt = new PIXI.RenderTexture(tls.renderer, b.width, b.height);
    var mx = new PIXI.Matrix();
    mx.translate(radius + 2.5, radius + 2.5);
    rt.render(b, mx);
    
    this._selector = new PIXI.Sprite(rt);
    this._selector.x = -2.5;
    this._selector.y = -2.5;
    this._selector.alpha = 0;
    this.addChild(this._selector);
}

CalcResult.prototype._alignText = function()
{
    this._text.x = this._selector.x + this._selector.width / 2 - this._text.width / 2;
    this._text.y = this._selector.y + this._selector.height / 2 - this._text.height / 2;
}

CalcResult.prototype.animate = function(time)
{
    var t = time || 0.5;
    TweenMax.to(this._selector, t, {alpha: 1, yoyo: true, repeat: -1});
}

CalcResult.prototype.stopAnimation = function()
{
    TweenMax.killTweensOf(this._selector);
    this._selector.alpha = 0;
}

CalcResult.prototype.destroy = function()
{
    TweenMax.killTweensOf(this._selector);
    
    this.removeChildren();
    this.removeAllListeners();
    this._text.destroy(true);
    this._selector.destroy(true);
    
    PIXI.Container.prototype.destroy.call(this, true);
}

tls.display.CalcResult = CalcResult;