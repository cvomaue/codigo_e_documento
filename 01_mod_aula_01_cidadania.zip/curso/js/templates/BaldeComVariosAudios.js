function Tela()
{
    tls.core.Factory.call(this, "telas/007/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/007/7_1.mp3");
    this.soundManager.addSingleSound("telas/007/7_2.mp3");
    this.soundManager.addSingleSound("telas/007/7_3.mp3");
    
    this.dialogos;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        var self = this;
        
        this.feedOkIndex = 1;
        this.bocaFeedOkIndex = 0;
        this.soundOkIndex = 1;
        
        this.feedFailIndex = 1;
        this.bocaFeedFailIndex = 0;
        this.soundFailIndex = 1;
        
        this._count = 0;
        this._totalCorrects = 2;
        
        this.init();        
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;    
    
    var b = self.baldes[0];
    b.possensorx = 0;
    b.possensory = 50;
    b.debug = false;
    
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0], 0);
    this.dialogos.on("preStart", function(e){
        
    });
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        for(var i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i + 1);
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }
        
        var b = self.baldes[0];
        b.tintObjects = self.tints;
        b.addEvents();
        b.on("correct", function(e){
            self.setOk(e.tintObject);
        });
        
        b.on("incorrect", function(e){
            self.setFail(e.tintObject);
        });
    });    
    
    this.dialogos.play();
}

Tela.prototype.setFail = function(tintObject)
{
    var self  = this;
    this.baldes[0].removeEvents();
    tintObject.color();
    
    setTimeout(function(){
        tintObject.uncolor();
        
        self.baldes[0].addEvents();
    }, 1500);
    
    //Alternativa fail com balão
    /*this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
        tintObject.uncolor();
        
        self.baldes[0].addEvents();         
    });*/
}

Tela.prototype.setOk = function(tintObject)
{
    var self  = this;
    this.baldes[0].removeEvents();
    tintObject.color();
    tintObject.lock = true;
    
    this._count++;
    
    
    if(this._count >= this._totalCorrects)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.emit("removeAll");
            }, 1000);            
        });
        
        return;
    }
    
    this.baldes[0].addEvents();
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    for(var i = 0; i < this.baldes.length; i++)
    {
        this.baldes[i].destroy();
    }
    
    for(i = 0; i < this.tints.length; i++)
    {
        this.tints[i].destroy();
    }
    
    tls.core.Factory.prototype.destroy.call(this);
}