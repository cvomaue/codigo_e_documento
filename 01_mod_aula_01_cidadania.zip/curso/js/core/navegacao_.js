//Definição da versão do Scorm utilizada
var lms = true;
var forSCORM = 0;
var FACTOR_SCALE = 1;
var CORRECTS = null;
var MINIMUN_AVAL = 0.6;

if(lms){
	var scorm = pipwerks.SCORM;
	scorm.version = "1.2";
	scorm.connection.initialize();
	
	//Verifica se conexão com LMS ainda está ativa
	window.onunload = window.onbeforeunload = function()
	{
		if(scorm.connection.isActive)
		{	
			pipwerks.UTILS.trace("Finalizando conexão no Unload");
			scorm.save();
			scorm.quit();
		}
	}
	var telaScorm = scorm.data.get("cmi.core.lesson_location");
	if(telaScorm=="" || telaScorm == null || telaScorm == undefined){
		telaScorm = inicio;
	}else{
		telaScorm = parseInt(telaScorm);
	}
	var porCurso = scorm.data.get("cmi.core.score.raw");
	if(porCurso=="" || isNaN(porCurso)){
		porCurso = 0;
        scorm.data.set("cmi.core.score.min", 0);
		scorm.data.set("cmi.core.score.max", 100);
	}else{
		porCurso = parseInt(porCurso);
	}
	//alert(telaScorm);
}
$(function(){
    var base_width = 974;
    var base_height = 524;
    
    var min_width = base_width / 2;
    var min_height = base_height / 2;
    
    var scale = 1;
    
    var leftOldState = false;
    var rightOldState = false;
    
    var ajudaOn = false;
    
    var allow = 0;
    
    var body = $('body');
    body.css({
        background: 'url(imgs/Interface_fundo_liso.jpg) no-repeat',
        width: '100%',
        height: '100%',
        position: 'absolute'
    });
    
    var curso = $("#curso");
    curso.width(base_width);
    curso.height(base_height);
    curso.css({
        position: 'absolute',
        margin: '0px',
    });
    
    var ajudabt = $(document.createElement('div'));
    ajudabt.size = 78 * .7;
    ajudabt.css({
        width: ajudabt.size + 'px',
        height: ajudabt.size + 'px',
        background: 'url(imgs/0000_ajuda.png) no-repeat center center',
        backgroundSize: '100% 100%',
        position: 'absolute',
        display: 'clock',
        cursor: 'pointer'
    });
    
    body.append(ajudabt);
    
    var ajudaBack = $(telas.getBackground(telas.getBackLenth() - 1));
    ajudaBack.css({
        position: 'absolute'
    });    
    
    var leftbt = $(document.createElement('div'));
    leftbt.active = "imgs/0003_volta.png";
    leftbt.inactive = "imgs/0004_volta_desativado.png";
    leftbt.isOn = false;
    leftbt.css({
        width: ajudabt.size + "px",
        height: ajudabt.size + "px",
        background: "url(" + leftbt.inactive + ") no-repeat center center",
        backgroundSize: "100% 100%",
        position: "absolute"
    });
    
    body.append(leftbt);
    
    var rightbt = $(document.createElement('div'));
    rightbt.active = "imgs/0005_avanca.png";
    rightbt.inactive = "imgs/0006_avanca_desativado.png";
    rightbt.isOn = false;
    rightbt.css({
        width: ajudabt.size + "px",
        height: ajudabt.size + "px",
        background: "url(" + rightbt.inactive + ") no-repeat center center",
        backgroundSize: "100% 100%",
        position: "absolute"
    });
    
    body.append(rightbt);
    
    ajudabt.on('click', function(){ 
        if(ajudaOn)
        {
            ajudaOn = false;
            ajudaBack.remove(); 
            
            if(leftOldState)
            {
                leftbt.css('background', 'url(' + leftbt.active + ') no-repeat center center');
                leftbt.css('background-size', '100% 100%');
                leftbt.isOn = true;
            }
            
            if(rightOldState)
            {
                rightbt.css('background', 'url(' + rightbt.active + ') no-repeat center center');
                rightbt.css('background-size', '100% 100%');
                rightbt.isOn = true;
            }
        }
        else
        {
            ajudaOn = true;
            ajudabt.before(ajudaBack);
            
            if(leftOldState)
            {
                leftbt.css('background', 'url(' + leftbt.inactive + ') no-repeat center center');
                leftbt.css('background-size', '100% 100%');
                leftbt.isOn = false;
            }
            
            if(rightOldState)
            {
                rightbt.css('background', 'url(' + rightbt.inactive + ') no-repeat center center');
                rightbt.css('background-size', '100% 100%');
                rightbt.isOn = false;
            }
        }
    });
    
    leftbt.on('click', function(e){
        if(leftbt.isOn)
        {
            voltarPagina();
        }
    });
    
    rightbt.on('click', function(){
        if(rightbt.isOn)
        {
            avancarPagina();
        }
    });
    
    var autorizeDobleResize = true;
    
    setTimeout(function(){
        onResize();
    }, 300);
    
    $(window).on('resize', function(e){
        autorizeDobleResize = true;
        onResize();
    });
    
    function onResize()
    {        
        if($(window).width() <= base_width || $(window).width() >= min_width ||
          $(window).height() <= base_height || $(window).height() >= min_height)
        {
            console.log("sou menor......")
            if($(window).height() <= base_height)
            {
                curso.height($(window).height());
                scale = curso.height() / base_height;
                curso.width(base_width * scale);
            }
            
            if($(window).width() <= base_width)
            {
                curso.width($(window).width());
                scale = curso.width() / base_width;
                curso.height(base_height * scale);
            }
            
            if(curso.height() > $(window).height())
            {
                curso.height($(window).height());
                scale = curso.height() / base_height;
                curso.width(base_width * scale);
            }
            
            if(curso.width() < min_width)
            {
                scale = curso.height() / base_height;
                
                curso.width(min_width);
                curso.height(min_height);
            }
        }
        
	
        if($(window).width() >= base_width && $(window).height() >= base_height)
        {
            curso.width(base_width);
            curso.height(base_height);
            
            scale = 1;
        }
        
        FACTOR_SCALE = scale;
        
        
        curso.css({
            left: $(window).width() / 2 - curso.width() / 2 + "px",
            top: $(window).height() / 2 - curso.height() / 2 + "px"
        });
        
        telas.resize(scale);
        
        body.css({
            backgroundSize: $(document).width() + 'px' + ' ' + $(document).height() + 'px'
        });
        
        ajudabt.width(ajudabt.size * scale);
        ajudabt.height(ajudabt.size * scale);
        
        ajudabt.css({
            left: curso.css('left'),
            top: curso.css('top')
        });
        
        ajudaBack.css({
            width: curso.width() + 'px',
            height: curso.height() + 'px',
            left: curso.css('left'),
            top: curso.css('top')
        });
        
        leftbt.css({
            width: ajudabt.css('width'),
            height: ajudabt.css('height'),
            left: parseInt(curso.css('left')) + curso.width() * .38 + 'px',
            top: parseInt(curso.css('top')) + curso.height() - leftbt.height() + 'px'
        });
        
        rightbt.css({
            width: ajudabt.css('width'),
            height: ajudabt.css('height'),
            left: parseInt(curso.css('left')) + curso.width() * .58 + 'px',
            top: parseInt(curso.css('top')) + curso.height() - leftbt.height() + 'px'
        });
        
        try{
            videoContainer.resize();
        }
        catch(err){}
        
        setTimeout(function(){            
            console.log("loop");
            if(autorizeDobleResize)
            onResize(scale);
            
            autorizeDobleResize = false;
        }, 100);
    }
    
    function voltarPagina()
    {
        ativarAvancar();
        var goBack;
        if(fim >= telas.length) goBack = telas.length - 1;
        else if(telas.getIndex() > fim) goBack = fim + 1;
        else goBack = telas.getIndex();
        
        
        console.log("voltando...." + goBack);
        avancarPagina(goBack - 1 + "");
    }
    
    window.avancarPagina = avancarPagina;
    function avancarPagina(index)
    {        
        if(!Main.getIsEnd() && Main.getIsEnd() != null)
        {
            console.log("estou aqui")
            
            try{
                Main.clear(null, true);
            }
            catch(err){
                console.log("erro ao voltar a tela... limpeza falhou")
                console.dir(err);
            }
        }
        
        var _index = index || null;
        if(_index != null) _index = parseInt(_index);
        desativarAvancar(); 
        console.log("testando o index 1..." + _index)
        if(telas.getIndex() + 1 > fim && _index == null)
        {
            _index = -1;
        }
        
        if(telas.getIndex() == telas.length - 1 && _index == null)
        {
            return;
        }
        
        console.log("testando o index 2..." + _index)
        var teste;
        if(_index == null)
            teste = telas.getTela(telas.getIndex() + 1);
        else
            teste = telas.getTela(_index);        
        
        console.log("testando o index...." + telas.getIndex());
        if(telas.getIndex() > inicio)
        {
            ativarVoltar();
        }
        else
        {
            desativarVoltar();
        }
        
        if(teste == null)
        {
            console.log("não tem mais telas");
            desativarAvancar();
            return;
        }
        
        if(lms){
            console.log("é o fim?........" + telas.isEnd);
            console.log("lms......" + telas.getIndex())
			
			scorm.data.set("cmi.core.lesson_location", telas.getIndex());
			
			var total = (fim - inicio)+1;
			console.log("total de telas é: " + total);
			
			var atual = (telas.getIndex()-inicio);
			console.log("página atual: " + atual);
			
			if(atual>fim){
				atual = (fim-inicio)+1;
			}
			
			var pct = (atual*100)/total;
			console.log("porcentagem....." + pct);
            
            console.log("qual é o por curso? " + porCurso);
			
			//alert(total+" - "+atual+" - "+pct);
			if(pct > porCurso){
				porCurso = pct;
				scorm.data.set("cmi.core.score.raw", porCurso);
                console.log("entrei no primeiro if");

               if(porCurso >= 100){

                   console.log("entrei no segundo if");
                   console.log("CORRECTS é diferente de null?")
					
                   if(CORRECTS == null)
                   {
					   var lStatus = scorm.data.get("cmi.core.lesson_status");
					   if(lStatus != "passed" || lStatus != "failed"){
						   scorm.data.set("cmi.core.score.raw", porCurso);
						   scorm.data.set("cmi.core.lesson_status","completed");
					   }
                   }
                   else
                   {
                       var total = CORRECTS / 3;

                       console.log("numero de corrects : " + CORRECTS);
                       console.log("o total de acertos é: " + total);

                       if(total >= MINIMUN_AVAL)
                       {
                            scorm.data.set("cmi.core.lesson_status","passed");

                            console.log("PASSEI");
                       }
                       else
                       {
                            scorm.data.set("cmi.core.lesson_status","failed");

                            console.log("NÃO PASSEI");
                       }

                       scorm.data.set("cmi.core.score.raw", Math.round(total * 100));
                       CORRECTS = null;
                   }
                }
            }
        }
        
        allow = allow < telas.getIndex() ? telas.getIndex() : allow;
        if(allow > telas.getIndex()) ativarAvancar();
    }
    
    function ativarVoltar()
    {
        leftbt.css({
            background: 'url(' + leftbt.active + ') no-repeat center center',
            backgroundSize: "100% 100%"
        });
        leftbt.isOn = true;
        leftOldState = true;
    }
    
    function desativarVoltar()
    {
        leftbt.css({
            background: 'url(' + leftbt.inactive + ') no-repeat center center',
            backgroundSize: "100% 100%"
        });
        leftbt.isOn = false;
        leftOldState = false
    }
    
    function ativarAvancar()
    {
        rightbt.css({
            background: 'url(' + rightbt.active + ') no-repeat center center',
            backgroundSize: "100% 100%"
        });
        rightbt.isOn = true;
        rightOldState = true;
    }
    
    function desativarAvancar()
    {
        rightbt.css({
            background: 'url(' + rightbt.inactive + ') no-repeat center center',
            backgroundSize: "100% 100%"
        });
        rightbt.isOn = false;
        rightOldState = false
    }
    
    function urlVar()
    {
        return (location.search.match(new RegExp('t=([^?&=]+)')) || [])[1] || '';
    }
    
    console.log("obtendo variavel: " + urlVar());
    var indexDinamico = isNaN(parseInt(urlVar())) ? undefined : parseInt(urlVar());
    
    if(indexDinamico != undefined && indexDinamico > 0 && indexDinamico < telas.length)
    {
        telas.getTela(indexDinamico);
        return;
    }
    
    if(fim == -1) fim = telas.length - 1;
    
    setTimeout(function(){
		if(lms){
			var ts = isNaN(telaScorm) ? inicio : telaScorm;            
			telas.getTela(ts);
            
            if(ts > inicio)
            {
                ativarVoltar();
            }
            else
            {
                desativarVoltar();
            }
            
		}else{
        	telas.getTela(inicio);
		}
    }, 1000);
    if(inicio == 0)
    ativarAvancar();
    if(lms){
		if(fim==(telas.length-1)){
			scorm.data.set("cmi.core.score.raw", 100);
			scorm.data.set("cmi.core.lesson_status","completed"); 
		}
	}
    /*setTimeout(function(){
        telas.getTela(1);
    }, 5000);*/
});