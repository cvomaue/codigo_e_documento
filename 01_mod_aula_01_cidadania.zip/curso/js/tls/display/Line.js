function Line(points)
{
    Base.call(this);
    
    var self = this;
    this._points = points;
    this._p1 = points[0];
    this._p2 = points[1];
    
    this._isMove = false;
    this._correct = false;
    
    this._feed = true;
    
    this._circleOne = new PIXI.Graphics();
    this._circleOne.lineStyle(4, 0x0eafaa);
    this._circleOne.beginFill(0xffffff);
    this._circleOne.drawCircle(0, 0, this._p1.width / 2);
    this._circleOne.endFill();
    this._circleOne.cacheAsBitmap = true;
    
    this._circleOne.x = this._p1.x + this._p1.width / 2;
    this._circleOne.y = this._p1.y + this._p1.height / 2;
    
    //circleOne.alpha = 0;
    
    this._circleTwo = new PIXI.Graphics();
    this._circleTwo.lineStyle(4, 0x0eafaa);
    this._circleTwo.beginFill(0xffffff);
    this._circleTwo.drawCircle(0, 0, this._p2.width / 2);
    this._circleTwo.endFill();
    this._circleTwo.cacheAsBitmap = true;
    
    this._circleTwo.x = this._p2.x + this._p2.width / 2;
    this._circleTwo.y = this._p2.y + this._p2.height / 2;
    this._circleTwo.alpha = 0;
    
    this._line = new PIXI.Graphics();    
    
    this.addChild(this._circleOne);
    this.addChild(this._circleTwo);
    this.addChild(this._line);
}

Line.prototype = Object.create(Base.prototype);
Line.prototype.constructor = Line;

Object.defineProperties(Line.prototype, {
    feed: {
        set: function(value){
            this._feed = value;
        }        
    }
})

Line.prototype.addEvents = function()
{
    this._circleOne.interactive = true;
    this._circleOne.buttonMode = true;
    
    this._circleOne
        .on('mousedown', this._onDown)
        .on('touchstart', this._onDown)

        .on('mouseup', this._onUp)
        .on('touchend', this._onUp)
        .on('mouseupoutside', this._onUp)
        .on('touchendoutside', this._onUp)

        .on('mousemove', this._onMove)
        .on('touchmove', this._onMove);    
}

Line.prototype.removeEvents = function()
{
    this._circleOne.interactive = false;
    this._circleOne.buttonMode = false;
    
    this._circleOne
        .removeListener('mousedown', this._onDown)
        .removeListener('touchstart', this._onDown)

        .removeListener('mouseup', this._onUp)
        .removeListener('touchend', this._onUp)
        .removeListener('mouseupoutside', this._onUp)
        .removeListener('touchendoutside', this._onUp)

        .removeListener('mousemove', this._onMove)
        .removeListener('touchmove', this._onMove); 
}

Line.prototype._onDown = function(e)
{
    var self = this.parent;
    
    TweenMax.to(this.scale, 0.2, {x: 1.2, y: 1.2, ease: Elastic.easeOut});           

    this._data = e.data;
    this._pi = new PIXI.Point(self._p1.x + self._p1.width / 2, self._p1.y + self._p1.height / 2);

    self._isMove = true;
}

Line.prototype._onUp = function(e)
{
    var self = e.target.parent;
    
    self._isMove = false;

    TweenMax.to(this.scale, 0.2, {x: 1, y: 1, ease: Back.easeOut});

    try{
        var p = this._data.getLocalPosition(this.parent);
    }
    catch(err)
    {
        return;
    }

    if(p.x > self._p2.x &&
      p.x < self._p2.x + self._p2.width &&
      p.y > self._p2.y &&
      p.y < self._p2.y + self._p2.height)
    {
        self._correct = true;

        self.removeEvents();

        TweenMax.to(self._circleTwo.scale, 0.2, {x: 1, y: 1, ease: Elastic.easeOut});
        
        if(self._feed)
        TweenMax.to(self._circleTwo, 0.2, {alpha: 1});

        self._line.clear();
        self._drawLine(this._pi, new PIXI.Point(self._p2.x + self._p2.width / 2, self._p2.y + self._p2.height / 2));

        self.emit("correct");
    }
    else
    {
        console.log("errou");
        self._line.clear();

        self.emit("incorrect");
    }

    this._data = null;
    this._pi = null; 
}

Line.prototype._onMove = function(e)
{
    var self = this.parent;
    
    if(self._isMove)
    {
        var p = this._data.getLocalPosition(this.parent);

        self._line.clear();             
        self._drawLine(this._pi, p);
    }
}

Line.prototype._drawLine = function(init, end)
{
    this._line.lineStyle(5, 0x62706f);
    this._line.moveTo(init.x, init.y);
    this._line.lineTo(end.x, end.y);
    this._line.endFill();
}

Line.prototype.destroy = function()
{
    this.removeChildren();
    this._circleOne.destroy();
    this._circleTwo.destroy();
    this._line.destroy();
    this.removeEvents();
    this.removeAllListeners();
    
    Base.prototype.destroy.call(this);
}

tls.display.Line = Line;