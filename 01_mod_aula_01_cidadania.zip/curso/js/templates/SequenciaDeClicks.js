function Tela05_b()
{
    tls.core.Factory.call(this, "telas/005_b/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/005_b/5b_1.mp3");
    this.soundManager.addSingleSound("telas/005_b/5b_2.mp3");
    this.soundManager.addSingleSound("telas/005_b/5b_3.mp3");
    this.soundManager.addSingleSound("telas/005_b/5b_4.mp3");
    this.soundManager.addSingleSound("telas/005_b/5b_5.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.atual = 0;
    
    this.on("complete", function(){
        this.removeListener("complete");
        this.init();
    });    
}

Tela05_b.prototype = Object.create(tls.core.Factory.prototype);
Tela05_b.prototype.constructor = Tela05_b;

Tela05_b.prototype.init = function()
{
    var self = this;
    
    for(var i = 0; i < this.clicks.length; i++)
    {
        var c = this.clicks[i];
        c.addIcon();
        c.id = i;
        c.on("clicked", function(){
            this.removeListener("clicked");
            this.removeEvents();
            this.icon.stopAnimation();
            
            self.soundManager.AutorizeSounds();
            self.soundManager.playSound(this.id);
            self.soundManager.on("soundComplete", function(){
                this.removeListener("soundComplete");
                
                self.atual++;
                
                if(self.atual >= self.clicks.length)
                {
                    self.emit("removeAll");
                    return;
                }
                
                self._initIcons(self.atual);                
            });
        });
        
        c.alpha = 0;
    }
    
    this._initIcons(this.atual);
}

Tela05_b.prototype._initIcons = function(index)
{
    this.clicks[index].open();
    this.clicks[index].icon.animate();
    this.clicks[index].addEvents();
}

Tela05_b.prototype.destroy = function()
{
    this.soundManager.destroy();
    for(var i = 0; i < this.clicks.length; i++)
    {
        this.clicks[i].destroy();
    }
    
    tls.core.Factory.prototype.destroy.call(this);
}