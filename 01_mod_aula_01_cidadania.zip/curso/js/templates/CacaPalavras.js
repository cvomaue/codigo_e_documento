function Tela()
{
    tls.core.Factory.call(this, "telas/007/sprites.json");    
    
    //Lista dos audios que a tela vai usar
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/007/7_1.mp3");
    this.soundManager.addSingleSound("telas/007/7_2.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    //Constante
    this.correct = 0;
    //Número de palavras corretas que a cruzadinha vai ter
    this.numCorrects = 2;
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        //Balao para o feed positivo
        this.feedOkIndex = 1;
        //Balao para o feed negativo
        this.feedFailIndex = 0;
        //Boca do feed positivo
        this.bocaFeedOkIndex = 1;
        //Boca do feed negativo
        this.bocaFeedFailIndex = 0;
        //Som do feed positivo
        this.soundOkIndex = 1;
        //Som do feed negativo
        this.soundFailIndex = 0;
        
        this.init();
        
        //String de todas as letras que a cruzadinha vai ter. Sempre na orderm de linha a linha
        var letras = "";
        letras += "C,V,B,N,A,N,";
        letras += "T,Z,N,P,T,E,";
        letras += "U,F,I,R,H,J,";
        letras += "L,A,S,Q,R,F,";
        letras += "M,S,O,L,O,R,";
        letras += "L,G,L,A,F,U";//não tem vígula no final da última linha
        
        //Construção da matriz. Sendo new tls.diplay.CrossWord({número de linhas},{número de colunas},{string das letras},new PIXI.Rectangle(0,0,{largura da celula},{altura da celula}));
        this.exe = new tls.display.CrossWord(6,6,letras,new PIXI.Rectangle(0,0,47,47));
        
        //posição da matriz
        this.exe.x = 342;
        this.exe.y = 169;
        
        //Gabarito. Palavras corretas
        this.exe.corrects = ["SOLO","SOL"];
        
        //Debug
        this.exe.debug = false;

        this.addChild(this.exe);
    });      
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("preStart", function(e){
        if(e.atualIndex == 0 || e.atualIndex == 2)
            e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        //self.emit("removeAll");
        self.exe.addEvents();
        //chama positivo
        self.exe.on("correct",function(){
            self.setOk();
        });
        //chama negativo
        //self.on("incorrect",setFail);
    });    
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
}                               

Tela.prototype.setOk = function()
{
    var self  = this;
    this.correct++;

    if(this.correct>=this.numCorrects)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                self.exe.addEvents();
                self.emit("removeAll");
            }, 1000);            
        });
    }
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    this.exe.removeEvents();
    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    this.exe.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}