function Calc(factory)
{
    EventEmitter.call(this);
    
    this._factory = factory;
    
    this._keys = this._factory.calcKeys;
    this._icon = this._factory.clicks[0];
    this._baseResults = this._factory.calcResults;
    this._results = [];
    
    this._countGroup = 0;
    this._countItem = 0;
    this._atualSelection;
    
    this._corrects = [];
    
    for(var i = 0; i < this._baseResults.length; i++)
    {
        if(this._results[i] == undefined) this._results[i] = [];
        
        for(var j = 0; j < this._baseResults[i].length; j++)
        {
            var r = this._baseResults[i][j];
            var res = new CalcResult(r.width / 2, "result");
            res.x = r.x;
            res.y = r.y;
            
            this._results[i].push(res);
            this._factory._layers.interactions.addChild(res);
        }
    }
    
    this._invertResults();
}

Calc.prototype = Object.create(EventEmitter.prototype);
Calc.prototype.constructor = Calc;

Object.defineProperties(Calc.prototype, {
    corrects: {
        set: function(value){
            this._corrects = value;
        }
    }
});

Calc.prototype._invertResults = function()
{
    this._results.reverse();
    for(var j = 0; j < this._results.length; j++)
    {
        this._results[j].reverse();
    }
}

Calc.prototype.addEvents = function()
{        
    var self = this;
    
    TweenMax.to(this._icon, 0.3, {y: this._keys[5].y - this._keys[5].height / 2});
    this._icon.addIcon();
    this._icon.icon.animate();
    
    for(var i = 0; i < this._keys.length - 1; i++)
    {
        var k = this._keys[i];
        k.alpha = 1;
        k.addEvents();
        k.on("clicked", function(e){
            self._setText(e)
        });
    }  
    
    this._atualSelection = this._results[this._countGroup][this._countItem];
    this._atualSelection.animate();
    
    this._keys[this._keys.length - 1].alpha = .5;
}

Calc.prototype._setText = function(e)
{
    this._atualSelection.text = e.target.value;
    this._atualSelection.stopAnimation();
    
    this._countItem++;
    if(this._countItem >= this._results[this._countGroup].length)
    {
        this._countItem = 0;
        this._countGroup ++;
    }
    
    if(this._countGroup >= this._results.length)
    {
        this._allowResult();
        return;
    }
    
    this._atualSelection = this._results[this._countGroup][this._countItem];
    this._atualSelection.animate();
}

Calc.prototype._allowResult = function()
{
    var self = this;
    
    for(var i = 0; i < this._keys.length - 1; i++)
    {
        var k = this._keys[i];
        k.removeEvents();
        k.removeListener("clicked")
        k.alpha = .5;
    }
    
    var e = this._keys[this._keys.length - 1];
    e.alpha = 1;
    e.addEvents();
    e.on("clicked", function(e){
        this.removeListener("clicked");
        this.removeEvents();
        self._icon.icon.stopAnimation();
        self._checkResult(e);
    });
    
    TweenMax.to(this._icon, 0.3, {y: e.y - e.height / 2});
}

Calc.prototype._clear = function()
{
    for(var i = 0; i < this._results.length; i++)
    {
        for(var j = 0; j < this._results[i].length; j++)
        {
            this._results[i][j].text = "";
        }
    }
}

Calc.prototype._checkResult = function(e)
{
    var res = [];
    this._invertResults();
    
    for(var i = 0; i < this._results.length; i++)
    {
        var tx = "";
        for(var j = 0; j < this._results[i].length; j++)
        {
            tx += this._results[i][j].text;
        }
        
        res.push(tx);
    }
    
    var ok = true;
    
    for(var i = 0; i < res.length; i++)
    {
        if(this._corrects[i] != parseInt(res[i]))
        {
            ok = false;
            break;
        }
    }
    
    if(ok)
    {
        this.emit("correct");
    }
    else
    {
        this._keys[this._keys.length - 1].alpha = 0.5;
        this._countGroup = 0;
        this._countItem = 0;
        
        this._invertResults();
        this._clear();
        
        this.emit("incorrect");
    }
}

Calc.prototype.destroy = function()
{
    this.removeAllListeners();
    
    for(var i = 0; i < this._results.length; i++)
    {
        var r = this._results[i];
        for(var j = 0; j < r.length; j++)
        {
            var res = this._results[i][j];
            this._factory._layers.interactions.removeChild(res);
            res.destroy();
            res = null;
        }
        
        r.splice(0, r.length);
        r = null;
    }
    
    this._keys = null;
    this._icon = null;
    this._baseResult = null;
    this._atualSelection = null;
    
    this._corrects.splice(0, this._corrects.length);
    this._corrects = null;
    
    this._results.splice(0, this._results.length);
}

tls.templates.Calc = Calc;