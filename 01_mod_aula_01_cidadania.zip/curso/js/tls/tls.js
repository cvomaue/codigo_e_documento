var tls = {
    buttons:{},
    core: {},
    display: {},
    loaders: {},
    media: {},
    templates: {},
    utils: {},
    ui: {},
    text: {}
};