function Tela()
{
    tls.core.Factory.call(this, "telas/033/sprites.json");    
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/033/12_1.mp3");
    this.soundManager.addSingleSound("telas/033/12_2.mp3");
    this.soundManager.addSingleSound("telas/033/12_3.mp3");
    this.soundManager.addSingleSound("telas/033/12_4.mp3");
    this.soundManager.addSingleSound("telas/033/12_5.mp3");
    this.soundManager.addSingleSound("telas/033/12_6.mp3");
    ///quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.on("complete", function(){
        this.removeListener("complete");
        this.init();
        
        this.feedOkIndex = 2;
        this.feedFailIndex = 1;
        this.bocaFeedOkIndex = 0;
        this.bocaFeedFailIndex = 0;
        this.soundOkIndex = 2;
        this.soundFailIndex = 1;
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.clock = new tls.templates.Clock(this);
    this.clock.corrects = [[6, 30], [0, 0], [8, 0]];
    
    this.click = this.clicks[0];
    this.click.addIcon();
    
    this.dialogos.on("preStart", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self.clock.addEvents();
        self.click.icon.animate();
        self.click.addEvents();
        self.click.on("clicked", function(e){
            this.removeEvents();
            this.icon.stopAnimation();
            
            self.clock.removeEvents();
            
            var result = self.clock.check();
            
            if(result) self.setOk();
            else self.setFail();
        });
        
        for(i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i + 2);
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }
    });    
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    
    this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
        self.clock.reset();
        
        self.click.addEvents();
        self.click.icon.animate();
        
        self.clock.addEvents();
    });
}

Tela.prototype.setOk = function()
{
    var self  = this;

    this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
        setTimeout(function(){
            self.emit("removeAll");
        }, 1000);            
    });      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound); 
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    this.clock.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}