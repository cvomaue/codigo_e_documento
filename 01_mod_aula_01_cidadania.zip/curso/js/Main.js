function _main()
{    
    EventEmitter.call(this);
    
    this._backURLs;
    this._backOrder;
    this._backLoader;
    this._backComplete = false;
    
    this._p;
    this.renderer;
    this.stage;
    
    this.isEnd = null;
    this.enterframe;
    
    this.font = new Font();
    this.font.fontFamily = "Angola";
    this.font.src = this.font.fontFamily;
}

_main.prototype = Object.create(EventEmitter.prototype);
_main.prototype.constructor = _main;

_main.prototype.init = function(_parent, controller)
{
    var self = this;
    
    var base_width = 974;
    var base_height = 524;
    
    PIXI.loader.reset();

    this.isEnd = false;

    this._p = _parent;

    this.renderer = PIXI.autoDetectRenderer(base_width, base_height, {transparent: true});
    tls.renderer = this.renderer;
    tls.parent = _parent;
    tls.base_width = base_width;
    tls.base_height = base_height;
    this._p.append(this.renderer.view);

    this.stage = controller;
    this.stage.on("removeAll", function(e){
        self.clear();
    });

    //----------------------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------------------
    // INICIO DO DEBUG -----------------------------------------------------------------------------------------
    //comentar o bloco a seguir para remover
  /*  var debug = new PIXI.Text($(_parent).attr("id") + " index: " + telas.getIndex(), {font: "18px Arial", fill: 0xff0000, align: 'center'});
    debug.alpha = 0;

    var bdebug = new PIXI.Graphics();
    bdebug.beginFill(0xffffff);
    bdebug.drawRect(0, 0, debug.width, debug.height);
    bdebug.endFill();

    this.stage.addChild(bdebug);
    this.stage.addChild(debug);

    this.stage.setChildIndex(bdebug, this.stage.children.length - 1);
    this.stage.setChildIndex(debug, this.stage.children.length - 1);
    debug.x = this._p.width() - debug.width;
    bdebug.x = debug.x;
    debug.alpha = 1;*/
    //----------------------------------------------------------------------------------------------------------
    // FIM DO DEBUG --------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------------------

    this.animate(this);
}

_main.prototype.animate = function(self)
{
    if(this.isEnd)
    {
        if(this.enterframe)
        cancelAnimationFrame(this.enterframe);

        this.enterframe = undefined;

        return;
    }
    
    this.enterframe = requestAnimationFrame(function(){
        self.animate(self);
    });

    this.renderer.render(this.stage);
}

_main.prototype.clear = function(self, imediate)
{   
    console.log("clear..................")
    var im = imediate || false;
    
    var _self = self != null? self : this;

    try{
        _self.stage.removeListener("removeAll");
        console.log("listener removido do stage")
    }
    catch(err)
    {
        console.log("erro ao remover listener do stage")
    }

    _self.isEnd = true;

    var time = im ? 0 : 0;

    //setTimeout(function(im){
        _self.end(im);
    //}, time, im);
}

_main.prototype.end = function(immediate)
{
    var im = immediate || false;
    
    console.log("quem sou eu?");
    console.log(this);
    try{
        var bocas = this.stage.bocas;
        for(var i = 0; i < bocas.length; i++)
        {
            var b = bocas[i];
            b.gotoAndStop(b.stationary);
        }
        
        this.renderer.render(this.stage);
    }
    catch(err){}
    this.stage.destroy();

    Object.keys(PIXI.utils.TextureCache).forEach(function(texture) {
      PIXI.utils.TextureCache[texture].destroy(true);
    });

    this.renderer.destroy(true);
    console.log("renderer....");
    console.log(this.renderer)

    this.stage = null;
    this.renderer = null;

    PIXI.loader.reset();
    console.log("fim da  limpeza")
    if(!im)
    {
        console.log("avançando a página... não era para eu estar aqui")
        avancarPagina();  
    }
}

_main.prototype.getIsEnd = function()
{
    return this.isEnd;
}

var Main = new _main();