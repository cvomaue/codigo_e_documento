function TxGroup()
{
    Base.call(this);
    
    this._images = [];
    this._audios = [];
}

TxGroup.prototype = Object.create(Base.prototype);
TxGroup.prototype.constructor = TxGroup;

tls.display.TxGroup = TxGroup;