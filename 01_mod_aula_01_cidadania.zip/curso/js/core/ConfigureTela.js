telas.defineBackground([
    "telas/back/abertura.png",//0
    "telas/back/exercicio.png",//1
    "telas/back/001.png",//2
    "telas/back/002.png",//3
    "telas/back/003.png",//4
    "telas/back/004.png",//5
    "telas/back/005.png",//6
    "telas/back/006.png",//7
    "telas/back/007.png",//8
    "telas/back/008.png",//9
    "telas/back/009.png",//10
    "telas/back/010.png",//11
    "telas/back/011.png",//12
    "telas/back/fim.png",
    "imgs/ajuda.png"
    
    
]);

telas.addTelaFim("fim",13);

telas.addTela("tela00",0);// 0          0
telas.addTela("tela01",1);// 1          1
telas.addTela("tela02",2);// 2          2
telas.addTela("tela02b",3);// 2b        3
telas.addTela("tela03",10);// 3         4
telas.addTela("tela03b",11);// 3b       5
telas.addTela("tela03c",12);// 3c       6
telas.addTela("tela04",4);// 4          7
telas.addTela("tela05",1);// 5          8
telas.addTela("tela06",1);// 6          9
telas.addTela("tela07",4);// 7          10
//telas.addTela("tela07b";//1, // 7b    
telas.addTela("tela08",5);// 8          11
//telas.addTela("tela08b";//1, // 8b
telas.addTela("tela09",6);// 9          12
telas.addTela("tela10",2);// 10           13
telas.addTela("tela10b",2);// 10b       14
telas.addTela("tela10c",2);// 10c       15
telas.addTela("tela10d",2);// 10d       16
telas.addTela("tela11",1);// 11         17
telas.addTela("tela12",1);// 12         18
telas.addTela("tela12b",1);// 12b       19
telas.addTela("tela12c",1);// 12c       20
telas.addTela("tela12d",1);// 12d       21
telas.addTela("tela13",1);// 13         22
telas.addTela("tela14",4);// 14         23
telas.addTela("tela15",7);// 15         24
//telas.addTela("tela15b";//1, // 15b
telas.addTela("tela16",1);// 16         25
telas.addTela("tela17",9);// 17         26
//telas.addTela("tela17b";//1, // 17b
telas.addTela("tela18",1);// 18         27
telas.addTela("tela19",8);// 19         28
telas.addTela("tela19b",8);// 19b       29
telas.addTela("tela20",1);// 20         30
telas.addTela("tela21",1);// 21         31
telas.addTela("tela13ex",1);            //32
telas.addTela("tela22",8);// 22         33
//telas.addTela("tela22b";//1  // 22b