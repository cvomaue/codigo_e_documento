function WriteLetter(txGroup, soundManager, keyboard)
{
    EventEmitter.call(this);
    
    this._txGroup = txGroup;
    this._soundManager = soundManager;
    this.keyboard = keyboard;
    
    this._checkActivity;
    this._corrects = [];
    this._count = 0;
    
    this._txIndex = 0;
    
    this._upperCase = false;
}

WriteLetter.prototype = Object.create(EventEmitter.prototype);
WriteLetter.prototype.constructor = WriteLetter;

Object.defineProperties(WriteLetter.prototype, {
    corrects: {
        set: function(value){
            this._corrects = value;
        }
    },
    
    upperCase: {
        set: function(value)
        {
            this._upperCase = value;
        }
    }
})

WriteLetter.prototype.open = function()
{
    var self = this;
    
    this._txGroup.setAudio(this._soundManager);
    this._txGroup.addTextEvents();
    this._txGroup.on("focus", function(e){
        self._txIndex = e.index;
        var ob = self._txGroup.inputs[e.index];
        //var p = //self._txGroup.toGlobal(ob.position);
        
        //TweenMax.to(self._txGroup, 0.5, {y: 120 + (-ob.y + 85)});
    });
    
    this._txGroup.on("blur", function(e){
        //TweenMax.to(self._txGroup, 0.3, {y: 0});
    });
    
    this._txGroup.on("textUpdate", function(e){
        
        if(self._upperCase) this.inputs[e.index].text = this.inputs[e.index].text.toUpperCase();
        
        if(this.inputs[e.index].text.length == this.inputs[e.index].maxChars)
        {
            self.keyboard.hide();
            self.checkResult(this.inputs[e.index], e.index);            
        }
    });
    
    this._txGroup.inputs[0].focus();
    
    for(var i = 0; i < this._txGroup.audios.length; i++)
    {
        var a = this._txGroup.audios[i];
        a.animate();
        a.addEvents();
    }
    
    this.keyboard.on("keyPressed", function(e){
        if(e.value == "backspace")
        {
            var tx = self._txGroup.inputs[self._txIndex].text;
            tx = tx.substr(0, tx.length - 1);
            
            self._txGroup.inputs[self._txIndex].text = tx;
        }
        else
        {
            self._txGroup.inputs[self._txIndex].text += e.value;
        }
        
        self._txGroup.emit("textUpdate", {index: self._txIndex});
    });
    
    this.keyboard.show();
}

WriteLetter.prototype.checkResult = function(input, index)
{
    this._txGroup.removeTextEvents();
    GOWN.InputControl.blur();
    
    //TweenMax.to(this._txGroup, 0.3, {y: 0});
    
    var self = this;
    //console.log(index)
    if(input.text == this._corrects[index])
    {
        input.block = true;
        input.openFeed("ok");        
            
        self._count++;

        if(self._count >= self._txGroup.inputs.length)
        {
            setTimeout(function(){
                self.emit("end");
            }, 100);
            return;
        }
        
        setTimeout(function(){
            self.keyboard.show();
        }, 200);

        for(var i = 0; i < self._txGroup.inputs.length; i++)
        {
            if(!self._txGroup.inputs[i].block)
            {
                self._txGroup.addTextEvents();
                self._txGroup.inputs[i].focus();
                
                return;
            }
        }
    }
    else
    {
        input.openFeed("fail");
        setTimeout(function(){
            input.closeFeed();
            setTimeout(function(){
                input.text = "";
                self._txGroup.addTextEvents();
                input.focus();
                
                self.keyboard.show();
            }, 400);            
        }, 1500);
    }
}

WriteLetter.prototype.checkActivity = function()
{
    this._checkActivity = setTimeout(function(){
        GOWN.InputControl.blur();
    }, 5000);
}

WriteLetter.prototype.destroy = function()
{
    this._txGroup.destroy();
    
    this.keyboard = null;
}

tls.templates.WriteLetter = WriteLetter;