function Tela()
{
    tls.core.Factory.call(this, "telas/013ex/sprites.json");
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/013ex/13_1.mp3");
    this.soundManager.addSingleSound("telas/013ex/13_2.mp3");
    this.soundManager.addSingleSound("telas/013ex/13_3.mp3");
    this.soundManager.addSingleSound("telas/013ex/13_4.mp3");
    this.soundManager.addSingleSound("telas/013ex/13_5.mp3");
    this.soundManager.addSingleSound("telas/013ex/13_6.mp3");
    this.soundManager.addSingleSound("telas/013ex/13_7.mp3");
    this.soundManager.addSingleSound("telas/013ex/13_8.mp3");
    
    this.dialogos;
    
    this.correct = 0;
    
    
    this.on("complete", function(){
        this.removeListener("complete");
        
        this.feedOkIndex = 1;
        this.feedFailIndex = 3;
        this.bocaFeedOkIndex = 0;
        this.bocaFeedFailIndex = 0;
        this.soundOkIndex = this.soundManager._sounds.length-1;
        
         this._tempDrags = [];
        this.isFail = false;
        
        this.init();
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;  
    for(i=0; i < self.areaDrags.length; i++)
    {
        this._tempDrags.push(new tls.display.AreaDrag(self.areaDrags[i]));
    }
    
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("start", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("end", function(e){
        //console.log(self.areaDrags)
        this.removeListener("end");
        
         for(var i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i);
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }
        
        self.addDragsEvents();
    });
    
     this.dialogos.on("end", function(e){
        this.removeListener("end");

        for(i = 1; i < self.audios.length; i++)
        {
            var a = self.audios[i];
            a.setAudio(self.soundManager, i );
            a.animate();
            a.addEvents();
            a.on("soundStart", function(){
                self.bocas[0].play();
            });
            a.on("soundComplete", function(){
                self.bocas[0].gotoAndStop(self.bocas[0].stationary);
            });
        }

    });
    
    this.configureDrags();
    
    this.dialogos.play();
}

Tela.prototype.setFail = function()
{   
    var self = this;
    self.removeDragsEvents(); 
  
    self.emit('removeAll');
/*    this.getFeed(this.feedFailIndex, this.bocaFeedFailIndex, this.soundFailIndex, function(){
        
        for(i = 0; i < self._tempDrags.length; i++)
        {
            var b = self._tempDrags[i];
            var d = b.children[0];
            d.isOff = false;
            d.lockColision = false;
            console.log("limpando...." + i)
            b.clear();
        }
        self.addDragsEvents(); 
    
    });*/
}

Tela.prototype.setOk = function()
{
    var self  = this;
    self.removeDragsEvents(); 
    
    self.correct++;

    if(self.correct >= self.areaDrags.length)
    {
        this.getFeed(this.feedOkIndex, this.bocaFeedOkIndex, this.soundOkIndex, function(){
            setTimeout(function(){
                if(!self.isFail){
                    console.log("pontuei")
                CORRECTS++;
                }
                self.emit("removeAll");
            }, 1000);                
        });

        return;
    }

    self.addDragsEvents();        
      
}

Tela.prototype.getFeed = function(indexBallon, indexMouth, indexSound, end)
{
    this.removeDragsEvents();
    
    var b = this.ballons[indexBallon];
    b.direction = "-";
    b.open();
    
    var m = this.bocas[indexMouth];
    m.play();
    
    this.soundManager.on("soundComplete", function(){
        this.removeListener("soundComplete");
        
        b.close();
        m.gotoAndStop(m.stationary);
        
        if(end != null && end != undefined) end();
    });
    
    this.soundManager.playSound(indexSound);  
}

Tela.prototype.configureDrags = function()
{
    var self = this;
    
    for(var i = 0; i < self._tempDrags.length; i++){
    self._tempDrags[i].maxChildren = 3;
        self._tempDrags[i].align = "vertical";
        self._tempDrags[i].vspace = 20;
        self._tempDrags[i].on('full', function(){
            self.verify(this);
        })
    }
    
    for(var i = 0; i < self.drags.length; i++)
    {
        
        self.drags[i].collisions = self._tempDrags;            
        self.drags[i].id = i;

        self.drags[i].usePoint = true;
        self.drags[i].adjust = false;
        self.drags[i].lockColision = false;
    }
}
Tela.prototype.addDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        if(this.drags[i].isOff) continue;
        this.drags[i].addEvents();
    }
}

Tela.prototype.removeDragsEvents = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].removeEvents();
    }
}

Tela.prototype.verify = function(area)
{
        var self = this;
        area.children[0].isOff = true;

        self.removeDragsEvents();
        
        self.correct++;        
        
   if (self.correct >= self.areaDrags.length) {
            var check = true;
            var item1 = false;
            var item2 = false;
            var item3 = false;
       
            for(var i = 0; i < this._tempDrags.length; i++)
            {
                var a = this._tempDrags[i];
                
                for(var j = 0; j < a.children.length; j++)
                {
                    /*if(a.children[0].id != i)
                    {
                        check = false; 
                        break;
                    }*/
                    console.log("a.children: ", a.children[j].id);
                    if(a.children[j].id == 1)
                        item1 = true;
                    if(a.children[j].id == 2)
                        item2 = true;
                    if(a.children[j].id == 5)
                        item3 = true;
                }
                
                    
                if(item1 == false || item2 == false || item3 == false)
                {
                    check = false; 
                    break;
                }
               
            }
            
            if(check)
            {
                self.setOk();
                
            }
            else
            {
                this.correct = 0;
                
                self.isFail = true;
                
                self.setFail();
                
            }
        }
        
        self.addDragsEvents();

}

Tela.prototype.destroy = function()
{
    for(var i = 0; i < this.drags.length; i++)
    {
        this.drags[i].destroy();
    }
    
    this.dialogos.destroy();
    
    this.soundManager.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}