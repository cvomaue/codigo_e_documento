/**
* Cria uma area clicável com suporte para um ícone de click
*
* @class
* @extends tls.core.Base
* @memberof tls.buttons
* @param [_w=10] {number} a largura da área
* @param [_h=10] {number} a altura da área
*/
function AreaButton(_w, _h)
{
    Base.call(this);
    
    /**
    * Largura da área
    *
    * @member {number}
    * @default 10
    * @private
    */
    this._width = _w || 10;
    
    /**
    * Altura da área
    *
    * @member {number}
    * @default 10
    * @private
    */
    this._height = _h || 10;
    
    /**
    * ícone pré definido
    *
    * @member {tls.buttons.AnimateButton}
    * @private
    */
    this._icon = new AnimateButton(tls.display.Textures.CLICK);
    
    /**
    * controle para verificar se o icone está sendo usado
    * 
    * @member {boolean}
    * @private
    */
    this._iconAdded = false;
    
    /**
    * Posição do ícone em relaçãp à área
    *
    * @member {object}
    * @property {object} _iconAtualAlign
    * @property {string} [_iconAtualAlign.hAlign=AreaButton.R]
    * @property {string} [_iconAtualAlign.vAlign=AreaButton.B]
    * @private
    */
    this._iconAtualAlign = {hAlign: AreaButton.R, vAlign: AreaButton.B};
    
    /**
    * Área
    *
    * @member {PIXI.Graphics}
    * @private
    */
    this._area = new PIXI.Graphics();
    var a = this._area;
    a.lineStyle(2, 0xff0000);
    a.beginFill(0xffffff, 0);
    a.drawRect(0, 0, 
              this._width,
              this._height);
    a.endFill();
    
    /**
    * deixando a área escondia servindo apenas para suporte
    * setando alpha para 0
    */
    a.alpha = 0;
    
    /**
    * Disparado quando o usuário solta a pressão do mouse ou tira o toque da tela
    * após ter precionado ou tocado representando uma ação de click
    *
    * @event clicked
    * @memberof AreaButton#
    */
    
    /**
    * adicionando a área para a lista de exibição
    */
    this.addChild(this._area);
}

AreaButton.prototype = Object.create(Base.prototype);
AreaButton.prototype.constructor = AreaButton;

Object.defineProperties(AreaButton.prototype, {
    /**
    * Retorna o objeto ícone se foi adicionado
    * Retorna {null} se não foi adicionado
    *
    * @member {tls.buttons.AnimateButton}
    * @readonly
    * @public
    */ 
    icon: {
        get: function(){
            if(!this._iconAdded) return null;
            
            return this._icon;
        }
    },
    
    /**
    * Deixa a área visível
    *
    * @param value {boolean}
    * @public
    */
    debug: {
        set: function(value)
        {
            if(value === true) this._area.alpha = 1;
            else if(value === false) this._area.alpha = 0;
        }
    }
});

/**
* Faz uma animação de fade em alpha de 0 para 1
* antes deve setar o alpha para 0
*
* ```js
* var b = new AreaButton(_w, _h);
* b.alpha = 0;
* b.open();
* ```
*
* @memberof AreaButton
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
AreaButton.prototype.open = function(onComplete, onCompleteParams)
{
    this.openWithFade(onComplete, onCompleteParams);
}

/**
* Faz uma animação de fade em alpha de 1 para 0
*
* @memberof AreaButton
* @param onComplete {function} Função executada no término da animação
* @param onCompleteParams {array} Array contendo os parametros da função onComplete
* @public
*/
AreaButton.prototype.close = function(onComplete, onCompleteParams)
{
    this.closeWithFade(onComplete, onCompleteParams);   
}

/**
* Adiciona os eventos suporte de mouse e touch
* inicia o modo interativo
*
* @memberof AnimateButton
* @public
*/
AreaButton.prototype.addEvents = function()
{
    this.interactive = true;
    this.buttonMode = true;
    
    this
        .on('mousedown', this._onDown)
        .on('touchstart', this._onDown)

        .on('mouseup', this._onUp)
        .on('touchend', this._onUp)
        .on('mouseupoutside', this._onUp)
        .on('touchendoutside', this._onUp);
}

/**
* Remove os eventos suporte de mouse e touch
* encerra o modo interativo
*
* @memberof AnimateButton
* @public
*/
AreaButton.prototype.removeEvents = function()
{
    this.interactive = false;
    this.buttonMode = false;
    
    this
        .removeListener('mousedown', this._onDown)
        .removeListener('touchstart', this._onDown)

        .removeListener('mouseup', this._onUp)
        .removeListener('touchend', this._onUp)
        .removeListener('mouseupoutside', this._onUp)
        .removeListener('touchendoutside', this._onUp);
}

/**
* @private
*/
AreaButton.prototype._onDown = function(e)
{
    
}

/**
* Ao retirar a pressão do mouse ou retirar o toque na tela
*
* @memberof AreaButton
* @param e {MouseEvent/TouchEvent}
* @fires clicked
* @private
*/
AreaButton.prototype._onUp = function(e)
{
    this.emit("clicked", e);
}

/**
* Adiciona o ícone à lista de exibição
*
* ```js
* var a = new AreaButton(_w, _h);
* a.addIcon();
* ```
*
* @memberof AreaButtom
* @public
*/
AreaButton.prototype.addIcon = function()
{
    this.addChild(this._icon);
    
    /**
    * Adiciona o método alignIcon ao icone
    */
    this._icon.align = this._alignIcon;
    
    this._iconAdded = true;
    
    this._alignIcon(AreaButton.R, AreaButton.B);    
}

/**
* Método para alinhamento do ícone em relação à área
* Esse método é adicionado no ícone e é utilizado a partir dele
*
* ```js
* var a = new AreaButton(_w, _h);
* a.addIcon();
* a.icon.align("top", "left");
* ```
*
* @memberof AreaButton
* @param hAlign {string} alinhamento horizontal ('left', 'center', 'right')
* @param vAlign {string} alinhamento vertical ('top', 'center', 'bottom')
* @private
*/
AreaButton.prototype._alignIcon = function(hAlign, vAlign)
{
    if(!this._iconAdded) return;
    
    var h = hAlign || null;
    var v = vAlign || null;
    
    if(h != null && h != undefined) this._iconAtualAlign.hAlign = h;
    else h = this._iconAtualAlign.hAlign;
    
    if(v != null && v != undefined) this._iconAtualAlign.hAlign = v;
    else v = this._iconAtualAlign.vAlign;
    
    switch(h)
    {
        case AreaButton.L:
            this._icon.x = this._icon.width / 2;
            break;
        case AreaButton.C:
            this._icon.x = this._area.width / 2;
            break;
        case AreaButton.R:
            this._icon.x = this._area.width - this._icon.width / 2;
            break;
    }

    switch(v)
    {
        case AreaButton.T:
            this._icon.y = this._icon.height / 2;
            break;
        case AreaButton.C:
            this._icon.y = this._area.height / 2;
            break;
        case AreaButton.B:
            this._icon.y = this._area.height - this._icon.height / 2;
            break;            
    }
}

/**
* Alterar o tamanho da área
*
* @memberof AreaButton
* @param _w {number} nova largura
* @param _h {number} nova altura
* @public
*/
AreaButton.prototype.setArea = function(_w, _h)
{
    this._area.width = _w;
    this._area.height = _h;

    if(this._iconAdded)
        this._alignIcon();
}

/**
* Suporte para limpar a memória
* destroi todos os objetos e remove os eventos
*
* @memberof AreaButton
* @public
*/
AreaButton.prototype.destroy = function()
{
    this.removeEvents();
    this.removeChildren();
    this.removeAllListeners();
    
    this._icon.destroy();
    this._area.destroy();
    
    Base.prototype.destroy.call(this);
}

/**
* @static
* @constant
* @property {string} [R='right']
*/
AreaButton.R = "right";

/**
* @static
* @constant
* @property {string} [L='left']
*/
AreaButton.L = "left";

/**
* @static
* @constant
* @property {string} [C='center']
*/
AreaButton.C = "center";

/**
* @static
* @constant
* @property {string} [T='top']
*/
AreaButton.T = "top";

/**
* @static
* @constant
* @property {string} [B='bottom']
*/
AreaButton.B = "bottom";

tls.buttons.AreaButton = AreaButton;