function MemoryGame(factory, type)
{
    EventEmitter.call(this);
    
    this._factory = factory;
    this._cards = this._factory.cards;
    this._type = type;
    
    this._atualIndex = null;
    this._selections = [];
    
    this._corrects = [];
    
    if(type == "memory")
    for(var i = 0; i < this._cards.length / 2; i++)
    {
        this._cards[i].index = i;
        this._cards[i + this._cards.length / 2].index = i;
    }
    else if(type == "individual")
    for(var i = 0; i < this._cards.length; i ++)
    {
        this._cards[i].index = i;
    }
}

MemoryGame.prototype = Object.create(EventEmitter.prototype);
MemoryGame.prototype.constructor = MemoryGame;

Object.defineProperties(MemoryGame.prototype, {
    corrects: {
        set: function(value){
            this._corrects = value;
        }
    }
});

MemoryGame.prototype.init = function()
{
    var self = this;
    
    this._openCards();
    
    setTimeout(function(){
        /*self.on("closeComplete", function(e){
            self._addEvents();
        });*/
        self._closeCards();        
    }, 4000);
}

MemoryGame.prototype._openCards = function()
{
    for(var i = 0; i < this._cards.length; i++)
    {
        this._cards[i].open();
    }
    
    this.emit("openComplete");
}

MemoryGame.prototype._closeCards = function()
{
    for(var i = 0; i < this._cards.length; i++)
    {
        this._cards[i].close();
    }
    
    this.emit("closeComplete");
}

MemoryGame.prototype._addEvents = function()
{
    var self = this;
    
    for(var i = 0; i < this._cards.length; i++)
    {
        if(!this._cards[i].locked)
        this._cards[i].on("clicked", function(e){
            if(e.status == "close")
            {
                this.open();
                
                self._selections.push(this);
                
                if(self._atualIndex == null)
                {
                    self._atualIndex = this.index; 
                    if(self._type == "individual")
                    {
                        self._checkIndividual();
                    }
                }
                else
                {
                    self._checkIndex(this.index);
                }
            }            
        });
    }
}

MemoryGame.prototype._removeEvents = function()
{
    for(var i = 0; i < this._cards.length; i++)
    {
        this._cards[i].removeListener("clicked");
    }
}

MemoryGame.prototype._checkIndividual = function()
{
    this._removeEvents();
    
    var self = this;
    
    var check = false;
    
    for(var i = 0; i < this._corrects.length; i++)
    {
        if(this._corrects[i] == this._atualIndex)
        {
            check = true;
            break;
        }
    }
    
    console.log("verificando...." + check);
    
    if(check)
    {
        this._selections[0].openFeed("ok");
        this._selections[0].locked = true;
        
        this.emit("correct");
        this._atualIndex = null;
        this._selections.splice(0, this._selections.length);
    }
    else
    {
        console.log("estou aqui")
        this._selections[0].openFeed("fail");
        
        this.emit("incorrect");
        
        setTimeout(function(){
            for(var i = 0; i < self._selections.length; i++)
            {
                self._selections[i].closeFeed();
                self._selections[i].close();
            }
            
            self._atualIndex = null;
            self._selections.splice(0, self._selections.length);
        }, 1000);
    }
}

MemoryGame.prototype._checkIndex = function(index)
{
    this._removeEvents();
    
    var self = this;
    
    if(index == this._atualIndex)
    {
        for(var i = 0; i < this._selections.length; i++)
        {
            this._selections[i].openFeed("ok");
            this._selections[i].locked = true;
        }
        
        this.emit("correct");
        this._atualIndex = null;
        this._selections.splice(0, this._selections.length);
    }
    else
    {       
        for(var i = 0; i < this._selections.length; i++)
        {
            this._selections[i].openFeed("fail");
        }
        
        this.emit("incorrect");
        
        setTimeout(function(){
            for(var i = 0; i < self._selections.length; i++)
            {
                self._selections[i].closeFeed();
                self._selections[i].close();
            }
            
            self._atualIndex = null;
            self._selections.splice(0, self._selections.length);
        }, 1000);
    }
}

MemoryGame.prototype.destroy = function()
{
    for(var i = 0; i < this._cards.length; i++)
        this._cards[i].destroy();
}

tls.templates.MemoryGame = MemoryGame;