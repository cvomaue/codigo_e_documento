function SelectableText(text, size, width)
{    
    this._size = size || 30;
    this._width = width || 500;
    
    this._inputTheme = new GOWN.ShapeTheme();
    this._inputTheme.textStyle = {
        "fill": "#000",
        "font": this._size + "px Angola",
        "wordWrap": true,
        "wordWrapWidth": this._width
    };
    
    GOWN.TextInput.call(this, text, false, this._inputTheme);
    
    this._corrects = ["batedeira"];
    this._results = {};
    this._mouse;
    
    var outputText = this.pixiText.wordWrap(text);
    this._lines = outputText.split(/(?:\r\n|\r|\n)/);
}

SelectableText.prototype = Object.create(GOWN.TextInput.prototype);
SelectableText.prototype.constructor = SelectableText;

Object.defineProperties(SelectableText.prototype, {
    corrects: {
        set: function(value)
        {
            this._corrects = value;
        }
    }
})

SelectableText.prototype.onMouseDown = function(e)
{    
    GOWN.TextInput.prototype.onMouseDown.call(this, e);
    
    this._mouse = this.mousePos(e); 
    
    var mouse = this.mousePos(e);
    this.cursorY = this._calculateY()
    this.cursorPos = this.clickPos(mouse.x, mouse.y)
    this.setCursorPos();
    this._cursorNeedsUpdate = true;
}

SelectableText.prototype.onfocus = function() {
    
};

SelectableText.prototype.focus = function () {
    // is already current input
    if (GOWN.InputControl.currentInput === this) {
        return;
    }

    // drop focus
    if (GOWN.InputControl.currentInput) {
        GOWN.InputControl.currentInput.blur();
    }

    // set focus
    GOWN.InputControl.currentInput = this;
    this.hasFocus = true;

    // check custom focus event
    this.onfocus();

    /*
     //TODO
     // is read only
     if(this.readonly) {
        return;
     }
     */

    // focus hidden input
    //InputWrapper.focus();
};

SelectableText.prototype.onMouseUp = function(e)
{
    GOWN.TextInput.prototype.onMouseUp.call(this, e);
    
    var selected = this._lines[this._currentLine() - 1].substring(this.selection[0], this.selection[1]);
    if(selected.length > 0) this._checkResult(selected, [this.selection[0], this.selection[1]]);
    
    this.updateSelection(0, 0);
}

SelectableText.prototype.onMouseMove = function (e) {
    var mouse = this.mousePos(e);
    if (!this.hasFocus || !this._mouseDown || this.selectionStart < 0) { // || !this.containsPoint(mouse)) {
        return false;
    }

    var curPos = this.clickPos(mouse.x, mouse.y),
        start = Math.min(this.selectionStart, curPos),
        end = Math.max(this.selectionStart, curPos);
    
    //console.log("end...." + end * this._currentLine())

    if (this.updateSelection(start, end)) {
        this.cursorPos = curPos;
        this.cursorY = this._calculateY();
        this.setCursorPos();
        this._cursorNeedsUpdate = true;
    }
    return true;
};

SelectableText.prototype.setCursorPos = function () {
    this.cursor.x = this.textWidth(this.text.substring(0, this.cursorPos)) | 0;
    this.cursor.y = this.cursorY;
};

SelectableText.prototype.clickPos = function(x)
{

    var text = this._lines[this._currentLine() - 1],
        totalWidth = this.pixiText.x,
        pos = text.length;

    if (x < this.textWidth(text) + totalWidth)
    {
        // loop through each character to identify the position
        for (var i=0; i<text.length; i++)
        {
            totalWidth += this.textWidth(text[i]);
            if (totalWidth >= x)
            {
                pos = i;
                break;
            }
        }
    }

    return this._clipPos[0] + pos;
};

SelectableText.prototype.updateTextState = function()
{
    //console.log("nada")
}

SelectableText.prototype.updateSelection = function(start, end)
{
    if (this.selection[0] !== start || this.selection[1] !== end) {
        this.selection[0] = start;
        this.selection[1] = end;
        //InputWrapper.setSelection(start, end);
        this._cursorNeedsUpdate = true;
        this.updateSelectionBg();
        return true;
    } else {
        return false;
    }
}

SelectableText.prototype.updateSelectionBg = function()
{
    var start = this.posToCoord(this.selection[0]),
        end = this.posToCoord(this.selection[1]);

    this.selectionBg.clear();
    if (start !== end) {
        this.selectionBg.beginFill(0x0080ff);
        this.selectionBg.drawRect(0, 0, end - start, this._size);
        this.selectionBg.x = start;
        this.selectionBg.y = this._calculateY();
    }
}

SelectableText.prototype.posToCoord = function(pos) {
    var text = this._lines[this._currentLine() - 1],
        totalWidth = this.pixiText.x;

    if (pos < text.length) {
        return totalWidth + this.textWidth(text.substring(0, pos));
    } else {
        return totalWidth + this.textWidth(text);
    }
};

SelectableText.prototype.setCursorPos = function()
{
    this.cursor.x = this.textWidth(this._lines[this._currentLine() - 1].substring(0, this.cursorPos)) | 0;
    this.cursor.y = this.cursorY;
}

SelectableText.prototype._checkResult = function(selected, area)
{    
    console.log(selected);
    for(var i = 0; i < this._corrects.length; i++)
    {
        if(selected == this._corrects[i])
        {
            this.emit("correct");
            this._setOk(area);
            return;
        }
    }
    
    this.emit("incorrect");
    this._setFail(area);
}

SelectableText.prototype._setFail = function(area)
{
    var self = this;
    
    var feed = this._drawFeed(area, 0xa21818);
    
    TweenMax.to(feed, 0.3, {alpha: 1, onComplete: function(){
        setTimeout(function(){
            TweenMax.to(feed, 0.2, {alpha: 0, onComplete: function(){
                self.removeChild(feed);
                feed.destroy();
                feed = null;
            }});
        }, 500);
    }}); 
}

SelectableText.prototype._setOk = function(area)
{
    var feed = this._drawFeed(area, 0x1ba218);
    
    TweenMax.to(feed, 0.3, {alpha: 1});
}

SelectableText.prototype._drawFeed = function(area, color)
{
    var start = this.posToCoord(area[0]);
    var end = this.posToCoord(area[1]);
    
    var feed = new PIXI.Graphics();
    feed.beginFill(color);
    feed.drawRect(0, 0, end - start, this._size);
    feed.endFill();
    
    feed.alpha = 0;
    feed.x = start;
    feed.y = this._calculateY();
    this.addChildAt(feed, 0);
    
    return feed;
}

SelectableText.prototype._currentLine = function()
{
    try{
        var currentLine = Math.ceil(this._mouse.y / this._size / 1.1);
    }
    catch(err)
    {
        return 1;
    }
    
    return currentLine;
}

SelectableText.prototype._calculateY = function()
{
    var c = this.pixiText.height / this._size / 1.1;
    var numLines = Math.ceil(c);
    
    var l = numLines * this._size;
    var space = (this.pixiText.height - l) / (numLines - 1);
    
    var currentLine = this._currentLine();
    
    var posY = (this._size + space) * (currentLine - 1) + (this._size * 0.1 * currentLine);
    
    return posY;
}

