function Tela()
{
    tls.core.Factory.call(this, "telas/007/sprites.json");
    
    this.soundManager = new tls.media.SoundManager();
    this.soundManager.addSingleSound("telas/007/7_1.mp3");
    this.soundManager.addSingleSound("telas/007/7_2.mp3");
    this.soundManager.addSingleSound("telas/007/7_3.mp3");
    this.soundManager.addSingleSound("telas/007/7_4.mp3");
    this.soundManager.addSingleSound("telas/007/7_5.mp3");
    this.soundManager.addSingleSound("telas/007/7_6.mp3");
    this.soundManager.addSingleSound("telas/007/7_7.mp3");
    this.soundManager.addSingleSound("telas/007/7_8.mp3");
    this.soundManager.addSingleSound("telas/007/7_9.mp3");
    //quantos sons forem necessarios para os baloes
    
    this.dialogos;
    
    this.count = 0;
    
    this.on("complete", function(){
        this.removeListener("complete");
        this.init();
        
        var urls = [
            "telas/007/popup00.png",
            "telas/007/popup01.png",
            "telas/007/popup02.png",
            "telas/007/popup03.png",
            "telas/007/popup04.png",
            "telas/007/popup05.png",
            "telas/007/popup06.png",
            "telas/007/popup07.png"
        ];
        
        var tx = new tls.loaders.HTMLTexture();
        this.tx = tx;
        tx.addMultiple(urls);
        tx.load();
        
        this.pops = [];
        this.count = 0;
        
        for(var i = 0; i < urls.length; i++)
        {
            var p = new tls.display.PopUp(new PIXI.Sprite(tx.getTextures()[i]));
            p.setAudio(this.soundManager, i + 1);
            
            this.addChild(p);
            this.pops.push(p);
        }
    });    
}

Tela.prototype = Object.create(tls.core.Factory.prototype);
Tela.prototype.constructor = Tela;

Tela.prototype.init = function()
{
    var self = this;
    this.dialogos = new tls.templates.Dialog(this, this.soundManager, [0]);
    this.dialogos.on("preStart", function(e){
        e.ballon.direction = "-";
    });
    this.dialogos.on("start", function(e){
        
    });
    this.dialogos.on("soundStart", function(e){
        
    });
    this.dialogos.on("soundComplete", function(e){
        
    });
    this.dialogos.on("end", function(e){
        self._initIcons(self.count);
        
        for(var i = 0; i < self.clicks.length; i++)
        {
            var c = self.clicks[i];
            c.addIcon();
            c.id = i ;
            c.on("clicked", function(){
                this.removeListener("clicked");
                this.removeEvents();
                this.icon.stopAnimation();
                this.close();
                
                var p = self.pops[this.id];
                p.open();
                p.on("closed", function(){
                    this.removeListener("closed");
                    
                    self.count++;
                    
                    if(self.count >= self.clicks.length)
                    {
                        self.emit("removeAll");
                        return;
                    }
                    
                    self._initIcons(self.count); 
                });                
            });
            
            c.alpha = 0;
        }
    });    
    
    this.dialogos.play();
    
}

Tela.prototype._initIcons = function(index)
{
    this.clicks[index].open();
    this.clicks[index].addIcon();
    this.clicks[index].icon.animate();
    this.clicks[index].addEvents();
}

Tela.prototype.destroy = function()
{
    this.dialogos.destroy();
    this.soundManager.destroy();
    
    for(var i = 0; i < this.clicks.length; i++)
        this.clicks[i].destroy();
    
    for(i = 0; i < this.stars.length; i++)
        this.stars[i].destroy();
    
    for(i = 0; i < this.icons.length; i++)
        this.icons[i].destroy();
    
    for(i = 0; i < this.pops.length; i++)
        this.popx[i].destroy();
    
    this.tx.destroy();
    
    tls.core.Factory.prototype.destroy.call(this);
}